# src/automation_ssarres_conservar.py
"""
Automatización de la forma SSARRES (Restricciones de horario) con Playwright
(API ASÍNCRONA): «DEJAR SOLO PROGRAMAS». Solo se trabaja en la sección
"RESTRICCIONES DE PROGRAMA" de la pestaña "Grado y programa"; la sección de Grado
NO se toca nunca.

Qué hace: para cada NRC deja ÚNICAMENTE los códigos de programa indicados para
ESE NRC y borra todos los demás. Nunca escribe un programa: solo borra filas
(Shift+F6), así que no depende de que Banner deje una fila vacía en edición.

ENTRADA (CSV / Excel / TXT, una fila por NRC):
    primera columna  = NRC
    columnas siguientes = códigos de programa que deben QUEDAR (3 dígitos numéricos)
    Ejemplo:   2464,502        2465,503,504

Reglas (cerradas con el usuario):
  - Todo se valida ANTES de empezar; si algo no cumple, no se inicia nada:
    NRC solo dígitos, al menos un código por NRC, cada código = 3 dígitos
    numéricos, y un NRC no puede repetirse con códigos distintos.
  - Por NRC se lee la lista COMPLETA de programas (todas las páginas, validada
    contra «Registro x de N»).
  - Si falta ALGUNO de los códigos pedidos en el NRC: error controlado, no se
    toca nada, F5 y se pasa al siguiente NRC (no cuenta para el corte por fallos
    seguidos: es un error de datos, no de Banner).
  - Si la lista ya es exactamente la pedida: "sin cambios" (no se pulsa F10).
  - Si no: se guarda la TRAZA (programas iniciales), se borra cada fila que NO
    está en los códigos pedidos (en cada vuelta se lee la fila ACTIVA y se
    comprueba que no es un código a conservar antes de Shift+F6), se VERIFICA con
    una lectura completa que quedaron solo los pedidos y recién entonces F10.
    Después de F10 se verifica la lista final y NUNCA se reintenta.
  - Incluir/Excluir en «Excluir»: error, no se toca nada.

Errores:
  - Un NRC que falla NO detiene la corrida: se marca error y se sigue. Solo se
    detiene si la sesión expiró o fallan MAX_FALLOS_SEGUIDOS NRCs seguidos.
  - Antes de F10, cualquier falla recarga TODA la página, vuelve a abrir la
    forma y reintenta (MAX_INTENTOS_POR_NRC). Nada se guardó, así que es seguro.
  - NRC inexistente, códigos faltantes e Incluir/Excluir en «Excluir» son errores
    CONTROLADOS: se informan, no se reintentan y no cuentan para el corte.

Este módulo es AUTOCONTENIDO: copia (no importa) lo validado en
automation_ssarres.py (quitar el 502), de modo que tocar uno no puede romper el
otro. Solo importa helpers de `.automation` y `.state`, como los demás.

Se ejecuta desde la app (main.py) o por línea de comandos:

    python -m src.automation_ssarres_conservar 202620 nrcs_y_programas.csv --visible

(requiere haber iniciado sesión antes con la app: usa la misma sesión
guardada en datos/banner_storage_state.json).
"""

import asyncio
import csv
import math
import os
import re
import sys
import time
import unicodedata
from datetime import datetime

from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

from .automation import (
    BANNER_URL,
    SELECTORES,
    SesionExpiradaError,
    _requiere_reautenticacion,
    _pantalla_muestra_sesion_expirada,
    _encontrar_frame,
    _guardar_captura_error,
    _pagina_nueva,
    _tecleo_confiable,
)
from .state import (
    ruta_sesion,
    carpeta_logs,
    invalidar_sesion,
    hay_sesion_guardada,
    EstadoCorrida,
)

# ------------------------------------------------------------------
# CONFIGURACIÓN
# ------------------------------------------------------------------

NOMBRE_FORMA = "SSARRES"

# Nombre de la carpeta de pendientes/procesados/fallos en datos/logs.
ACCION = "ssarres_conservar"
# Carpeta (dentro de datos/logs) de la traza y de los archivos de errores.
CARPETA_REGISTROS = "ssarres_conservar_registros"

# Registros por página que se fijan en la grilla de Programa (opciones de
# Banner: 10, 20, 30, 40, 50).
POR_PAGINA = 50
# Tamaño de la ventana (viewport) del navegador. Con 27 o más programas el
# paginador y las últimas filas pueden quedar fuera de la ventana y el código
# desplaza la página para llegar a ellos.
VIEWPORT_ANCHO = 1600
VIEWPORT_ALTO = 1200
# Registros por página por defecto de Banner (con menos o igual a esto, el selector
# 'Por página' se queda deshabilitado y no hace falta cambiarlo).
POR_PAGINA_BASE = 10

# Cómo llegar a la grilla de Programa. PRIMERA opción (determinista, confirmada
# en Banner real): clic en la pestaña "Grado y programa" y clic en la primera
# línea de Restricciones de programa (eso habilita la barra y "Por página").
# Alt+PageDown contando queda de RESPALDO: con 6 se llega a la pestaña pero
# seguir pulsando se pasa hasta "Atributo y cohorte de alumno".
USAR_CLIC_PRIMERO = True
ALT_PGDN_ESPERADAS = 6
MAX_ALT_PGDN = 6

# --- Paralelismo -----------------------------------------------------------
# DESACTIVADO hasta validar esta función con 1 pestaña (el flujo borra datos y
# el problema de varias pestañas sigue abierto). Para activarlo: True.
PARALELO_HABILITADO = True
UMBRAL_PARALELO = 20
NUM_PESTANAS = 5

# Intentos por NRC ANTES de F10 (cada fallo recarga la página completa).
MAX_INTENTOS_POR_NRC = 2

# Si fallan tantos NRCs SEGUIDOS por causas de Banner (no cuentan los errores
# controlados), se asume que Banner dejó de responder y se detiene la corrida.
MAX_FALLOS_SEGUIDOS = 5

# SOLO PARA PRUEBAS: antepone "[Pestaña N]" y el tiempo a los mensajes del panel.
MOSTRAR_PESTANA_EN_RESUMEN = False

# SOLO PARA PRUEBAS: True abre el navegador VISIBLE. False = headless (normal).
# Desde la línea de comandos manda --visible.
MOSTRAR_NAVEGADOR = False

# Límite de tiempo por intento de un NRC (red de seguridad contra cuelgues). Es mayor
# que en «Quitar programa 502» (240) porque aquí se borran las filas una por una
# (un NRC con 30-50 sobrantes tarda bastante más que quitar una sola).
LIMITE_SEGUNDOS_POR_INTENTO = 420

# --- Tiempos (valores seguros; bajarlos de a poco tras validar) --------------
ESPERA_TRAS_ALT_PGDN = 0.5
ESPERA_DETALLE = 20.0          # máx. para que cargue el detalle tras el NRC
ESPERA_TRAS_DETALLE = 1.0      # margen para que SlickGrid termine de dibujar
ESPERA_TRAS_CLIC = 0.3
ESPERA_TRAS_POR_PAGINA = 1.0
ESPERA_TRAS_F10 = 0.3


# ------------------------------------------------------------------
# ERRORES
# ------------------------------------------------------------------

class ErrorControlado(RuntimeError):
    """Resultado esperable que no es una falla de Banner: se informa, no se
    reintenta. Atributos: `cuenta_para_corte` (si suma a los fallos seguidos) y
    `requiere_recarga` (si hay cambios sin guardar que obligan a recargar)."""
    cuenta_para_corte = False
    requiere_recarga = False


class NrcInexistenteError(ErrorControlado):
    pass


class ModoExcluirError(ErrorControlado):
    pass


class ProgramasFaltantesError(ErrorControlado):
    """Alguno de los códigos a conservar no está en la lista del NRC. No se
    tocó nada (se detecta antes de borrar), así que basta F5."""


class PostGuardadoError(RuntimeError):
    """Algo falló DESPUÉS de pulsar F10: el estado en Banner pudo cambiar. No se
    reintenta; hay que verificar el NRC (la foto previa está en la traza)."""
    cuenta_para_corte = True


# ------------------------------------------------------------------
# ENTRADA: NRC + CÓDIGOS A CONSERVAR (lectura y validación)
#
# Cada línea / fila = un NRC con los códigos de programa que deben QUEDAR:
#     NRC,código,código,...      p. ej.   2464,503,504
# La "clave" de la línea (lo que se guarda en pendientes/errores y lo que se
# puede reimportar) es esa misma forma normalizada.
# ------------------------------------------------------------------

_PATRON_NRC = re.compile(r"^[0-9]{1,10}$")
_PATRON_CODIGO = re.compile(r"^[0-9]{3}$")
_SEPARADORES = re.compile(r"[,;\s]+")


def _a_texto(valor) -> str:
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    return str(valor).strip()


def armar_clave(nrc: str, codigos: list) -> str:
    """('2464', ['503', '504']) -> '2464,503,504'."""
    return ",".join([nrc] + list(codigos))


def separar_clave(clave: str) -> tuple:
    """'2464,503,504' -> ('2464', ['503', '504'])."""
    partes = [p for p in _SEPARADORES.split((clave or "").strip()) if p]
    if not partes:
        raise ValueError("línea vacía")
    return partes[0], partes[1:]


def validar_lineas(lineas: list, numeros: list = None) -> tuple:
    """Valida TODAS las líneas «NRC,código,código». Devuelve
    (claves_ok, errores, repetidas):
      - claves_ok: líneas normalizadas (códigos sin repetir, en el orden dado).
      - errores: textos claros; si hay alguno, la corrida NO debe iniciar.
      - repetidas: líneas idénticas (mismo NRC y mismos códigos) que se descartan.
    Un NRC repetido con códigos DISTINTOS es un error (sería ambiguo).
    `numeros` (opcional) son los números de línea/fila a mostrar en los errores."""
    ok, errores, vistos, repetidas = [], [], {}, 0
    for i, linea in enumerate(lineas):
        n = numeros[i] if numeros else i + 1
        texto = (linea or "").strip()
        if not texto:
            continue
        partes = [p for p in _SEPARADORES.split(texto) if p]
        nrc, codigos = partes[0], partes[1:]
        if not _PATRON_NRC.match(nrc):
            errores.append(f"Línea {n}: «{nrc}» no es un NRC válido (solo dígitos)")
            continue
        if not codigos:
            errores.append(
                f"Línea {n}: el NRC {nrc} no trae ningún código de programa "
                "(formato: NRC,código,código)"
            )
            continue
        malos = [c for c in codigos if not _PATRON_CODIGO.match(c)]
        if malos:
            errores.append(
                f"Línea {n}: NRC {nrc}: código(s) de programa no válido(s) "
                + ", ".join(f"«{m}»" for m in malos)
                + " (deben ser exactamente 3 dígitos numéricos)"
            )
            continue
        sin_repetir = list(dict.fromkeys(codigos))
        if nrc in vistos:
            n_previa, set_previo = vistos[nrc]
            if set_previo == set(sin_repetir):
                repetidas += 1
            else:
                errores.append(
                    f"Línea {n}: el NRC {nrc} ya aparece en la línea {n_previa} con otros códigos; "
                    "cada NRC debe tener una sola línea con todos los códigos que deben quedar"
                )
            continue
        vistos[nrc] = (n, set(sin_repetir))
        ok.append(armar_clave(nrc, sin_repetir))
    return ok, errores, repetidas


def leer_pares_de_archivo(ruta: str) -> tuple:
    """Lee un CSV / Excel / TXT con el NRC en la PRIMERA columna y los códigos de
    programa a conservar en las siguientes (salta la primera fila si su primera
    celda no es numérica: encabezado). Devuelve (claves, repetidas).
    ValueError con mensaje claro si algo no cumple (nada se inicia a medias)."""
    extension = os.path.splitext(ruta)[1].lower()
    filas = []
    if extension in (".xlsx", ".xls"):
        import openpyxl  # import perezoso

        libro = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
        for fila in libro.active.iter_rows(values_only=True):
            filas.append([_a_texto(c) for c in (fila or ())])
    elif extension in (".csv", ".txt"):
        with open(ruta, newline="", encoding="utf-8-sig") as f:
            muestra = f.read(4096)
            f.seek(0)
            cuentas = {d: muestra.count(d) for d in (",", ";", "\t")}
            delimitador = max(cuentas, key=cuentas.get) if max(cuentas.values()) > 0 else ","
            for fila in csv.reader(f, delimiter=delimitador):
                filas.append([c.strip() for c in fila])
    else:
        raise ValueError(f"Formato de archivo no soportado: {extension}")

    # Se conservan los números de fila reales del archivo para los mensajes.
    con_numero = [(n, fila) for n, fila in enumerate(filas, start=1) if any(c for c in fila)]
    if con_numero and con_numero[0][1][0] and not con_numero[0][1][0].isdigit():
        con_numero = con_numero[1:]          # encabezado
    lineas, numeros = [], []
    for n, fila in con_numero:
        nrc = fila[0] if fila else ""
        codigos = [c for c in fila[1:] if c]
        lineas.append(",".join([nrc or "(sin NRC)"] + codigos))
        numeros.append(n)
    claves, errores, repetidas = validar_lineas(lineas, numeros)
    if errores:
        raise ValueError(
            "El archivo tiene filas que no cumplen el formato NRC + códigos de 3 dígitos. "
            + " | ".join(errores[:5])
            + (f" ... y {len(errores) - 5} más" if len(errores) > 5 else "")
        )
    return claves, repetidas


# ------------------------------------------------------------------
# TRAZABILIDAD Y REGISTRO DE ERRORES (datos/logs/ssarres_conservar_registros/)
#
#   programas_iniciales_<marca>.csv   nrc, programas_iniciales (códigos separados
#                                     por coma, en UNA celda), programas_a_conservar.
#                                     Solo los NRC que realmente se intenta modificar.
#                                     Se escribe ANTES del primer Shift+F6.
#   nrcs_con_error_<marca>.csv        nrc, programas_a_conservar, motivo
#   nrcs_con_error_<marca>.txt        una línea «NRC,código,código» por NRC con error,
#                                     SIN motivo: se puede importar tal cual
# ------------------------------------------------------------------

_marca_corrida = None
_fotos_corrida = {}   # nrc -> lista de programas del PRIMER intento


def _carpeta_registros() -> str:
    ruta = os.path.join(carpeta_logs(), CARPETA_REGISTROS)
    os.makedirs(ruta, exist_ok=True)
    return ruta


def _marca() -> str:
    global _marca_corrida
    if _marca_corrida is None:
        _marca_corrida = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    return _marca_corrida


def ruta_csv_traza() -> str:
    return os.path.join(_carpeta_registros(), f"programas_iniciales_{_marca()}.csv")


def ruta_csv_errores() -> str:
    return os.path.join(_carpeta_registros(), f"nrcs_con_error_{_marca()}.csv")


def ruta_txt_errores() -> str:
    """TXT de la corrida actual: una línea «NRC,código,código» por NRC con error,
    sin encabezado ni motivo (se puede importar tal cual para reintentar)."""
    return os.path.splitext(ruta_csv_errores())[0] + ".txt"


def _reiniciar_registros() -> None:
    global _marca_corrida
    _marca_corrida = None
    _fotos_corrida.clear()


def hay_errores_en_corrida() -> bool:
    return _marca_corrida is not None and os.path.exists(ruta_txt_errores())


def registrar_programas_iniciales(nrc: str, programas: list, conservar: list) -> None:
    ruta = ruta_csv_traza()
    es_nuevo = not os.path.exists(ruta)
    with open(ruta, "a", newline="", encoding="utf-8-sig") as f:
        escritor = csv.writer(f)
        if es_nuevo:
            escritor.writerow(["nrc", "programas_iniciales", "programas_a_conservar"])
        escritor.writerow([nrc, ",".join(programas), ",".join(conservar)])
        f.flush()
        os.fsync(f.fileno())


def registrar_nrc_error(clave: str, motivo: str) -> None:
    nrc, conservar = separar_clave(clave)
    ruta = ruta_csv_errores()
    es_nuevo = not os.path.exists(ruta)
    with open(ruta, "a", newline="", encoding="utf-8-sig") as f:
        escritor = csv.writer(f)
        if es_nuevo:
            escritor.writerow(["nrc", "programas_a_conservar", "motivo"])
        escritor.writerow([nrc, ",".join(conservar), motivo])
    with open(ruta_txt_errores(), "a", encoding="utf-8") as f:
        f.write(clave + "\n")


# ------------------------------------------------------------------
# MENSAJES DE BANNER (español e inglés) - listas PROPIAS de esta forma.
#
# Se comparan contra el texto VISIBLE normalizado (minúsculas, sin tildes), así
# que las frases van sin tildes. Los marcados CONFIRMADO salieron de capturas
# reales; las variantes en inglés de NRC inexistente son suposiciones
# razonables: si Banner usa otra redacción, el error saldrá con el texto real en
# el motivo ([DIAG]) y basta agregarla aquí.
# ------------------------------------------------------------------

FRASES_EXITO = [
    # inglés (CONFIRMADO: "Saved successfully (1 rows saved)")
    "saved successfully",
    "changes saved",
    "record saved",
    "transaction complete",
    "no changes to save",
    # español (texto real visto en otras formas: "Guardado con suceso (2 registros guardados)")
    "guardado con suceso",
    "guardado con exito",
    "guardado exitosamente",
    "guardado correctamente",
    "cambios guardados",
    "sin cambios que guardar",
    "no hay cambios que guardar",
    "sin cambios para guardar",
]

# CONFIRMADO: "*ERROR* Debe existir una sección para utilizar la página, consulte
# la lista de valores para ver los NRC válidos."
FRASES_NRC_INEXISTENTE = [
    "debe existir una seccion para utilizar la pagina",
    "a section must exist to use the page",
    "section must exist",
]

# Errores que NO son fallo del guardado (tecla inválida en el contexto actual).
FRASES_ERROR_IGNORABLES = ("funcion invalida", "invalid function")


def _normalizar(texto: str) -> str:
    """Minúsculas, sin tildes y con espacios/saltos de línea colapsados."""
    sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto or "") if unicodedata.category(c) != "Mn"
    )
    return " ".join(sin_tildes.lower().split())


def _errores_en(texto_norm: str) -> list:
    """Cola (hasta 160 caracteres) de cada '*error*' visible que sí cuenta."""
    res = []
    for m in re.finditer(r"\*error\*", texto_norm):
        cola = texto_norm[m.end(): m.end() + 160].strip()
        if cola.startswith(FRASES_ERROR_IGNORABLES):
            continue
        res.append(cola)
    return res


def _contar(texto_norm: str) -> dict:
    """Cuántos avisos de cada tipo hay en el texto visible (ya normalizado)."""
    errs = _errores_en(texto_norm)
    return {
        "exito": sum(texto_norm.count(f) for f in FRASES_EXITO),
        "error": len(errs),
        "nrc": sum(1 for e in errs if any(f in e[:140] for f in FRASES_NRC_INEXISTENTE)),
    }


# ------------------------------------------------------------------
# SCRIPTS JS (se ejecutan DENTRO del iframe del formulario con frame.evaluate)
# ------------------------------------------------------------------

# La grilla de Programa se identifica por data-name="grdSsrrprg" (estable); el
# id "page_degreeProgramRestriction_grdSsrrprg" es el respaldo. Los ids
# dinámicos (frames59, slickgrid_383347...) NO se usan.
SEL_GRILLA = '[data-name="grdSsrrprg"], [id$="_grdSsrrprg"]'
SEL_RADIO_INCLUIR = "#rb_SsrrprgProgramInd_Include_btn"

_JS_COMUN = r"""
  const GRID = '__GRID__';
  const grid = document.querySelector(GRID);
  // Paginador de la sección de Programa. Orden de búsqueda: (1) dentro de la grilla;
  // (2) POR POSICIÓN: el paginador con tamaño real que queda justo debajo de la grilla
  // (no depende de cuántos haya en la página: tras redibujar puede haber duplicados u
  // ocultos); (3) el único paginador de algún ancestro (regla antigua).
  function pagerDe(el) {
    const dentro = el.querySelector('.ui-grid-pager');
    if (dentro) return dentro;
    const gr = el.getBoundingClientRect();
    let mejor = null, mejorD = 1e9;
    document.querySelectorAll('.ui-grid-pager').forEach(p => {
      const r = p.getBoundingClientRect();
      if (!(r.width > 0 && r.height > 0)) return;           // oculto o sin dibujar
      const d = r.top - gr.bottom;                            // distancia vertical bajo la grilla
      if (d < -6 || d > 200) return;
      if (r.right < gr.left || r.left > gr.right) return;     // sin solape horizontal
      if (d < mejorD) { mejorD = d; mejor = p; }
    });
    if (mejor) return mejor;
    let n = el;
    while (n && n.parentElement) {
      const pgs = n.parentElement.querySelectorAll('.ui-grid-pager');
      // Solo vale un paginador que quede DESPUÉS de la grilla: el de la sección de
      // Grado (antes) no es el de Programa aunque sea el único del ancestro.
      if (pgs.length === 1 && (el.compareDocumentPosition(pgs[0]) & Node.DOCUMENT_POSITION_FOLLOWING)) return pgs[0];
      n = n.parentElement;
    }
    return null;
  }
  const reposo = ms => new Promise(r => setTimeout(r, ms));
  // Espera a que la grilla redibuje tras un scroll (rAF doble; con respaldo por tiempo
  // por si la pestaña no pinta).
  const tick = async () => {
    await Promise.race([new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))), reposo(250)]);
    await reposo(80);
  };
  // Como pagerDe, pero si no aparece desplaza la página hasta dejar a la vista el
  // pie de la sección de Programa (el paginador puede no existir/no localizarse
  // mientras está fuera de la ventana) y vuelve a buscar.
  async function pagerVisible(el) {
    let p = pagerDe(el);
    if (p) return p;
    el.scrollIntoView({block: 'end'}); await tick();
    p = pagerDe(el); if (p) return p;
    for (let n = el; n; n = n.parentElement) {
      if (n.scrollHeight > n.clientHeight + 4) n.scrollTop = n.scrollHeight;
    }
    await tick();
    return pagerDe(el);
  }
  function raizFilas(el) { return el.querySelector('.slick-pane-top.slick-pane-left') || el; }
"""

# Elemento con foco: si está dentro de la grilla de Programa, si está en una
# fila, su valor / si es de solo lectura, y la pestaña activa.
_JS_FOCO = ("() => {" + _JS_COMUN + r"""
  const a = document.activeElement;
  if (!a) return null;
  const enGrilla = !!(grid && a !== document.body && grid.contains(a));
  let tab = '';
  const cands = document.querySelectorAll('[role="tab"][aria-selected="true"], li.ui-tabs-active, .ui-tabs-active');
  for (const t of cands) { const x = (t.innerText || t.textContent || '').trim(); if (x) { tab = x; break; } }
  const ro = (a.readOnly === true) || (a.getAttribute && a.getAttribute('readonly') !== null);
  return {
    tag: (a.tagName || '').toLowerCase(),
    value: (a.value === undefined ? null : a.value),
    readonly: !!ro,
    id: a.id || '',
    en_programa: enGrilla,
    en_fila: !!(a.closest && a.closest('.slick-row')),
    tab: tab
  };
}""").replace("__GRID__", SEL_GRILLA)

# Estado de la grilla de Programa: contador "Registro x de N", "Por página",
# página actual, radio Incluir y las filas (código, descripción, si es editable
# y si es la activa). Con {scroll: true} recorre el viewport para recoger
# también filas virtualizadas (si la grilla dibuja todas, no hace nada extra).
_JS_ESTADO = ("async (opts) => {" + _JS_COMUN + r"""
  if (!grid) return null;
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const pager = await pagerVisible(grid);
  let por_pagina = null, registro = null, total = null, sel_disabled = null, pagina_actual = null;
  if (pager) {
    const sel = pager.querySelector('select');
    if (sel) { por_pagina = parseInt(sel.value, 10); sel_disabled = !!sel.disabled; }
    const rs = pager.querySelector('.slick-pager-selected-record');
    const m = rs ? (rs.textContent || '').match(/(\d+)\D+(\d+)/) : null;
    if (m) { registro = parseInt(m[1], 10); total = parseInt(m[2], 10); }
    const pin = pager.querySelector('.slick-pager-controls input');
    if (pin) { const v = parseInt(pin.value, 10); if (!isNaN(v)) pagina_actual = v; }
  }
  // Filas que DEBERÍA haber en la página actual según el contador (la grilla solo
  // dibuja las visibles: las demás exigen hacer scroll para existir en el DOM).
  let esperadas = null;
  if (total !== null && por_pagina) {
    const pag = pagina_actual || 1;
    esperadas = Math.max(0, Math.min(por_pagina, total - (pag - 1) * por_pagina));
  }
  const rb = document.querySelector('__RADIO__');
  const incluir = rb ? rb.getAttribute('aria-checked') : null;

  const raiz = raizFilas(grid);
  const filas = new Map();
  function recoger() {
    raiz.querySelectorAll('.slick-row').forEach(r => {
      const top = parseInt((r.style.top || '0'), 10) || 0;
      const celdas = r.querySelectorAll(':scope > .slick-cell');
      if (!celdas.length) return;
      const leer = c => { const i = c.querySelector('input'); return ((i ? i.value : (c.innerText || '')) || '').trim(); };
      const inp = celdas[0].querySelector('input');
      filas.set(top, {
        top: top,
        codigo: leer(celdas[0]),
        desc: celdas[1] ? leer(celdas[1]) : '',
        editable: !!(inp && !inp.readOnly && inp.getAttribute('readonly') === null),
        activa: r.classList.contains('active') || r.getAttribute('aria-selected') === 'true'
      });
    });
  }
  recoger();
  const vp = grid.querySelector('.slick-viewport');
  const faltan = () => esperadas !== null && filas.size < esperadas;
  let pasos = 0;
  if (vp && ((opts && opts.scroll) || (!(opts && opts.rapido) && faltan()))) {
    const orig = vp.scrollTop;
    const paso = Math.max(24, Math.floor(vp.clientHeight / 2));   // medio viewport: con solape
    vp.scrollTop = 0; await tick(); recoger();
    let guarda = 0;
    let atascado = 0;
    while (vp.scrollTop + vp.clientHeight < vp.scrollHeight - 2 && guarda++ < 600) {
      const antes = vp.scrollTop;
      vp.scrollTop += paso; pasos++; await tick(); recoger();
      if (vp.scrollTop <= antes) { if (++atascado >= 3) break; } else atascado = 0;   // el scroll no avanza: se corta
    }
    // Último tramo: hasta el fondo (la última fila puede quedar justo en el borde).
    vp.scrollTop = vp.scrollHeight; await tick(); recoger();
    vp.scrollTop = orig;
  }
  return {
    esperadas: esperadas, completa: !faltan(), dibujadas: filas.size, pasos: pasos,
    pagers_total: document.querySelectorAll('.ui-grid-pager').length,
    pagers_visibles: Array.from(document.querySelectorAll('.ui-grid-pager')).filter(p => { const r = p.getBoundingClientRect(); return r.width > 0 && r.height > 0; }).length,
    pager_top: pager ? Math.round(pager.getBoundingClientRect().top) : null,
    grid_bottom: Math.round(grid.getBoundingClientRect().bottom), ventana_alto: window.innerHeight,
    total: total, registro: registro, por_pagina: por_pagina, sel_disabled: sel_disabled,
    pagina_actual: pagina_actual, hay_pager: !!pager, incluir: incluir,
    filas: Array.from(filas.values()).sort((a, b) => a.top - b.top)
  };
}""").replace("__GRID__", SEL_GRILLA).replace("__RADIO__", SEL_RADIO_INCLUIR)

# Marca con data-auto="..." los elementos sobre los que Playwright hará clic o
# select_option (los ids de Banner son dinámicos): el selector "Por página" y los
# botones de página DE LA SECCIÓN DE PROGRAMA, o una celda de código de la grilla.
_JS_ETIQUETAR = ("async (opts) => {" + _JS_COMUN + r"""
  document.querySelectorAll('[data-auto]').forEach(e => e.removeAttribute('data-auto'));
  const res = {};
  if (!grid) return res;
  if (opts.pager) {
    const pager = await pagerVisible(grid);
    if (pager) {
      pager.scrollIntoView({block: 'nearest'});
      await tick();
      const sel = pager.querySelector('select');
      if (sel) { sel.setAttribute('data-auto', 'pg-sel'); res['pg-sel'] = true; }
      const ctl = pager.querySelector('.slick-pager-controls') || pager;
      const icono = claves => { for (const k of claves) { const e = ctl.querySelector('[class*="' + k + '"]'); if (e) return e; } return null; };
      const mapa = {'pg-first': ['seek-first', 'first'], 'pg-prev': ['seek-prev', 'prev'],
                    'pg-next': ['seek-next', 'next'], 'pg-last': ['seek-end', 'last']};
      for (const nombre in mapa) {
        const e = icono(mapa[nombre]);
        if (e) { e.setAttribute('data-auto', nombre); res[nombre] = true; }
      }
    }
  }
  if (opts.celda) {
    const raiz = raizFilas(grid);
    const vp = grid.querySelector('.slick-viewport');
    const esperar = ms => new Promise(r => setTimeout(r, ms));
    // La grilla solo dibuja las filas visibles: se recorre con scroll hasta
    // encontrar la fila pedida (o hasta el fondo).
    const listar = () => Array.from(raiz.querySelectorAll('.slick-row'))
      .map(r => ({r: r, top: parseInt((r.style.top || '0'), 10) || 0}))
      .sort((a, b) => a.top - b.top);
    const cel0 = r => r.querySelector(':scope > .slick-cell');
    const porCodigo = cod => {
      for (const f of listar()) {
        const c = cel0(f.r); if (!c) continue;
        const i = c.querySelector('input');
        const v = ((i ? i.value : (c.innerText || '')) || '').trim().toUpperCase();
        if (v === cod) return c;
      }
      return null;
    };
    let elegido = null;
    if (opts.celda.codigo) {
      elegido = porCodigo(opts.celda.codigo);
      if (!elegido && vp) {
        const paso = Math.max(24, Math.floor(vp.clientHeight / 2));
        vp.scrollTop = 0; await tick();
        let guarda = 0;
        let atascado = 0;
        while (true) {
          elegido = porCodigo(opts.celda.codigo);
          if (elegido || vp.scrollTop + vp.clientHeight >= vp.scrollHeight - 2 || guarda++ > 600) break;
          const antes = vp.scrollTop;
          vp.scrollTop += paso; await tick();
          if (vp.scrollTop <= antes) { if (++atascado >= 3) break; } else atascado = 0;
        }
        if (!elegido) { vp.scrollTop = vp.scrollHeight; await tick(); elegido = porCodigo(opts.celda.codigo); }
      }
    } else {
      const ultima = opts.celda.posicion === 'ultima';
      if (vp) { vp.scrollTop = ultima ? vp.scrollHeight : 0; await tick(); }
      const filas = listar();
      if (filas.length) elegido = cel0(ultima ? filas[filas.length - 1].r : filas[0].r);
    }
    if (elegido) {
      elegido.scrollIntoView({block: opts.celda.bloque || 'center', inline: 'nearest'});
      await tick();   // el scroll puede redibujar las filas: se vuelve a localizar
      if (!elegido.isConnected && opts.celda.codigo) elegido = porCodigo(opts.celda.codigo);
      else if (!elegido.isConnected) {
        const filas = listar(); const ultima = opts.celda.posicion === 'ultima';
        elegido = filas.length ? cel0(ultima ? filas[filas.length - 1].r : filas[0].r) : null;
      }
    }
    if (elegido) { elegido.setAttribute('data-auto', 'celda'); res.celda = true; }
  }
  return res;
}""").replace("__GRID__", SEL_GRILLA)

# Comprueba que el elemento marcado (data-auto="celda") está dentro de la ventana y
# que en el punto donde se hará clic el elemento superior es esa misma fila (no una
# barra fija ni otra capa que la tape).
_JS_CLIC_LIBRE = r"""() => {
  const el = document.querySelector('[data-auto="celda"]');
  if (!el) return {ok: false, motivo: 'sin elemento marcado'};
  const r = el.getBoundingClientRect();
  const vh = window.innerHeight, vw = window.innerWidth;
  const x = Math.min(Math.max(r.left + Math.min(r.width / 2, 80), 1), vw - 2);
  const y = r.top + r.height / 2;
  if (y < 1 || y > vh - 1) return {ok: false, motivo: 'fuera de la ventana (y=' + Math.round(y) + ', alto=' + vh + ')'};
  const top = document.elementFromPoint(x, y);
  if (!top) return {ok: false, motivo: 'no hay elemento en el punto de clic'};
  const fila = el.closest('.slick-row');
  const ok = top === el || el.contains(top) || (fila && fila.contains(top));
  return {ok: ok, motivo: ok ? '' : ('tapada por <' + top.tagName.toLowerCase() + ' class="' + String(top.className || '').slice(0, 40) + '">')};
}"""

# Texto que SE VE de verdad (no el innerText, que incluye texto invisible y
# avisos viejos) del frame actual + el documento superior (shell de Banner,
# donde aparecen los avisos).
_JS_TEXTOS_VISIBLES = r"""() => {
  function tv(doc) {
    const out = [];
    if (!doc || !doc.body) return out;
    const cache = new Map();
    const w = doc.createTreeWalker(doc.body, 4, null);
    let n;
    while ((n = w.nextNode())) {
      const t = n.nodeValue;
      if (!t || !t.trim()) continue;
      const el = n.parentElement;
      if (!el) continue;
      const tag = el.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') continue;
      let vis = cache.get(el);
      if (vis === undefined) {
        const r = el.getBoundingClientRect();
        vis = (r.width >= 4 && r.height >= 4);
        if (vis && el.checkVisibility) {
          vis = el.checkVisibility({checkOpacity: true, checkVisibilityCSS: true});
        }
        cache.set(el, vis);
      }
      if (vis) out.push(t.trim());
    }
    return out;
  }
  let res = tv(document);
  try { if (window.top !== window) res = res.concat(tv(window.top.document)); } catch (e) {}
  return res;
}"""

# ¿Ya cargó el detalle del NRC? Sí cuando el campo NRC de la cabecera dejó de
# estar visible o aparecen las pestañas de la forma.
_JS_DETALLE_LISTO = r"""(selNrc) => {
  const n = document.querySelector(selNrc);
  const nrcVisible = !!(n && n.offsetParent !== null);
  const tab = document.querySelector('[role="tab"]');
  return !nrcVisible || !!(tab && tab.offsetParent !== null);
}"""


async def _pausa(segundos: float) -> None:
    if segundos > 0:
        await asyncio.sleep(segundos)



# ------------------------------------------------------------------
# UNA PESTAÑA DE TRABAJO
# ------------------------------------------------------------------

class VentanaSSARRESConservar:
    """Una pestaña (Page) con su propio estado: el frame del formulario."""

    def __init__(self, pagina, on_log, periodo: str, contexto=None):
        self.pagina = pagina
        self.contexto = contexto
        self.log = on_log
        self.periodo = periodo
        self.marco = None
        self.necesita_abrir = True    # True: hay que recargar la página completa
        self._f10_hecho = False       # True desde que se pulsa F10 en este intento

    # ----------------------------------------------------- utilidades base --

    async def _tecla(self, combinacion: str) -> None:
        await self.pagina.keyboard.press(combinacion)

    async def _foco(self):
        try:
            return await self.marco.evaluate(_JS_FOCO)
        except Exception:
            return None

    async def _estado(self, scroll: bool = False, rapido: bool = False):
        """Estado de la grilla de Programa (dict) o None si no se pudo leer. La
        grilla solo dibuja las filas visibles: si el contador dice que hay más,
        el JS recorre la grilla con scroll (siempre, con scroll=True)."""
        try:
            est = await self.marco.evaluate(_JS_ESTADO, {"scroll": bool(scroll), "rapido": bool(rapido)})
        except Exception:
            return None
        if not est:
            return None
        est["codigos"] = [(f["codigo"] or "").strip().upper() for f in est["filas"] if (f["codigo"] or "").strip()]
        return est

    async def _estado_o_error(self, scroll: bool = False, estricto: bool = True) -> dict:
        """Lee la grilla. Con estricto=True exige que estén TODAS las filas de la
        página actual (las del contador), recorriendo la grilla con scroll; si tras
        varios intentos faltan filas, es un error (nunca se decide con una lectura
        parcial)."""
        ultimo = None
        for i in range(6):
            est = await self._estado(scroll=scroll or i > 0)
            if est:
                if est.get("completa", True) or not estricto:
                    return est
                ultimo = est
            await asyncio.sleep(0.4 if est else 0.3)
        if ultimo:
            raise RuntimeError(
                f"lectura incompleta de la grilla de Programa: {ultimo.get('dibujadas')} filas leídas de "
                f"{ultimo.get('esperadas')} esperadas (total {ultimo.get('total')}, por página "
                f"{ultimo.get('por_pagina')}) aun recorriéndola con scroll"
            )
        raise RuntimeError("no se pudo leer la grilla de Programa")

    async def _diag_estado(self) -> str:
        """Resumen del estado de la grilla para el log de un fallo."""
        try:
            e = await asyncio.wait_for(self._estado(scroll=True), timeout=8)
        except Exception:
            e = None
        if not e:
            return "[DIAG] grilla no legible"
        return (f"[DIAG] total={e.get('total')} registro={e.get('registro')} por_pagina={e.get('por_pagina')} "
                f"select_deshabilitado={e.get('sel_disabled')} pagina={e.get('pagina_actual')} "
                f"filas_dibujadas={e.get('dibujadas')}/{e.get('esperadas')} completa={e.get('completa')} "
                f"codigos={len(e.get('codigos', []))} paginadores={e.get('pagers_visibles')}/{e.get('pagers_total')} "
                f"(visibles/total) pager_top={e.get('pager_top')} grilla_fin={e.get('grid_bottom')} "
                f"alto_ventana={e.get('ventana_alto')}")

    async def _textos_visibles(self) -> list:
        try:
            return list((await self.marco.evaluate(_JS_TEXTOS_VISIBLES)) or [])
        except Exception:
            return []

    async def _texto_norm(self) -> str:
        return _normalizar(" ".join(await self._textos_visibles()))

    async def _contar_avisos(self) -> dict:
        return _contar(await self._texto_norm())

    async def _esperar_sin_avisos(self, timeout: float = 4.0) -> bool:
        """Espera a que no quede ningún aviso en pantalla para que la línea base
        sea limpia (un aviso viejo que desaparece justo cuando aparece el nuevo
        ocultaría el resultado)."""
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            c = await self._contar_avisos()
            if c["exito"] == 0 and c["error"] == 0:
                return True
            await asyncio.sleep(0.1)
        return False

    async def _texto_con(self, frases) -> str:
        """Texto ORIGINAL (con tildes) del primer aviso visible que contiene
        alguna de las frases normalizadas."""
        for t in await self._textos_visibles():
            n = _normalizar(t)
            if any(f in n for f in frases):
                return " ".join(t.split())
        return ""

    async def _sesion_muerta(self) -> bool:
        try:
            return _requiere_reautenticacion(self.pagina) or await _pantalla_muestra_sesion_expirada(self.pagina)
        except Exception:
            return False

    async def _lanzar_si_sesion_expirada(self) -> None:
        if await self._sesion_muerta():
            raise SesionExpiradaError(
                "La sesión de Banner expiró (pantalla de error de autenticación externa). "
                "Hay que iniciar sesión de nuevo."
            )

    async def _asegurar_marco(self, selector: str, timeout_ms: int = 15000) -> None:
        self.marco = await _encontrar_frame(self.pagina, selector, timeout_ms=timeout_ms)

    # ------------------------------------------------------- abrir forma --

    async def abrir_forma(self) -> None:
        """Camino completo: recarga TODA la página, busca SSARRES, escribe el
        Periodo y deja la forma lista para escribir el NRC."""
        self.necesita_abrir = True
        p = self.pagina
        await p.goto(BANNER_URL, wait_until="domcontentloaded")

        if _requiere_reautenticacion(p):
            await self._lanzar_si_sesion_expirada()
        await p.wait_for_timeout(1500)
        await self._lanzar_si_sesion_expirada()

        try:
            await p.wait_for_selector(SELECTORES["busqueda_general"], timeout=30000)
        except PlaywrightTimeoutError:
            await self._lanzar_si_sesion_expirada()
            raise

        await p.wait_for_timeout(400)  # margen: Angular conecta sus manejadores
        if not await _tecleo_confiable(p, SELECTORES["busqueda_general"], NOMBRE_FORMA, self.log):
            raise RuntimeError(f'No se pudo escribir "{NOMBRE_FORMA}" en el buscador de forma confiable')
        await p.wait_for_timeout(2500)  # autocompletado

        try:
            sugerencia = p.locator(f"text={NOMBRE_FORMA}").filter(
                has_not=p.locator(SELECTORES["busqueda_general"])
            ).first
            if await sugerencia.is_visible(timeout=1500):
                await sugerencia.click()
            else:
                await p.keyboard.press("Enter")
        except Exception:
            await p.keyboard.press("Enter")

        try:
            await self._asegurar_marco(SELECTORES["campo_periodo"], timeout_ms=40000)
        except PlaywrightTimeoutError:
            await self._lanzar_si_sesion_expirada()
            raise
        await self.marco.wait_for_timeout(400)

        if not await _tecleo_confiable(self.marco, SELECTORES["campo_periodo"], self.periodo, self.log):
            raise RuntimeError(f'No se pudo escribir el periodo "{self.periodo}" de forma confiable')
        self.necesita_abrir = False
        self.log(f"Forma {NOMBRE_FORMA} abierta (periodo {self.periodo}).")

    async def recomenzar(self) -> None:
        """F5 ("Recomenzar"): vuelve a la pantalla Periodo/NRC; el Periodo se
        conserva. Si la cabecera no reaparece, lanza para que se recargue todo."""
        await self._tecla("F5")
        await self.pagina.wait_for_timeout(1000)
        await self._lanzar_si_sesion_expirada()
        await self._asegurar_marco(SELECTORES["campo_nrc"], timeout_ms=15000)
        try:
            await self.marco.wait_for_selector(SELECTORES["campo_nrc"], state="visible", timeout=10000)
        except Exception:
            await self._lanzar_si_sesion_expirada()
            raise

    async def recomenzar_seguro(self) -> None:
        """F5 tras un NRC ya resuelto: si falla, NO se pierde el resultado del
        NRC; solo se marca que el siguiente debe recargar la página completa."""
        try:
            await self.recomenzar()
        except Exception as err:
            self.log(f"  (F5 no devolvió la cabecera: {type(err).__name__}; el siguiente NRC recargará la página completa)")
            self.necesita_abrir = True

    # ----------------------------------------------------------- cargar NRC --

    async def _cargar_nrc(self, nrc: str) -> None:
        """Escribe el NRC, Alt+PageDown y espera el detalle. NRC inexistente ->
        NrcInexistenteError (error controlado)."""
        await self._asegurar_marco(SELECTORES["campo_nrc"], timeout_ms=15000)
        # El Periodo debería conservarse tras F5; si no, se vuelve a escribir.
        try:
            actual = await self.marco.locator(SELECTORES["campo_periodo"]).input_value(timeout=3000)
        except Exception:
            actual = None
        if actual != self.periodo:
            if not await _tecleo_confiable(self.marco, SELECTORES["campo_periodo"], self.periodo, self.log):
                raise RuntimeError(f'No se pudo escribir el periodo "{self.periodo}" de forma confiable')
        if not await _tecleo_confiable(self.marco, SELECTORES["campo_nrc"], nrc, self.log):
            raise RuntimeError(f'No se pudo escribir el NRC "{nrc}" de forma confiable')

        await self._esperar_sin_avisos(timeout=3.0)
        base = await self._contar_avisos()
        await self._tecla("Alt+PageDown")

        fin = time.monotonic() + ESPERA_DETALLE
        while time.monotonic() < fin:
            av = await self._contar_avisos()
            if av["nrc"] > base["nrc"]:
                texto = await self._texto_con(FRASES_NRC_INEXISTENTE) or "(sin texto)"
                raise NrcInexistenteError(f"NRC inexistente en el periodo {self.periodo}: Banner dijo «{texto}»")
            try:
                listo = await self.marco.evaluate(_JS_DETALLE_LISTO, SELECTORES["campo_nrc"])
            except Exception:
                listo = False
            if listo:
                await _pausa(ESPERA_TRAS_DETALLE)
                return
            await asyncio.sleep(0.15)
        await self._lanzar_si_sesion_expirada()
        raise RuntimeError(f"no cargó el detalle del NRC {nrc} (la cabecera no desapareció a tiempo)")

    # ------------------------------------------- llegar a la grilla Programa --

    async def _ir_por_clic(self) -> None:
        """Clic en la pestaña "Grado y programa" (la forma siempre arranca en
        "Departamento y campo de estudio") y clic en la primera línea de
        Restricciones de programa. Exige que el foco quede en la grilla de Programa."""
        try:
            await self.marco.locator('[role="tab"]', has_text="Grado y programa").first.click(timeout=4000)
        except Exception:
            await self.marco.get_by_text("Grado y programa", exact=True).first.click(timeout=4000)
        await asyncio.sleep(0.5)
        await self._enfocar_celda(posicion="primera")
        # Con 10 programas o menos Banner NO habilita «Por página» ni con el foco
        # dentro: el criterio de éxito es que el foco esté en la grilla de Programa.
        foco = await self._foco()
        if not (foco and foco["en_programa"]):
            raise RuntimeError("tras el clic en la primera línea, el foco no quedó en Restricciones de programa")

    async def _ir_a_grilla_programa(self) -> int:
        """Llega a la grilla de Programa. Devuelve 0 si ya estaba, -1 si fue por
        clic, o cuántos Alt+PageDown hicieron falta (respaldo)."""
        foco = await self._foco()
        if foco and foco["en_programa"]:
            return 0
        if USAR_CLIC_PRIMERO:
            try:
                await self._ir_por_clic()
                self.log("  Grilla de Programa alcanzada por clic (pestaña + primera línea)")
                return -1
            except Exception as err:
                self.log(f"  El clic no llegó a la grilla de Programa ({err}); se prueba con Alt+PageDown")
        for i in range(1, MAX_ALT_PGDN + 1):
            await self._tecla("Alt+PageDown")
            await asyncio.sleep(ESPERA_TRAS_ALT_PGDN)
            foco = await self._foco()
            if foco and foco["en_programa"]:
                self.log(f"  Grilla de Programa alcanzada con {i} Alt+PageDown")
                return i
        if USAR_CLIC_PRIMERO:
            raise RuntimeError("no se pudo llegar a la grilla de Programa (ni por clic ni con Alt+PageDown)")
        # Sin clic como primera opción, el clic es el último recurso.
        self.log("  Alt+PageDown no llegó a la grilla de Programa; se usa clic como respaldo")
        await self._ir_por_clic()
        return -1

    async def _enfocar_celda(self, codigo=None, posicion: str = "primera") -> dict:
        """Clic en la celda de código de una fila (por código, o la primera /
        última) y verificación de que el foco quedó en la grilla de Programa
        (y, si se pidió un código, SOBRE ese código)."""
        for intento in range(4):
            # Cada intento centra / alinea la fila de otra forma por si algo la tapa.
            bloque = ("center", "start", "end", "center")[intento]
            et = await self.marco.evaluate(
                _JS_ETIQUETAR, {"celda": {"codigo": codigo, "posicion": posicion, "bloque": bloque}}
            )
            if not et.get("celda"):
                if intento < 3:
                    await asyncio.sleep(0.4)
                    continue
                raise RuntimeError(
                    f"no se encontró la fila {'«' + codigo + '»' if codigo else posicion} en la grilla de Programa "
                    "(aun recorriéndola con scroll)"
                )
            try:
                libre = await self.marco.evaluate(_JS_CLIC_LIBRE)
            except Exception:
                libre = {"ok": True}   # la grilla se redibujó: el clic de abajo lo reintenta
            if not libre.get("ok"):
                self.log(f"  (la fila no está libre para el clic: {libre.get('motivo')}; se vuelve a desplazar)")
                await asyncio.sleep(0.3)
                continue
            try:
                await self.marco.locator('[data-auto="celda"]').click(timeout=2500)
            except Exception as err:
                # La grilla se redibujó entre marcar y hacer clic: se vuelve a localizar.
                self.log(f"  (clic en la fila no aplicado: {type(err).__name__}; se vuelve a localizar)")
                await asyncio.sleep(0.3)
                continue
            await asyncio.sleep(ESPERA_TRAS_CLIC)
            for _ in range(10):
                foco = await self._foco()
                if foco and foco["en_programa"]:
                    if codigo is None:
                        return foco
                    est = await self._estado(rapido=True)
                    if est and self._codigo_activo(est, foco) == codigo:
                        return foco
                await asyncio.sleep(0.15)
        raise RuntimeError(
            "el foco no quedó en la fila esperada de Programa tras hacer clic"
            + (f" (esperaba «{codigo}»)" if codigo else "")
        )

    # ------------------------------------------ Incluir / Por página / foto --

    @staticmethod
    def _verificar_incluir(est: dict) -> None:
        if est.get("incluir") != "true":
            detalle = "Excluir" if est.get("incluir") == "false" else "no se pudo leer"
            raise ModoExcluirError(
                f"Incluir/Excluir de Restricciones de programa no está en «Incluir» ({detalle}); "
                "no se tocó nada. Corrígelo a mano en Banner."
            )

    @staticmethod
    def _lectura_completa(est: dict) -> bool:
        """Las filas leídas coinciden con el contador «Registro x de N»."""
        total, n = est.get("total"), len(est["codigos"])
        return total is not None and (n == total or (total == 1 and n == 0)) and est.get("completa", True)

    async def _asegurar_por_pagina(self) -> dict:
        """Deja 'Por página' en POR_PAGINA SOLO si hace falta.
        - Con 10 programas o menos Banner deja el selector deshabilitado y no
          hace falta: ya se ven todos (siempre que la lectura coincida con el contador).
        - Tras elegir 50, Banner puede redibujar u ocultar el paginador: no se
          exige volver a leer el selector si la lista leída está completa."""
        cambio = False
        for _ in range(3):
            est = await self._estado_o_error(estricto=False)
            total, pp = est.get("total"), est.get("por_pagina")
            ya = pp == POR_PAGINA or (total is not None and pp is not None and total <= pp)
            if not ya and cambio and pp is None and self._lectura_completa(est):
                ya = True   # el paginador desapareció tras elegir 50, pero se ve todo
            if ya:
                if cambio:
                    # El select tomó el foco: se devuelve a la grilla.
                    await self._enfocar_celda(posicion="primera")
                    est = await self._estado_o_error(estricto=False)
                return est
            et = await self.marco.evaluate(_JS_ETIQUETAR, {"pager": True})
            if not et.get("pg-sel"):
                # Banner redibuja el paginador tras elegir 50 (o al cargar): se espera
                # a que reaparezca antes de darlo por perdido.
                for _ in range(12):
                    await asyncio.sleep(0.5)
                    est = await self._estado_o_error(estricto=False)
                    total, pp = est.get("total"), est.get("por_pagina")
                    if pp == POR_PAGINA or (total is not None and pp is not None and total <= pp):
                        break
                    et = await self.marco.evaluate(_JS_ETIQUETAR, {"pager": True})
                    if et.get("pg-sel"):
                        break
                if pp == POR_PAGINA or (total is not None and pp is not None and total <= pp):
                    continue
            habilitado = bool(et.get("pg-sel")) and not est.get("sel_disabled")
            if not habilitado:
                if self._lectura_completa(est) and total <= POR_PAGINA_BASE:
                    self.log(f"  {total} programa(s): «Por página» no se habilita y no hace falta; se ven todos")
                    return est
                if not et.get("pg-sel"):
                    raise RuntimeError("no se encontró el selector «Por página» de Restricciones de programa")
                # Deshabilitado con más de 10 programas: falta el foco en la sección.
                self.log("  («Por página» deshabilitado; se enfoca la primera línea y se reintenta)")
                await self._enfocar_celda(posicion="primera")
                await asyncio.sleep(0.5)
                continue
            try:
                await self.marco.locator('[data-auto="pg-sel"]').select_option(str(POR_PAGINA), timeout=5000)
                cambio = True
            except Exception as err:
                self.log(f"  («Por página» no disponible: {type(err).__name__}; se enfoca la grilla y se reintenta)")
                await self._enfocar_celda(posicion="primera")
            await asyncio.sleep(ESPERA_TRAS_POR_PAGINA)
        raise RuntimeError(f"no se pudo fijar {POR_PAGINA} registros por página")

    async def _click_pager(self, nombre: str) -> None:
        et = await self.marco.evaluate(_JS_ETIQUETAR, {"pager": True})
        if not et.get(nombre):
            raise RuntimeError(f"no se encontró el botón de paginación «{nombre}» (no se puede recorrer más de una página)")
        await self.marco.locator(f'[data-auto="{nombre}"]').click(timeout=5000)
        await asyncio.sleep(ESPERA_TRAS_CLIC)

    async def _esperar_firma_distinta(self, firma_anterior: tuple, timeout: float = 5.0) -> dict:
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            est = await self._estado()
            if est and tuple(est["codigos"]) != firma_anterior:
                return est
            await asyncio.sleep(0.15)
        raise RuntimeError("la grilla no cambió de página tras hacer clic en el paginador")

    async def _ir_a_pagina(self, destino: int) -> None:
        est = await self._estado_o_error()
        actual = est.get("pagina_actual")
        if actual is None:
            # Sin indicador de página: se va a la primera y se avanza contando.
            await self._click_pager("pg-first")
            actual = 1
            est = await self._estado_o_error()
        guarda = 0
        while actual != destino and guarda < 500:
            guarda += 1
            nombre = "pg-next" if actual < destino else "pg-prev"
            firma = tuple(est["codigos"])
            await self._click_pager(nombre)
            est = await self._esperar_firma_distinta(firma)
            actual += 1 if nombre == "pg-next" else -1
        if actual != destino:
            raise RuntimeError(f"no se pudo llegar a la página {destino} de la grilla")

    async def _leer_foto(self) -> tuple:
        """Todos los códigos de programa (todas las páginas). Devuelve
        (codigos, ubicacion) con ubicacion = {codigo: página}. Verifica que lo
        leído coincida con el contador «Registro x de N»: si no, ERROR (nunca se
        concluye «no está el programa» con una lectura incompleta)."""
        est = await self._estado_o_error(scroll=True)
        total = est.get("total")
        if total is None:
            raise RuntimeError("no se pudo leer el contador «Registro x de N» de Restricciones de programa")
        por_pagina = est.get("por_pagina") or POR_PAGINA
        paginas = max(1, math.ceil(total / por_pagina))

        if paginas == 1:
            codigos = est["codigos"]
            if not (len(codigos) == total or (total == 1 and not codigos)):
                raise RuntimeError(f"lectura incompleta de la grilla: {len(codigos)} filas leídas y el contador dice {total}")
            if len(set(codigos)) != len(codigos):
                raise RuntimeError(f"la grilla muestra códigos repetidos: {codigos}")
            return codigos, {c: 1 for c in codigos}

        self.log(f"  {total} programas en {paginas} páginas: se leen todas")
        await self._ir_a_pagina(1)
        todos, ubicacion = [], {}
        for pag in range(1, paginas + 1):
            if pag > 1:
                await self._ir_a_pagina(pag)
            e = await self._estado_o_error(scroll=True)
            for c in e["codigos"]:
                if c in ubicacion:
                    raise RuntimeError(f"el programa {c} apareció en dos páginas al leer la grilla")
                ubicacion[c] = pag
                todos.append(c)
        if len(todos) != total:
            raise RuntimeError(f"lectura incompleta de la grilla: {len(todos)} filas leídas y el contador dice {total}")
        return todos, ubicacion

    def _trazar(self, nrc: str, foto: list, conservar: list) -> None:
        """Guarda la foto previa en disco ANTES de borrar nada. Un reintento NO
        la sobrescribe (conserva la del primer intento)."""
        if nrc in _fotos_corrida:
            return
        _fotos_corrida[nrc] = list(foto)
        registrar_programas_iniciales(nrc, foto, conservar)
        self.log(f"  Programas iniciales guardados en la traza ({len(foto)}): {', '.join(foto) if foto else '(ninguno)'}")

    # ------------------------------------------------------------- borrado --

    @staticmethod
    def _codigo_activo(est: dict, foco) -> str:
        """Código de la fila ACTIVA de la grilla (la que borraría Shift+F6). Se
        prefiere la fila marcada como activa por SlickGrid; si no se puede
        saber, el valor del campo con foco."""
        for f in est["filas"]:
            if f.get("activa"):
                return (f["codigo"] or "").strip().upper()
        if foco and foco.get("tag") == "input":
            return (foco["value"] or "").strip().upper()
        return ""

    async def _esperar_borrado(self, total_antes, n_antes: int, timeout: float = 4.0) -> dict:
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            est = await self._estado(rapido=True)
            if est:
                bajo_total = est["total"] is not None and total_antes is not None and est["total"] < total_antes
                if bajo_total or (est.get("completa", True) and len(est["codigos"]) < n_antes):
                    return est
            await asyncio.sleep(0.1)
        raise RuntimeError("Shift+F6 no eliminó la fila (el contador y las filas no cambiaron)")


    async def _borrar_sobrantes(self, foto: list, conservar: list) -> list:
        """Shift+F6 sobre cada programa que NO está en `conservar`.

        Banner deja el foco en la fila SIGUIENTE al borrar, así que en cada
        vuelta se lee la fila ACTIVA (no se cuentan posiciones):
          - si es un sobrante -> Shift+F6 (SALVAGUARDA: nunca sobre un código a conservar);
          - si no (un código a conservar, o el foco se perdió) -> clic en el
            siguiente sobrante de la página actual, comprobando que quedó activo;
          - si la página actual ya no tiene sobrantes -> página siguiente.
        Las filas solo se mueven hacia páginas anteriores al borrar, por eso
        recorrer de la primera página hacia delante no se salta ninguna.
        Nada se guarda aquí: F10 viene después de verificar la lista completa."""
        a_conservar = set(conservar)
        pendientes = [c for c in foto if c not in a_conservar]
        iniciales = list(pendientes)
        borrados = []

        est0 = await self._estado_o_error(scroll=True)
        total0 = est0.get("total") or len(foto)
        if math.ceil(total0 / (est0.get("por_pagina") or POR_PAGINA)) > 1:
            await self._ir_a_pagina(1)

        tope = len(foto) * 4 + 20
        pasos = 0
        while pendientes:
            pasos += 1
            if pasos > tope:
                raise RuntimeError(
                    f"no se pudieron borrar los programas sobrantes (se agotó el tope de iteraciones; "
                    f"faltan {pendientes}); se aborta antes de guardar"
                )
            foco, est = await self._foco(), await self._estado(rapido=True)
            if not foco or not est:
                await asyncio.sleep(0.2)
                continue
            activo = self._codigo_activo(est, foco) if foco["en_programa"] else ""

            if activo and activo in pendientes:
                # SALVAGUARDA: Shift+F6 no pide confirmación y borra la fila ACTIVA.
                if activo in a_conservar:
                    raise RuntimeError(f"la fila activa «{activo}» es un programa a conservar; no se borra nada")
                if activo not in foto:
                    raise RuntimeError(f"fila inesperada «{activo}» (no estaba en la foto inicial); se aborta antes de guardar")
                total_antes, n_antes = est["total"], len(est["codigos"])
                await self._tecla("Shift+F6")
                await self._esperar_borrado(total_antes, n_antes)
                pendientes.remove(activo)
                borrados.append(activo)
                continue

            # El foco no está en un sobrante: se va al siguiente de esta página.
            completo = await self._estado_o_error(scroll=True)
            candidatos = [c for c in completo["codigos"] if c in pendientes]
            if candidatos:
                await self._enfocar_celda(codigo=candidatos[0])
                continue
            total = completo.get("total") or 0
            paginas = max(1, math.ceil(total / (completo.get("por_pagina") or POR_PAGINA)))
            pagina = completo.get("pagina_actual") or 1
            if pagina < paginas:
                await self._ir_a_pagina(pagina + 1)
                continue
            raise RuntimeError(f"no se encontraron en la grilla los programas por borrar: {pendientes}")

        if sorted(borrados) != sorted(iniciales):
            raise RuntimeError(
                f"lo borrado {sorted(borrados)} no coincide con lo previsto {sorted(iniciales)}; se aborta antes de guardar"
            )
        self.log(f"  Borrados {len(borrados)} programas sobrantes")
        return borrados

    # ------------------------------------------------------------------ F10 --

    async def _esperar_resultado_guardado(self, base: dict, textos_antes: set, timeout: float = 8.0):
        """(estado, detalle): 'ok' | 'error' | 'desconocido'.
        Solo cuenta un aviso ADICIONAL a los que ya había antes de F10."""
        vistos = []
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            textos = await self._textos_visibles()
            for t in textos:
                if t not in textos_antes and t not in vistos:
                    vistos.append(t)
            norm = _normalizar(" ".join(textos))
            c = _contar(norm)
            if c["error"] > base["error"]:
                errs = _errores_en(norm)
                return "error", (errs[-1][:140] if errs else "")
            if c["exito"] > base["exito"]:
                for t in vistos:
                    if any(f in _normalizar(t) for f in FRASES_EXITO):
                        return "ok", " ".join(t.split())
                return "ok", ""
            await asyncio.sleep(0.15)
        return "desconocido", " | ".join(" ".join(t.split()) for t in vistos)[:400]

    async def guardar(self) -> str:
        """F10 y lectura del mensaje REAL de Banner. Devuelve el texto de éxito.
        Desde que se pulsa F10 el estado de Banner puede haber cambiado: si no
        hay confirmación NO se reintenta (PostGuardadoError)."""
        if not await self._esperar_sin_avisos(timeout=4.0):
            self.log("  (hay un aviso viejo todavía visible antes de F10; se usa como línea base)")
        base = await self._contar_avisos()
        textos_antes = set(await self._textos_visibles())

        await self._tecla("F10")
        self._f10_hecho = True
        await _pausa(ESPERA_TRAS_F10)

        estado, detalle = await self._esperar_resultado_guardado(base, textos_antes)
        if estado == "ok":
            return detalle
        if estado == "error":
            # Banner rechazó el guardado con un *ERROR*: no se guardó nada.
            self._f10_hecho = False
            raise RuntimeError(f"Banner mostró un mensaje de error tras F10: «{detalle}»")
        visto = detalle or "(no apareció ningún texto nuevo en pantalla)"
        self.log(f"  [DIAG] texto nuevo en pantalla tras F10: {visto}")
        raise PostGuardadoError(
            "no se confirmó el guardado: ningún mensaje de éxito conocido tras F10. "
            f"Banner mostró: «{visto}». Verifica el NRC en Banner (la foto previa está en la traza). "
            "Si es un éxito con otra redacción, agrégala a FRASES_EXITO."
        )


    # ------------------------------------------------------------------ modo --

    async def _modo_conservar(self, nrc: str, foto: list, conservar: list) -> tuple:
        """Deja en el NRC únicamente los programas de `conservar`."""
        if not conservar:
            raise ValueError("no hay códigos de programa a conservar")   # la validación previa lo impide

        faltan = [c for c in conservar if c not in foto]
        if faltan:
            raise ProgramasFaltantesError(
                f"faltan programas a conservar: {', '.join(faltan)} no están en el NRC "
                f"(el NRC tiene {len(foto)} programas: {', '.join(foto) if foto else 'ninguno'}); no se tocó nada"
            )
        sobran = [c for c in foto if c not in conservar]
        if not sobran:
            return "sin_cambios", f"ya tenía únicamente los programas {', '.join(conservar)}"

        self._trazar(nrc, foto, conservar)
        borrados = await self._borrar_sobrantes(foto, conservar)

        # Verificación COMPLETA (todas las páginas) ANTES de guardar: si quedó
        # cualquier otra cosa, no se pulsa F10 (la página se recarga y se descartan los borrados).
        previo, _ = await self._leer_foto()
        if sorted(previo) != sorted(conservar):
            raise RuntimeError(
                f"tras borrar, la grilla quedó {sorted(previo)} y se esperaba {sorted(conservar)}; "
                "se aborta antes de guardar"
            )

        mensaje = await self.guardar()

        try:
            final, _ = await self._leer_foto()
        except Exception as err:
            raise PostGuardadoError(f"se guardó («{mensaje}») pero no se pudo verificar la lista final: {err}")
        if sorted(final) != sorted(conservar):
            raise PostGuardadoError(
                f"guardado con diferencias: quedó {sorted(final)} y se esperaba {sorted(conservar)}. "
                "Restaura desde la traza (programas_iniciales) si hace falta."
            )
        return "ok", f"quedaron solo {', '.join(conservar)} (se borraron {len(borrados)}; {mensaje})"

    # ------------------------------------------------------- un NRC completo --

    async def _intentar(self, nrc: str, conservar: list) -> tuple:
        """Un intento completo. Devuelve ('ok'|'sin_cambios', detalle)."""
        if self.necesita_abrir or self.marco is None:
            await self.abrir_forma()
        await self._cargar_nrc(nrc)
        await self._ir_a_grilla_programa()
        est = await self._estado_o_error()
        self._verificar_incluir(est)
        await self._asegurar_por_pagina()
        foto, _ubicacion = await self._leer_foto()
        self.log(f"  Programas actuales ({len(foto)}): {', '.join(foto) if foto else '(ninguno)'}")
        self.log(f"  Programas a conservar: {', '.join(conservar)}")
        return await self._modo_conservar(nrc, foto, conservar)

    async def _recuperar(self, requiere_recarga: bool) -> None:
        """Deja la pestaña limpia tras un resultado ya definido del NRC. Con
        cambios sin guardar (requiere_recarga) se recarga TODA la página."""
        try:
            if requiere_recarga:
                self.necesita_abrir = True
                await asyncio.wait_for(self.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
            else:
                await self.recomenzar()
        except Exception as err:
            self.log(f"  (recuperación: {type(err).__name__}: {err}; el siguiente NRC recargará la página completa)")
            self.necesita_abrir = True

    async def procesar_con_reintentos(self, clave: str):
        """Devuelve (estado, dato): 'ok' / 'sin_cambios' (dato = detalle),
        'controlado' / 'post' (dato = excepción), 'fallo' (dato = excepción),
        'sesion_expirada' (dato = excepción).
        Escalera ANTES de F10: intento -> falla -> recargar página completa ->
        reintento. DESPUÉS de F10 no se reintenta nunca.
        `clave` es la línea «NRC,código,código»."""
        nrc, conservar = separar_clave(clave)
        ultimo_error = None
        for intento in range(MAX_INTENTOS_POR_NRC):
            self._f10_hecho = False
            try:
                estado, detalle = await asyncio.wait_for(self._intentar(nrc, conservar), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
                await self.recomenzar_seguro()
                return estado, detalle

            except ErrorControlado as err:
                self.log(f"  {type(err).__name__}: {err}")
                if err.requiere_recarga:
                    ruta = await _guardar_captura_error(self.pagina, f"ssarres_conservar_{nrc}")
                    if ruta:
                        self.log(f"  (captura: {ruta})")
                await self._recuperar(err.requiere_recarga)
                return "controlado", err

            except PostGuardadoError as err:
                self.log(f"  *** DESPUÉS DE F10: {err}")
                ruta = await _guardar_captura_error(self.pagina, f"ssarres_conservar_post_{nrc}")
                if ruta:
                    self.log(f"  (captura: {ruta})")
                await self._recuperar(True)
                return "post", err

            except asyncio.TimeoutError:
                if self._f10_hecho:
                    err = PostGuardadoError(
                        f"se agotó el límite de {LIMITE_SEGUNDOS_POR_INTENTO}s DESPUÉS de pulsar F10: "
                        "verifica el NRC en Banner (la foto previa está en la traza)"
                    )
                    await self._recuperar(True)
                    return "post", err
                ultimo_error = RuntimeError(
                    f"se agotó el límite de {LIMITE_SEGUNDOS_POR_INTENTO}s para este intento (posible cuelgue)"
                )
                self.log(f"  intento {intento + 1}/{MAX_INTENTOS_POR_NRC} falló: {ultimo_error}")

            except Exception as err:
                if isinstance(err, SesionExpiradaError) or await self._sesion_muerta():
                    return "sesion_expirada", SesionExpiradaError(str(err))
                if self._f10_hecho:
                    post = PostGuardadoError(f"falló DESPUÉS de pulsar F10 ({err}): verifica el NRC en Banner")
                    self.log(f"  *** {post}")
                    await self._recuperar(True)
                    return "post", post
                ultimo_error = err
                ruta = await _guardar_captura_error(self.pagina, f"ssarres_conservar_{nrc}")
                self.log(
                    f"  intento {intento + 1}/{MAX_INTENTOS_POR_NRC} falló: {type(err).__name__}: {err}"
                    + (f" (captura: {ruta})" if ruta else "")
                )
                self.log(f"  {await self._diag_estado()}")

            # Recuperación ANTES de F10 (nada se guardó): recargar la página
            # completa y volver a entrar a la forma (también tras el último
            # intento, para que el siguiente NRC empiece sobre pantalla limpia).
            ultimo = intento == MAX_INTENTOS_POR_NRC - 1
            self.log("  Se agotaron los intentos de este NRC; recargando la página para continuar..." if ultimo
                     else "  Recargando la página completa y reintentando...")
            try:
                await asyncio.wait_for(self.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
            except SesionExpiradaError as e2:
                return "sesion_expirada", e2
            except Exception as e2:
                if not isinstance(e2, asyncio.TimeoutError) and await self._sesion_muerta():
                    return "sesion_expirada", SesionExpiradaError(str(e2))
                if not ultimo:
                    ultimo_error = e2
                else:
                    self.log(f"  ADVERTENCIA: falló la recarga tras agotar los intentos: {e2}")
                self.necesita_abrir = True
                await self._reabrir_pagina_si_hace_falta()
        return "fallo", ultimo_error

    async def reabrir_pagina(self) -> None:
        """Cierra esta pestaña y abre una nueva (misma sesión de login)."""
        try:
            await asyncio.wait_for(self.pagina.close(), timeout=10)
        except Exception:
            pass
        if self.contexto is None:
            raise RuntimeError("no hay contexto para reabrir la pestaña")
        self.pagina = await asyncio.wait_for(_pagina_nueva(self.contexto), timeout=15)
        self.marco = None
        self.necesita_abrir = True

    async def _reabrir_pagina_si_hace_falta(self) -> None:
        try:
            if not self.pagina.is_closed():
                return
        except Exception:
            pass
        if self.contexto is None:
            return
        try:
            self.pagina = await _pagina_nueva(self.contexto)
            self.marco = None
            self.necesita_abrir = True
        except Exception as err:
            self.log(f"  (no se pudo reabrir la pestaña: {err})")


# ------------------------------------------------------------------
# TRABAJADOR (una pestaña) Y LOOP PRINCIPAL
# ------------------------------------------------------------------

async def _trabajador_ssarres_conservar(
    indice: int,
    contexto,
    cola: "asyncio.Queue[str]",
    periodo: str,
    estado_corrida,
    control,
    evento_detener: asyncio.Event,
    estado_compartido: dict,
    on_log,
    on_progreso,
    on_resumen=None,
):
    """Procesa líneas «NRC,código,código» de la cola compartida una a una, en su propia pestaña, hasta
    que la cola se vacía, se cancela la corrida o se activa evento_detener."""
    resumen = on_resumen if on_resumen is not None else on_log
    etiqueta = f"[Pestaña {indice + 1}]"

    def log(mensaje: str):
        on_log(f"{etiqueta} {mensaje}")

    def r(mensaje: str, segundos: float = None):
        if MOSTRAR_PESTANA_EN_RESUMEN:
            extra = f" ({segundos:.1f} s)" if segundos is not None else ""
            resumen(f"{etiqueta} {mensaje}{extra}")
        else:
            resumen(mensaje)

    def progreso(clave: str):
        on_progreso(clave, len(estado_corrida.procesados), len(estado_corrida.pendientes), len(estado_corrida.fallos))

    log("Pestaña iniciada.")
    pagina = await _pagina_nueva(contexto)
    ventana = VentanaSSARRESConservar(pagina, log, periodo, contexto=contexto)

    async def _pestana_se_rinde(sesion_muerta: bool) -> None:
        if not sesion_muerta:
            estado_compartido["fallo_no_sesion"] = True
        if estado_compartido["tabs_vivas"] > 1:
            log("Esta pestaña no pudo trabajar; se retira. Las demás pestañas continúan.")
            return
        if sesion_muerta and not estado_compartido["fallo_no_sesion"]:
            invalidar_sesion()
            resumen("Error - sesión de Banner expirada, corrida detenida")
        else:
            resumen(f"Error - no se pudo abrir {NOMBRE_FORMA}, corrida detenida")
        evento_detener.set()

    def _marcar_error(clave: str, motivo: str, duracion: float, cuenta_para_corte: bool):
        nrc = separar_clave(clave)[0]
        registrar_nrc_error(clave, motivo)
        estado_corrida.marcar_fallo(clave, motivo)
        log(f"*** NRC {nrc}: ERROR - {motivo} ***")
        r(f"NRC {nrc}: Error - {motivo}", duracion)
        progreso(clave)
        if cuenta_para_corte:
            estado_compartido["fallos_seguidos"] += 1
            if estado_compartido["fallos_seguidos"] >= MAX_FALLOS_SEGUIDOS:
                log(
                    f"Fallaron {MAX_FALLOS_SEGUIDOS} NRCs seguidos: Banner parece no estar "
                    "respondiendo. Deteniendo toda la corrida."
                )
                evento_detener.set()

    try:
        # Entrada inicial: intento -> intento (tras pausa) -> intento sobre una
        # pestaña NUEVA (mismo patrón que SSASECT / STVBLCK).
        listo = False
        ultimo_error = None
        t_inicio = time.monotonic()
        for intento in range(3):
            try:
                if intento == 2:
                    log("Reabriendo la pestaña para un último intento...")
                    await ventana.reabrir_pagina()
                await asyncio.wait_for(ventana.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
                listo = True
                break
            except Exception as err:
                ultimo_error = err
                if isinstance(err, SesionExpiradaError):
                    log(f"Pantalla de sesión/autenticación al abrir {NOMBRE_FORMA} (intento {intento + 1}/3): {err}")
                else:
                    log(f"No se pudo abrir {NOMBRE_FORMA} (intento {intento + 1}/3): {err}")
                await asyncio.sleep(2 + indice)
        if listo:
            r(f"Pestaña lista ({NOMBRE_FORMA} abierto)", time.monotonic() - t_inicio)
        else:
            sesion_muerta = isinstance(ultimo_error, SesionExpiradaError) or await ventana._sesion_muerta()
            await _pestana_se_rinde(sesion_muerta)
            return

        while not evento_detener.is_set() and not control.cancelado:
            while control.pausado and not control.cancelado and not evento_detener.is_set():
                await asyncio.sleep(0.3)
            if control.cancelado or evento_detener.is_set():
                break

            try:
                clave = cola.get_nowait()
            except asyncio.QueueEmpty:
                log("Sin más NRCs en la cola - esta pestaña terminó su parte.")
                break

            nrc = separar_clave(clave)[0]
            log(f"--- Procesando NRC {nrc} ---")
            t0 = time.monotonic()
            estado, dato = await ventana.procesar_con_reintentos(clave)
            duracion = time.monotonic() - t0

            if estado in ("ok", "sin_cambios"):
                estado_compartido["fallos_seguidos"] = 0
                estado_corrida.marcar_exito(clave)
                if estado == "sin_cambios":
                    log(f"NRC {nrc}: OK sin cambios ({dato}) ({duracion:.1f} s)")
                    r(f"NRC {nrc}: Procesado (sin cambios: {dato})", duracion)
                else:
                    log(f"NRC {nrc}: OK ({dato}) ({duracion:.1f} s)")
                    r(f"NRC {nrc}: Procesado", duracion)
                progreso(clave)

            elif estado == "controlado":
                _marcar_error(clave, str(dato), duracion, getattr(dato, "cuenta_para_corte", False))

            elif estado == "post":
                _marcar_error(clave, str(dato), duracion, True)

            elif estado == "sesion_expirada":
                # Puede ser un hipo pasajero del SSO en ESTA pestaña. El NRC
                # vuelve a la cola (no se marca como fallo) y la pestaña intenta
                # recuperarse; si falla repetidamente con el mismo NRC, se marca.
                veces = estado_compartido["reintentos_sesion"].get(clave, 0) + 1
                estado_compartido["reintentos_sesion"][clave] = veces
                if veces > 2:
                    _marcar_error(clave, f"sesión/autenticación falló repetidamente al procesar este NRC: {dato}", duracion, False)
                else:
                    cola.put_nowait(clave)
                log("Pantalla de sesión/autenticación detectada; se intenta recuperar esta pestaña...")
                recuperada = False
                for intento_rec in range(2):
                    try:
                        await ventana.reabrir_pagina()
                        await asyncio.wait_for(ventana.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
                        recuperada = True
                        break
                    except Exception as err:
                        log(f"  recuperación {intento_rec + 1}/2 falló: {err}")
                        await asyncio.sleep(2 + indice)
                if recuperada:
                    log("Pestaña recuperada; se continúa.")
                    continue
                await _pestana_se_rinde(True)
                break

            else:  # "fallo"
                _marcar_error(clave, f"fallo tras {MAX_INTENTOS_POR_NRC} intentos: {dato}", duracion, True)
    finally:
        estado_compartido["tabs_vivas"] -= 1
        try:
            await ventana.pagina.close()
        except Exception:
            pass


async def ejecutar_lote_ssarres_conservar(
    periodo: str,
    lineas: list,
    estado_corrida,
    control,
    on_log,
    on_progreso,
    num_pestanas: int = NUM_PESTANAS,
    on_resumen=None,
    headless: bool = None,
    preparar_contexto=None,
) -> None:
    """Procesa las líneas «NRC,código,código» (una por NRC): deja en cada NRC solo
    esos programas. `headless=False` abre una ventana visible (para depurar); si no
    se indica, depende de MOSTRAR_NAVEGADOR. `preparar_contexto` es un gancho
    SOLO PARA PRUEBAS (async callable(contexto), p. ej. un Banner simulado)."""
    # Defensa en profundidad: aunque la app ya validó, aquí se vuelve a validar y
    # NO se arranca nada si alguna línea no cumple.
    claves, errores, _repetidas = validar_lineas(lineas)
    if errores:
        raise ValueError("Líneas inválidas: " + " | ".join(errores[:5]))
    lineas = claves
    if headless is None:
        headless = not MOSTRAR_NAVEGADOR
    _reiniciar_registros()
    resumen = on_resumen if on_resumen is not None else on_log
    ruta = ruta_sesion()
    resumen("Inicializando...")

    if PARALELO_HABILITADO:
        n_pestanas = max(1, num_pestanas) if len(lineas) > UMBRAL_PARALELO else 1
    else:
        n_pestanas = 1
        if num_pestanas > 1 and len(lineas) > UMBRAL_PARALELO:
            on_log("SSARRES (dejar solo programas): el paralelo aún no está validado para esta función; se usa 1 pestaña.")
    if n_pestanas > 1:
        on_log(f"{len(lineas)} NRCs: se procesan en paralelo con {n_pestanas} pestañas.")

    cola: "asyncio.Queue[str]" = asyncio.Queue()
    for clave in lineas:
        cola.put_nowait(clave)

    evento_detener = asyncio.Event()
    estado_compartido = {
        "fallos_seguidos": 0,
        "tabs_vivas": n_pestanas,
        "fallo_no_sesion": False,
        "reintentos_sesion": {},
    }

    async with async_playwright() as p:
        navegador = await p.chromium.launch(headless=headless)
        contexto = await navegador.new_context(
            storage_state=ruta, locale="es-PE", viewport={"width": VIEWPORT_ANCHO, "height": VIEWPORT_ALTO}
        )
        if preparar_contexto is not None:
            await preparar_contexto(contexto)
        tareas = []
        for i in range(n_pestanas):
            tareas.append(asyncio.create_task(_trabajador_ssarres_conservar(
                i, contexto, cola, periodo, estado_corrida, control, evento_detener,
                estado_compartido, on_log, on_progreso, on_resumen=resumen,
            )))
            if i < n_pestanas - 1:
                await asyncio.sleep(1.5)  # no saturar el arranque de golpe
        await asyncio.gather(*tareas)
        await navegador.close()

    if evento_detener.is_set() and not control.cancelado:
        if not hay_sesion_guardada():
            resumen("Corrida detenida por sesión expirada. Vuelve a abrir la app e inicia sesión con Google antes de reintentar.")
        else:
            resumen("La corrida se detuvo antes de terminar todos los NRCs: Banner dejó de responder. Revisa el sistema e intenta de nuevo más tarde.")
    resumen(
        f"Resumen: {len(estado_corrida.procesados)} procesados, "
        f"{len(estado_corrida.fallos)} fallidos, {len(estado_corrida.pendientes)} pendientes."
    )
    if _fotos_corrida and os.path.exists(ruta_csv_traza()):
        resumen(f"Programas iniciales de los NRC modificados (para restaurar): {ruta_csv_traza()}")
    if estado_corrida.fallos and hay_errores_en_corrida():
        resumen(f"NRCs con error (TXT para reimportar): {ruta_txt_errores()}")
        resumen(f"NRCs con error con motivo (CSV): {ruta_csv_errores()}")


# ------------------------------------------------------------------
# EJECUCIÓN POR LÍNEA DE COMANDOS (validar en visible antes de usar la app)
# ------------------------------------------------------------------

def _cli() -> None:
    import argparse

    ap = argparse.ArgumentParser(
        description="Deja en cada NRC de SSARRES (Restricciones de programa) solo los programas indicados, sin la interfaz."
    )
    ap.add_argument("periodo", help="periodo de 6 dígitos, ej. 202620")
    ap.add_argument("archivo", help="CSV, Excel o TXT: NRC en la primera columna y los códigos a conservar en las siguientes")
    ap.add_argument("--visible", action="store_true", help="abre una ventana de Chrome visible")
    ap.add_argument("--pestanas", type=int, default=1, help="pestañas en paralelo (solo si PARALELO_HABILITADO = True)")
    args = ap.parse_args()

    if not (args.periodo.isdigit() and len(args.periodo) == 6):
        sys.exit("El periodo debe tener exactamente 6 dígitos.")
    if not hay_sesion_guardada():
        sys.exit("No hay sesión guardada: abre la app (python main.py) e inicia sesión con Google primero.")

    try:
        lineas, repetidas = leer_pares_de_archivo(args.archivo)
    except ValueError as err:
        sys.exit(f"No se inicia nada: {err}")
    if repetidas:
        print(f"(se descartaron {repetidas} líneas repetidas del archivo)")
    print(f"{len(lineas)} NRCs a procesar.")

    class _Control:
        pausado = False
        cancelado = False

    estado = EstadoCorrida(ACCION, lineas)
    asyncio.run(ejecutar_lote_ssarres_conservar(
        periodo=args.periodo,
        lineas=lineas,
        estado_corrida=estado,
        control=_Control(),
        on_log=lambda m: print(f"[{datetime.now():%H:%M:%S}] {m}", flush=True),
        on_progreso=lambda *a: None,
        num_pestanas=args.pestanas,
        headless=not args.visible,
    ))


if __name__ == "__main__":
    _cli()
