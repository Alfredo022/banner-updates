# src/formato_fallos.py
"""
Presentación legible de los fallos de SFABRDF (sin dependencias de interfaz,
para poder probarlo aparte).

Cada línea del archivo de fallos se guarda como:

    [2026-10-23 10:59:12] 14,PG,S01,113,MAJOR,UREG,ICNM,S01PR11311 - <motivo técnico>

Aquí se convierte en una ficha con cada valor etiquetado y el motivo explicado
en lenguaje claro, dejando el detalle técnico aparte (para soporte).
"""

import re

# Misma posición que las 8 columnas del CSV de reglas.
ETIQUETAS_CAMPOS = [
    "Prioridad",
    "Nivel",
    "Campus",
    "Programa",
    "Tipo de campo",
    "Departamento",
    "Atributo",
    "Bloque",
]

_PATRON_LINEA = re.compile(r"^\[(?P<fecha>[^\]]+)\]\s*(?P<clave>.*?)\s+-\s+(?P<motivo>.*)$", re.S)


def _entre_comillas(texto: str) -> str:
    m = re.search(r"«(.*?)»", texto, re.S)
    return " ".join(m.group(1).split()) if m else ""


def motivo_legible(motivo: str) -> str:
    """Motivo técnico -> explicación para el usuario."""
    original = " ".join(motivo.split())
    bajo = original.lower()

    if bajo.startswith("duplicado"):
        texto = "DUPLICADA: esta regla ya existe en Banner, no hace falta volver a crearla."
        if "tras reintento" in bajo:
            texto += (
                " Salió en un reintento, así que probablemente SÍ se guardó bien en el primer "
                "intento: verifícala en Banner."
            )
        return texto

    if "línea inválida" in bajo or "linea inválida" in bajo:
        return "La línea no tiene los 8 campos requeridos (Prioridad, Nivel, Campus, Programa, Tipo de campo, Departamento, Atributo, Bloque)."

    if "banner mostró un mensaje de error" in bajo:
        detalle = _entre_comillas(original)
        return "Banner RECHAZÓ la regla" + (f" y dijo: «{detalle}»." if detalle else ".")

    if "no se confirmó el guardado" in bajo:
        detalle = _entre_comillas(original)
        base = "No se pudo CONFIRMAR que Banner guardara la regla (no apareció un mensaje de éxito reconocido)."
        if detalle:
            base += f" Banner mostró: «{detalle}»."
        return base + " Verifica en Banner si quedó guardada antes de reintentarla."

    if "fila incompleta" in bajo or "no se pudieron llenar" in bajo:
        return (
            "No se pudieron llenar todos los campos de la fila: Banner no aceptó o borró algún valor. "
            "Revisa que Nivel, Campus, Programa, Tipo de campo, Departamento y Atributo existan en Banner."
        )

    if "campo bloque" in bajo:
        return "No se pudo escribir el código de Bloque en Banner."

    if "límite de" in bajo or "se agotó el límite" in bajo:
        return "Banner tardó demasiado en responder; se cortó la regla."

    if "sesión" in bajo and "autentic" in bajo:
        return "Problema de sesión con Banner. Vuelve a iniciar sesión y reintenta."

    if "grilla inferior" in bajo or "foco no regres" in bajo or "foco no regresa" in bajo or "tras varios intentos de f6" in bajo:
        return "Banner no volvió a la grilla de reglas a tiempo; la regla se omitió sin guardarse."

    return "Error: " + original[:250]


def _detalle_tecnico(motivo: str) -> str:
    """Motivo técnico original, recortado; solo se muestra si aporta algo más
    que la explicación (los duplicados no lo necesitan)."""
    original = " ".join(motivo.split())
    if original.lower().startswith("duplicado"):
        return ""
    return original[:300]


def parsear_linea_fallo(linea: str) -> dict:
    """Línea del archivo de fallos -> {fecha, clave, campos, motivo}. Si no
    respeta el formato, devuelve la línea cruda en 'clave'."""
    m = _PATRON_LINEA.match(linea.strip())
    if not m:
        return {"fecha": "", "clave": linea.strip(), "campos": None, "motivo": ""}
    clave = m.group("clave").strip()
    campos = [c.strip() for c in clave.split(",")]
    return {
        "fecha": m.group("fecha").strip(),
        "clave": clave,
        "campos": campos if len(campos) == len(ETIQUETAS_CAMPOS) else None,
        "motivo": m.group("motivo").strip(),
    }


def formatear_fallos_sfabrdf(lineas: list) -> tuple:
    """Devuelve (texto_legible, claves). `claves` son las reglas con error que
    tiene sentido REINTENTAR, en el formato de 8 campos separados por coma, listas
    para pegar en la app (se excluyen los duplicados y las líneas inválidas)."""
    if not lineas:
        return "Sin fallos registrados todavía.", []

    bloques, claves = [], []
    for n, linea in enumerate(lineas, start=1):
        d = parsear_linea_fallo(linea)
        hora = d["fecha"].split(" ")[-1] if d["fecha"] else ""
        if d["campos"]:
            c = d["campos"]
            titulo = f"{n}) Bloque {c[7]}  ·  Prioridad {c[0]}" + (f"   [{hora}]" if hora else "")
            valores = "     ".join(f"{et}: {v}" for et, v in zip(ETIQUETAS_CAMPOS[1:7], c[1:7]))
            if not d["motivo"].lower().startswith("duplicado"):
                claves.append(d["clave"])
        else:
            titulo = f"{n}) Regla «{d['clave']}»" + (f"   [{hora}]" if hora else "")
            valores = ""
        partes = [titulo]
        if valores:
            partes.append(f"     {valores}")
        if d["motivo"]:
            partes.append(f"     ► {motivo_legible(d['motivo'])}")
            tecnico = _detalle_tecnico(d["motivo"])
            if tecnico and not motivo_legible(d["motivo"]).startswith("Error: "):
                partes.append(f"     (detalle técnico: {tecnico})")
        bloques.append("\n".join(partes))
    return "\n\n".join(bloques), claves


# ------------------------------------------------------------------
# STVBLCK (Validación de código de bloque): la "clave" de cada fallo es solo
# el código de bloque (una línea = un código).
#
#     [2026-10-23 16:20:05] F02ST99999 - <motivo técnico>
# ------------------------------------------------------------------

def motivo_legible_stvblck(motivo: str) -> str:
    """Motivo técnico de STVBLCK -> explicación para el usuario."""
    original = " ".join(motivo.split())
    bajo = original.lower()

    if bajo.startswith("inserción rechazada") or bajo.startswith("insercion rechazada"):
        texto = (
            "RECHAZADO por Banner (\"Failed to insert record\"). Lo más probable es que el código "
            "ya exista en STVBLCK; Banner usa el mismo aviso para otros rechazos, así que "
            "verifica en la forma antes de reintentarlo."
        )
        if "tras reintento" in bajo:
            texto += (
                " Salió en un reintento, así que probablemente SÍ se guardó bien en el primer "
                "intento: verifícalo en Banner."
            )
        return texto

    if "banner mostró un mensaje de error" in bajo:
        detalle = _entre_comillas(original)
        return "Banner RECHAZÓ el código" + (f" y dijo: «{detalle}»." if detalle else ".")

    if "no se confirmó el guardado" in bajo:
        detalle = _entre_comillas(original)
        base = "No se pudo CONFIRMAR que Banner guardara el código (no apareció un mensaje de éxito reconocido)."
        if detalle:
            base += f" Banner mostró: «{detalle}»."
        return base + " Verifica en Banner si quedó guardado antes de reintentarlo."

    if "fila incompleta" in bajo or "no se pudieron llenar" in bajo:
        return "No se pudo llenar el Código y la Descripción de la fila; el código se omitió sin guardarse."

    if "límite de" in bajo or "se agotó el límite" in bajo:
        return "Banner tardó demasiado en responder; se cortó el código."

    if "sesión" in bajo and "autentic" in bajo:
        return "Problema de sesión con Banner. Vuelve a iniciar sesión y reintenta."

    if "f6" in bajo and "fila" in bajo:
        return "Banner no insertó la fila nueva a tiempo; el código se omitió sin guardarse."

    return "Error: " + original[:250]


def formatear_fallos_stvblck(lineas: list) -> tuple:
    """Devuelve (texto_legible, claves). `claves` son los códigos con error que
    tiene sentido REINTENTAR, uno por línea, listos para pegar en la app (se
    excluyen los rechazados por Banner: lo más probable es que ya existan)."""
    if not lineas:
        return "Sin fallos registrados todavía.", []

    bloques, claves = [], []
    for n, linea in enumerate(lineas, start=1):
        d = parsear_linea_fallo(linea)
        hora = d["fecha"].split(" ")[-1] if d["fecha"] else ""
        titulo = f"{n}) Bloque {d['clave']}" + (f"   [{hora}]" if hora else "")
        partes = [titulo]
        if d["motivo"]:
            legible = motivo_legible_stvblck(d["motivo"])
            partes.append(f"     ► {legible}")
            if not legible.startswith(("Error: ", "RECHAZADO")):
                partes.append(f"     (detalle técnico: {' '.join(d['motivo'].split())[:300]})")
            if not d["motivo"].lower().startswith(("inserción rechazada", "insercion rechazada")):
                claves.append(d["clave"])
        else:
            claves.append(d["clave"])
        bloques.append("\n".join(partes))
    return "\n\n".join(bloques), claves

# ------------------------------------------------------------------
# SSARRES (Restricciones de horario, sección de programa): la "clave" de cada
# fallo es solo el NRC (una línea = un NRC).
#
#     [2026-10-26 12:10:05] 33278 - <motivo técnico>
# ------------------------------------------------------------------

def motivo_legible_ssarres(motivo: str) -> str:
    """Motivo técnico de SSARRES -> explicación para el usuario."""
    original = " ".join(motivo.split())
    bajo = original.lower()

    if bajo.startswith("nrc inexistente"):
        detalle = _entre_comillas(original)
        return (
            "El NRC NO EXISTE en ese periodo"
            + (f" (Banner dijo: «{detalle}»)" if detalle else "")
            + ". Revisa el NRC y el periodo; no se tocó nada."
        )

    if "incluir/excluir" in bajo:
        return (
            "La restricción de programa está en «Excluir» (o no se pudo leer). El script solo trabaja con "
            "«Incluir», así que NO se tocó nada. Corrígelo a mano en Banner si corresponde."
        )

    if "único programa" in bajo or "unico programa" in bajo:
        return (
            "El 502 es el ÚNICO programa del NRC: quitarlo dejaría el NRC abierto a todos los programas, "
            "así que NO se tocó. Revísalo a mano."
        )

    if "pero no se pudo verificar la lista final" in bajo:
        return (
            "El guardado SE HIZO pero no se pudo verificar la lista final. Revisa el NRC en Banner y, si hace "
            "falta, restaura desde el CSV «programas_iniciales» de la carpeta datos/logs/ssarres."
        )

    if "guardado con diferencias" in bajo:
        return (
            "El guardado SE HIZO pero la lista final no es la esperada. Revisa el NRC en Banner y, si hace falta, "
            "restaura los programas desde el CSV «programas_iniciales» de la carpeta datos/logs/ssarres."
        )

    if "no se confirmó el guardado" in bajo:
        detalle = _entre_comillas(original)
        base = "No se pudo CONFIRMAR el guardado (no apareció un mensaje de éxito reconocido)."
        if detalle:
            base += f" Banner mostró: «{detalle}»."
        return base + " Verifica el NRC en Banner (los programas originales están en «programas_iniciales»)."

    if "después de pulsar f10" in bajo or "despues de pulsar f10" in bajo or "después de f10" in bajo:
        return (
            "Falló DESPUÉS de pulsar F10, así que el cambio pudo haberse guardado. No se reintentó. "
            "Verifica el NRC en Banner (los programas originales están en «programas_iniciales»)."
        )

    if "banner mostró un mensaje de error" in bajo:
        detalle = _entre_comillas(original)
        return "Banner RECHAZÓ el guardado" + (f" y dijo: «{detalle}»." if detalle else ".") + " No se guardó nada."

    if "límite de" in bajo or "se agotó el límite" in bajo:
        return "Banner tardó demasiado en responder; se cortó el NRC."

    if "sesión" in bajo and "autentic" in bajo:
        return "Problema de sesión con Banner. Vuelve a iniciar sesión y reintenta."

    if "lectura incompleta" in bajo or "códigos repetidos" in bajo or "contador" in bajo:
        return (
            "No se pudo leer completa la lista de programas, así que por seguridad NO se modificó nada. "
            "Reintenta; si se repite, avisa para revisar la grilla."
        )

    if "grilla de programa" in bajo or "alt+pagedown" in bajo or "por página" in bajo or "no cargó el detalle" in bajo:
        return "Banner no llegó a la grilla de Restricciones de programa a tiempo; el NRC se omitió sin guardarse."

    return "Error: " + original[:250]


# Motivos que NO tiene sentido reintentar sin corregir antes el dato o Banner
# (se buscan DENTRO del motivo, no solo al principio).
_NO_REINTENTAR_SSARRES = (
    "nrc inexistente", "incluir/excluir", "único programa", "unico programa",
)


def formatear_fallos_ssarres(lineas: list) -> tuple:
    """Devuelve (texto_legible, claves). `claves` son los NRC con error que tiene
    sentido REINTENTAR (uno por línea, listos para pegar en la app); se excluyen
    NRC inexistentes, los que están en «Excluir» y los que solo tienen el 502."""
    if not lineas:
        return "Sin fallos registrados todavía.", []

    bloques, claves = [], []
    for n, linea in enumerate(lineas, start=1):
        d = parsear_linea_fallo(linea)
        hora = d["fecha"].split(" ")[-1] if d["fecha"] else ""
        partes = [f"{n}) NRC {d['clave']}" + (f"   [{hora}]" if hora else "")]
        if d["motivo"]:
            legible = motivo_legible_ssarres(d["motivo"])
            partes.append(f"     ► {legible}")
            if not legible.startswith("Error: "):
                partes.append(f"     (detalle técnico: {' '.join(d['motivo'].split())[:300]})")
            if not any(m in d["motivo"].lower() for m in _NO_REINTENTAR_SSARRES):
                claves.append(d["clave"])
        else:
            claves.append(d["clave"])
        bloques.append("\n".join(partes))
    return "\n\n".join(bloques), claves


# ------------------------------------------------------------------
# SSARRES, pestaña "Atributo y cohorte de alumno" (quitar un atributo, p. ej. P015): la
# "clave" de cada fallo es solo el NRC (una línea = un NRC). Funciones PROPIAS,
# independientes de las de programas de arriba.
#
#     [2026-10-26 19:10:05] 9617 - <motivo técnico>
# ------------------------------------------------------------------

def motivo_legible_ssarres_atributo(motivo: str) -> str:
    """Motivo técnico de SSARRES (atributo) -> explicación para el usuario."""
    original = " ".join(motivo.split())
    bajo = original.lower()

    if bajo.startswith("nrc inexistente"):
        detalle = _entre_comillas(original)
        return (
            "El NRC NO EXISTE en ese periodo"
            + (f" (Banner dijo: «{detalle}»)" if detalle else "")
            + ". Revisa el NRC y el periodo; no se tocó nada."
        )

    if "incluir/excluir" in bajo:
        return (
            "La restricción de atributo de alumno está en «Excluir» (o no se pudo leer). El script solo trabaja "
            "con «Incluir», así que NO se tocó nada. Corrígelo a mano en Banner si corresponde."
        )

    if "único atributo" in bajo or "unico atributo" in bajo:
        return (
            "El atributo a quitar es el ÚNICO atributo del NRC: quitarlo dejaría el NRC abierto a todos los atributos, "
            "así que NO se tocó. Revísalo a mano."
        )

    if "pero no se pudo verificar la lista final" in bajo:
        return (
            "El guardado SE HIZO pero no se pudo verificar la lista final. Revisa el NRC en Banner y, si hace "
            "falta, restaura desde el CSV «atributos_iniciales» de la carpeta datos/logs/ssarres_atributo."
        )

    if "guardado con diferencias" in bajo:
        return (
            "El guardado SE HIZO pero la lista final no es la esperada. Revisa el NRC en Banner y, si hace falta, "
            "restaura los atributos desde el CSV «atributos_iniciales» de la carpeta datos/logs/ssarres_atributo."
        )

    if "no se confirmó el guardado" in bajo:
        detalle = _entre_comillas(original)
        base = "No se pudo CONFIRMAR el guardado (no apareció un mensaje de éxito reconocido)."
        if detalle:
            base += f" Banner mostró: «{detalle}»."
        return base + " Verifica el NRC en Banner (los atributos originales están en «atributos_iniciales»)."

    if "después de pulsar f10" in bajo or "despues de pulsar f10" in bajo or "después de f10" in bajo:
        return (
            "Falló DESPUÉS de pulsar F10, así que el cambio pudo haberse guardado. No se reintentó. "
            "Verifica el NRC en Banner (los atributos originales están en «atributos_iniciales»)."
        )

    if "banner mostró un mensaje de error" in bajo:
        detalle = _entre_comillas(original)
        return "Banner RECHAZÓ el guardado" + (f" y dijo: «{detalle}»." if detalle else ".") + " No se guardó nada."

    if "límite de" in bajo or "se agotó el límite" in bajo:
        return "Banner tardó demasiado en responder; se cortó el NRC."

    if "sesión" in bajo and "autentic" in bajo:
        return "Problema de sesión con Banner. Vuelve a iniciar sesión y reintenta."

    if "lectura incompleta" in bajo or "repetidos" in bajo or "contador" in bajo:
        return (
            "No se pudo leer completa la lista de atributos, así que por seguridad NO se modificó nada. "
            "Reintenta; si se repite, avisa para revisar la grilla."
        )

    if "grilla de atributo" in bajo or "restricciones de atributo" in bajo or "alt+pagedown" in bajo \
            or "por página" in bajo or "no cargó el detalle" in bajo:
        return "Banner no llegó a la grilla de Restricciones de atributo de alumno a tiempo; el NRC se omitió sin guardarse."

    return "Error: " + original[:250]


# Motivos que NO tiene sentido reintentar sin corregir antes el dato o Banner
# (se buscan DENTRO del motivo, no solo al principio).
_NO_REINTENTAR_SSARRES_ATRIBUTO = (
    "nrc inexistente", "incluir/excluir", "único atributo", "unico atributo",
)


def formatear_fallos_ssarres_atributo(lineas: list) -> tuple:
    """Devuelve (texto_legible, claves). `claves` son los NRC con error que tiene
    sentido REINTENTAR (uno por línea, listos para pegar en la app); se excluyen
    NRC inexistentes, los que están en «Excluir» y los que solo tienen el atributo a quitar."""
    if not lineas:
        return "Sin fallos registrados todavía.", []

    bloques, claves = [], []
    for n, linea in enumerate(lineas, start=1):
        d = parsear_linea_fallo(linea)
        hora = d["fecha"].split(" ")[-1] if d["fecha"] else ""
        partes = [f"{n}) NRC {d['clave']}" + (f"   [{hora}]" if hora else "")]
        if d["motivo"]:
            legible = motivo_legible_ssarres_atributo(d["motivo"])
            partes.append(f"     ► {legible}")
            if not legible.startswith("Error: "):
                partes.append(f"     (detalle técnico: {' '.join(d['motivo'].split())[:300]})")
            if not any(m in d["motivo"].lower() for m in _NO_REINTENTAR_SSARRES_ATRIBUTO):
                claves.append(d["clave"])
        else:
            claves.append(d["clave"])
        bloques.append("\n".join(partes))
    return "\n\n".join(bloques), claves


# ------------------------------------------------------------------
# SSARRES «Dejar solo programas» (src/automation_ssarres_conservar.py): la "clave" de
# cada fallo es la línea completa «NRC,código,código» (los programas que debían
# quedar), de modo que se puede reimportar tal cual. Funciones PROPIAS, independientes
# de las de «Quitar programa 502» y «Quitar atributo».
#
#     [2026-10-28 12:10:05] 2464,503,504 - <motivo técnico>
# ------------------------------------------------------------------

_PATRON_FALTANTES = re.compile(
    r"faltan programas a conservar:\s*(?P<faltan>.*?)\s+no est[aá]n en el NRC\s*\(el NRC tiene (?P<tiene>.*?)\)",
    re.I | re.S,
)


def motivo_legible_ssarres_conservar(motivo: str) -> str:
    """Motivo técnico de «Dejar solo programas» -> explicación para el usuario."""
    original = " ".join(motivo.split())
    bajo = original.lower()

    if bajo.startswith("nrc inexistente"):
        detalle = _entre_comillas(original)
        return (
            "El NRC NO EXISTE en ese periodo"
            + (f" (Banner dijo: «{detalle}»)" if detalle else "")
            + ". Revisa el NRC y el periodo; no se tocó nada."
        )

    if "incluir/excluir" in bajo:
        return (
            "La restricción de programa está en «Excluir» (o no se pudo leer). El script solo trabaja con "
            "«Incluir», así que NO se tocó nada. Corrígelo a mano en Banner si corresponde."
        )

    if "faltan programas a conservar" in bajo:
        m = _PATRON_FALTANTES.search(original)
        if m:
            return (
                f"Los programas que debían quedar NO están todos en el NRC: falta(n) {m.group('faltan')}. "
                f"El NRC tiene {m.group('tiene')}. NO se tocó nada. Corrige los códigos del archivo o revisa el NRC en Banner."
            )
        return (
            "Alguno de los programas que debían quedar NO está en el NRC. NO se tocó nada. "
            "Corrige los códigos del archivo o revisa el NRC en Banner."
        )

    if "pero no se pudo verificar la lista final" in bajo:
        return (
            "El guardado SE HIZO pero no se pudo verificar la lista final. Revisa el NRC en Banner y, si hace "
            "falta, restaura desde el CSV «programas_iniciales» de la carpeta datos/logs/ssarres_conservar_registros."
        )

    if "guardado con diferencias" in bajo:
        return (
            "El guardado SE HIZO pero la lista final no es la esperada. Revisa el NRC en Banner y, si hace falta, "
            "restaura los programas desde el CSV «programas_iniciales» de la carpeta datos/logs/ssarres_conservar_registros."
        )

    if "no se confirmó el guardado" in bajo:
        detalle = _entre_comillas(original)
        base = "No se pudo CONFIRMAR el guardado (no apareció un mensaje de éxito reconocido)."
        if detalle:
            base += f" Banner mostró: «{detalle}»."
        return base + " Verifica el NRC en Banner (los programas originales están en «programas_iniciales»)."

    if "después de pulsar f10" in bajo or "despues de pulsar f10" in bajo or "después de f10" in bajo:
        return (
            "Falló DESPUÉS de pulsar F10, así que el cambio pudo haberse guardado. No se reintentó. "
            "Verifica el NRC en Banner (los programas originales están en «programas_iniciales»)."
        )

    if "banner mostró un mensaje de error" in bajo:
        detalle = _entre_comillas(original)
        return "Banner RECHAZÓ el guardado" + (f" y dijo: «{detalle}»." if detalle else ".") + " No se guardó nada."

    if "se aborta antes de guardar" in bajo:
        return (
            "Por seguridad NO se guardó nada: al borrar, la lista no quedó exactamente como se pidió. "
            "El NRC no cambió en Banner. Reintenta; si se repite, avisa para revisar la grilla."
        )

    if "límite de" in bajo or "se agotó el límite" in bajo:
        return "Banner tardó demasiado en responder; se cortó el NRC."

    if "sesión" in bajo and "autentic" in bajo:
        return "Problema de sesión con Banner. Vuelve a iniciar sesión y reintenta."

    if "lectura incompleta" in bajo or "códigos repetidos" in bajo or "contador" in bajo:
        return (
            "No se pudo leer completa la lista de programas, así que por seguridad NO se modificó nada. "
            "Reintenta; si se repite, avisa para revisar la grilla."
        )

    if "grilla de programa" in bajo or "alt+pagedown" in bajo or "por página" in bajo or "no cargó el detalle" in bajo:
        return "Banner no llegó a la grilla de Restricciones de programa a tiempo; el NRC se omitió sin guardarse."

    return "Error: " + original[:250]


# Motivos que NO tiene sentido reintentar sin corregir antes el dato o Banner
# (se buscan DENTRO del motivo, no solo al principio).
_NO_REINTENTAR_SSARRES_CONSERVAR = (
    "nrc inexistente", "incluir/excluir", "faltan programas a conservar",
)


def formatear_fallos_ssarres_conservar(lineas: list) -> tuple:
    """Devuelve (texto_legible, claves). `claves` son las líneas «NRC,código,código»
    con error que tiene sentido REINTENTAR, listas para pegar en la app; se excluyen
    NRC inexistentes, los que están en «Excluir» y los que no tenían todos los códigos."""
    if not lineas:
        return "Sin fallos registrados todavía.", []

    bloques, claves = [], []
    for n, linea in enumerate(lineas, start=1):
        d = parsear_linea_fallo(linea)
        hora = d["fecha"].split(" ")[-1] if d["fecha"] else ""
        campos = [c.strip() for c in d["clave"].split(",") if c.strip()]
        nrc, conservar = (campos[0], campos[1:]) if campos else (d["clave"], [])
        titulo = f"{n}) NRC {nrc}"
        if conservar:
            titulo += f"   · debía quedar: {', '.join(conservar)}"
        partes = [titulo + (f"   [{hora}]" if hora else "")]
        if d["motivo"]:
            legible = motivo_legible_ssarres_conservar(d["motivo"])
            partes.append(f"     ► {legible}")
            if not legible.startswith("Error: "):
                partes.append(f"     (detalle técnico: {' '.join(d['motivo'].split())[:300]})")
            if not any(m in d["motivo"].lower() for m in _NO_REINTENTAR_SSARRES_CONSERVAR):
                claves.append(d["clave"])
        else:
            claves.append(d["clave"])
        bloques.append("\n".join(partes))
    return "\n\n".join(bloques), claves
