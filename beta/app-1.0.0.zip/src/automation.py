# src/automation.py
"""
Lógica de automatización sobre Banner con Playwright (API ASÍNCRONA).
Porta los hallazgos documentados en la sección 9 del contexto del
proyecto (login SSO, ids de campos, Alt+PageDown, tecleo con delay, F10,
F5 para "recomenzar"). NO reconstruye el protocolo AJAX a mano (bloqueado
por el servidor) - deja que el navegador real dispare sus propias requests.

IMPORTANTE - iframes: Banner 9 renderiza los formularios clásicos
(SSASECT, etc.) dentro de un iframe anidado dentro de la SPA Angular.
Playwright, a diferencia de Selenium con switch_to.frame(), NO busca
automáticamente dentro de iframes cuando se llama a page.click/type/
wait_for_selector directamente - solo mira el frame principal. Por eso
todas las interacciones con el formulario de SSASECT pasan por
_encontrar_frame(), que recorre pagina.frames hasta dar con el que
contiene el campo buscado.

IMPORTANTE - paralelización: se usa la API asíncrona de Playwright
(en vez de la síncrona) para poder correr varias pestañas del mismo
navegador/sesión en paralelo real (asyncio.gather), repartiendo los NRCs
mediante una cola compartida (asyncio.Queue) - así ninguna pestaña se
queda ociosa esperando aunque el trabajo no esté parejo entre ellas.
"""

import os
import sys
import asyncio
from datetime import datetime

from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

# Parche conocido para un problema de asyncio en Windows: bajo carga alta
# (muchas pestañas/operaciones de red encoladas de golpe, como al arrancar
# una corrida grande), la maquinaria interna de asyncio puede toparse con
# el límite de recursión por defecto de Python (1000), sin que sea un
# problema real de la lógica de este archivo. Subirlo es el parche
# estándar recomendado para este caso específico.
sys.setrecursionlimit(10000)

from .state import ruta_sesion, ruta_perfil_login, carpeta_logs, invalidar_sesion, hay_sesion_guardada

BANNER_URL = "https://banner9.continental.edu.pe/applicationNavigator/seamless"
BANNER_HOST = "banner9.continental.edu.pe"

SELECTORES = {
    "busqueda_general": "#search-landing",
    "campo_periodo": "#inp\\:key_block_ssasectTermCode",
    "campo_nrc": "#inp\\:key_block_ssasectCrn",
    "campo_estatus": "#inp\\:ssbsect_ssbsectSstsCode",
    "checkbox_voz": "#inp\\:ssbsect_ssbsectVoiceAvail_btn",
}

# A partir de cuántos NRCs vale la pena paralelizar en varias pestañas.
# Con 20 o menos, una sola pestaña (secuencial) es suficiente.
UMBRAL_PARALELO = 20
NUM_PESTANAS = 5

# Reintentos por NRC antes de darlo por fallido definitivamente:
# intento 1 (normal) -> falla -> recargar página -> intento 2 -> falla ->
# recargar página -> intento 3 -> falla -> reabrir pestaña -> intento 4 ->
# falla -> se rinde con este NRC y detiene TODA la corrida (probablemente
# Banner dejó de responder).
MAX_INTENTOS_POR_NRC = 4


class SesionExpiradaError(RuntimeError):
    """Banner/WSO2 reportó que la sesión ya no es válida (pantalla de error
    de autenticación externa). Reintentar (recargar página, reabrir
    pestaña) no sirve de nada en este caso, solo un login nuevo lo arregla."""
    pass


# Frases que indican que la sesión expiró, en los idiomas que podría
# mostrar el servicio de autenticación externo (WSO2). No sabemos con
# certeza si esta pantalla respeta el idioma del navegador o siempre sale
# en inglés, así que se revisan varias posibilidades por seguridad.
FRASES_SESION_EXPIRADA = [
    "authentication failed",
    "problem in external authentication",
    "autenticación fallida",
    "autenticacion fallida",
    "error de autenticación",
    "error de autenticacion",
    "sesión ha expirado",
    "sesion ha expirado",
    "session expired",
    "session has expired",
]


async def _pantalla_muestra_sesion_expirada(pagina) -> bool:
    """
    Revisa el contenido de TODOS los frames de la página (documento
    principal + cualquier iframe anidado, incluido el de Banner) contra
    varias frases posibles, sin distinguir mayúsculas/minúsculas. Es clave
    revisar los iframes también: si este mensaje se renderiza dentro del
    mismo iframe donde Banner carga sus formularios (igual que pasa con
    los campos de SSASECT), buscar solo en pagina.content() nunca lo
    encuentra, porque ese método solo mira el documento principal.
    """
    try:
        objetivos = [pagina] + list(pagina.frames)
    except Exception:
        objetivos = [pagina]

    for objetivo in objetivos:
        try:
            contenido = (await objetivo.content()).lower()
        except Exception:
            continue
        if any(frase in contenido for frase in FRASES_SESION_EXPIRADA):
            return True

    return False


def _requiere_reautenticacion(pagina) -> bool:
    """
    Detección PRINCIPAL (más confiable que buscar texto): si tras navegar
    a Banner la página termina en un dominio distinto al de Banner mismo
    (accounts.google.com, login.microsoftonline.com, login.continental...),
    significa que la sesión guardada ya no alcanza y Banner está
    intentando reautenticarse solo contra el SSO - lo cual, en headless
    (sin nadie para hacer clic en "elegir cuenta" o similar), se queda
    esperando una interacción humana que nunca llega. No depende del
    idioma ni de la redacción exacta de ningún mensaje.
    """
    try:
        return BANNER_HOST not in pagina.url
    except Exception:
        return False


# --- 1) LOGIN SSO (headful, interacción humana la primera vez) -------------

async def iniciar_login_interactivo(on_log, pos_x=None, pos_y=None) -> str:
    """
    Abre una ventana REAL (no headless) para que el usuario complete el
    flujo SSO completo (WSO2 -> Google -> Microsoft/2FA -> WSO2 -> Banner).
    Al terminar, guarda storage_state (cookies + localStorage) en disco.
    Corridas futuras headless reutilizan ese storage_state y el SSO se
    resuelve solo.
    """
    ANCHO_LOGIN = 480
    ALTO_LOGIN = 680

    args = [f"--window-size={ANCHO_LOGIN},{ALTO_LOGIN}"]
    if pos_x is not None and pos_y is not None:
        args.append(f"--window-position={pos_x},{pos_y}")

    async with async_playwright() as p:
        # launch_persistent_context (en vez de launch + new_context) guarda
        # el perfil completo del navegador entre una llamada y la
        # siguiente - incluidas las cookies de Google/Microsoft. Así, si
        # tu sesión de Google sigue activa (como cuando haces logout/login
        # en tu Chrome normal), el SSO se completa solo la próxima vez,
        # sin pedir credenciales de nuevo.
        contexto = await p.chromium.launch_persistent_context(
            ruta_perfil_login(),
            headless=False,
            args=args,
            locale="es-PE",
            viewport={"width": ANCHO_LOGIN, "height": ALTO_LOGIN - 90},
            no_viewport=False,
        )
        pagina = contexto.pages[0] if contexto.pages else await contexto.new_page()

        on_log("Abriendo ventana de login. Completa el SSO (Google -> Microsoft) en la ventana...")

        try:
            await pagina.goto(BANNER_URL, wait_until="domcontentloaded")
            await pagina.wait_for_url(
                "**/banner9.continental.edu.pe/applicationNavigator/**",
                timeout=5 * 60 * 1000,
            )
            await pagina.wait_for_timeout(1500)

            ruta = ruta_sesion()
            await contexto.storage_state(path=ruta)
            on_log(f"Sesión guardada correctamente en: {ruta}")
            return ruta

        except PlaywrightTimeoutError:
            raise RuntimeError(
                "Se agotó el tiempo de espera (5 min) sin completar el login."
            )
        except Exception as err:
            mensaje = str(err)
            if "closed" in mensaje.lower():
                raise RuntimeError(
                    "Cerraste la ventana antes de completar el inicio de sesión. Intenta de nuevo."
                )
            raise RuntimeError(f"No se pudo completar el login: {mensaje}")
        finally:
            try:
                await contexto.close()
            except Exception:
                pass


# --- 2) AUTOMATIZACIÓN DE SSASECT (async) -----------------------------------

async def _encontrar_frame(pagina, selector: str, timeout_ms: int = 20000):
    """
    Recorre todos los frames de la página (incluye el/los iframe(s)
    anidados donde Banner renderiza sus formularios clásicos) hasta
    encontrar uno que contenga el selector dado.
    """
    limite = asyncio.get_event_loop().time() + timeout_ms / 1000
    while asyncio.get_event_loop().time() < limite:
        for frame in pagina.frames:
            try:
                if await frame.query_selector(selector) is not None:
                    return frame
            except Exception:
                continue
        await pagina.wait_for_timeout(300)
    raise PlaywrightTimeoutError(
        f'No se encontró el selector "{selector}" en ningún frame de la página '
        f"(incluido el iframe de Banner)."
    )


async def _tecleo_confiable(objetivo, selector: str, valor: str, on_log, max_intentos: int = 3) -> bool:
    """
    fill() pierde el primer carácter en estos campos con binding Angular
    pesado. Se limpia el campo y se teclea carácter por carácter, con
    verificación posterior y reintento. `objetivo` puede ser la Page o un
    Frame (ej. el iframe de Banner) - se usa Locator, que funciona igual
    sobre ambos.
    """
    loc = objetivo.locator(selector)
    for intento in range(1, max_intentos + 1):
        await loc.click()
        await loc.press("Control+a")
        await objetivo.wait_for_timeout(200)
        await loc.type(valor, delay=80)

        try:
            valor_actual = await loc.input_value()
        except Exception:
            valor_actual = None

        if valor_actual == valor:
            return True

        on_log(f'Verificación de "{valor}" falló (quedó "{valor_actual}"), reintento {intento}/{max_intentos}')
        await objetivo.wait_for_timeout(300)

    return False


async def _abrir_ssasect_desde_cero(pagina, periodo: str, nrc: str, on_log):
    """
    Camino completo: desde la pantalla "Bienvenido(a)", busca SSASECT,
    escribe Periodo + NRC y avanza a la pantalla de detalle. Se usa para
    el primer NRC que procesa cada pestaña, o para recuperarse si algo
    falló. Devuelve el Frame donde vive el formulario.
    """
    await pagina.goto(BANNER_URL, wait_until="domcontentloaded")

    # Dos formas de detectar que la sesión ya no alcanza: (1) Banner
    # redirige de verdad a Google/Microsoft/WSO2 pidiendo reautenticación
    # (se nota por la URL, es la más confiable) o (2) Angular se queda en
    # el mismo shell de Banner pero muestra el mensaje "Authentication
    # Failed" en el contenido (hace falta esperar un poco a que aparezca).
    if _requiere_reautenticacion(pagina):
        raise SesionExpiradaError(
            "La sesión de Banner expiró (redirigido a la pantalla de login externo). "
            "Hay que iniciar sesión de nuevo."
        )

    await pagina.wait_for_timeout(1500)
    if _requiere_reautenticacion(pagina) or await _pantalla_muestra_sesion_expirada(pagina):
        raise SesionExpiradaError(
            "La sesión de Banner expiró (pantalla de error de autenticación externa). "
            "Hay que iniciar sesión de nuevo."
        )

    try:
        await pagina.wait_for_selector(SELECTORES["busqueda_general"], timeout=30000)
    except PlaywrightTimeoutError:
        # Respaldo: si el buscador nunca apareció, puede que el mensaje de
        # sesión expirada haya aparecido recién ahora (más tarde de lo
        # esperado) - se revisa una vez más antes de darlo por un fallo
        # genérico cualquiera.
        if _requiere_reautenticacion(pagina) or await _pantalla_muestra_sesion_expirada(pagina):
            raise SesionExpiradaError(
                "La sesión de Banner expiró (pantalla de error de autenticación externa). "
                "Hay que iniciar sesión de nuevo."
            )
        raise

    # Margen extra antes de escribir: aunque el campo ya sea visible,
    # Angular puede tardar un poco más en terminar de conectar sus propios
    # manejadores de eventos de teclado - escribir demasiado pronto es lo
    # que causa que se pierdan las primeras letras (ej. "SSASECT" -> 
    # "ASECT"). El tecleo confiable de abajo igual verifica y reintenta si
    # hace falta, pero este margen reduce cuánto necesita reintentar.
    await pagina.wait_for_timeout(400)

    # Igual que con Periodo/NRC/Estatus: escribir "a ciegas" puede perder
    # caracteres (binding Angular pesado). Se usa el mismo tecleo confiable
    # con verificación y reintento en vez de un simple type() sin revisar.
    if not await _tecleo_confiable(pagina, SELECTORES["busqueda_general"], "SSASECT", on_log):
        raise RuntimeError('No se pudo escribir "SSASECT" en el buscador de forma confiable')
    await pagina.wait_for_timeout(2500)

    try:
        sugerencia = pagina.locator("text=SSASECT").filter(
            has_not=pagina.locator(SELECTORES["busqueda_general"])
        ).first
        if await sugerencia.is_visible(timeout=1500):
            await sugerencia.click()
        else:
            await pagina.keyboard.press("Enter")
    except Exception:
        await pagina.keyboard.press("Enter")

    marco = await _encontrar_frame(pagina, SELECTORES["campo_periodo"], timeout_ms=20000)
    await marco.wait_for_timeout(400)

    if not await _tecleo_confiable(marco, SELECTORES["campo_periodo"], periodo, on_log):
        raise RuntimeError(f'No se pudo escribir el periodo "{periodo}" de forma confiable')

    if not await _tecleo_confiable(marco, SELECTORES["campo_nrc"], nrc, on_log):
        raise RuntimeError(f'No se pudo escribir el NRC "{nrc}" de forma confiable')

    await pagina.keyboard.press("Alt+PageDown")
    try:
        await marco.wait_for_selector(SELECTORES["campo_estatus"], timeout=15000)
    except Exception:
        if _requiere_reautenticacion(pagina) or await _pantalla_muestra_sesion_expirada(pagina):
            raise SesionExpiradaError(
                "La sesión de Banner expiró (pantalla de error de autenticación externa). "
                "Hay que iniciar sesión de nuevo."
            )
        raise

    return marco


async def _abrir_ssasect_siguiente_nrc(pagina, marco, nrc: str, on_log):
    """
    Camino rápido: se usa desde el segundo NRC en adelante que procesa
    una misma pestaña, justo después de un F5 (que ya dejó la pantalla en
    el buscador de Periodo/NRC, con el Periodo todavía escrito). Solo
    hace falta escribir el NRC nuevo.
    """
    if not await _tecleo_confiable(marco, SELECTORES["campo_nrc"], nrc, on_log):
        raise RuntimeError(f'No se pudo escribir el NRC "{nrc}" de forma confiable')

    await pagina.keyboard.press("Alt+PageDown")
    try:
        await marco.wait_for_selector(SELECTORES["campo_estatus"], timeout=15000)
    except Exception:
        # Este es el camino que usa la MAYORÍA de los NRCs en una corrida
        # grande (todo menos el primero de cada pestaña) - si no se
        # revisa sesión expirada acá también, la mayoría de los casos
        # reales caerían al manejo genérico en vez del específico.
        if _requiere_reautenticacion(pagina) or await _pantalla_muestra_sesion_expirada(pagina):
            raise SesionExpiradaError(
                "La sesión de Banner expiró (pantalla de error de autenticación externa). "
                "Hay que iniciar sesión de nuevo."
            )
        raise

    return marco


# Frases de confirmación de guardado. Los mensajes de sistema de Banner
# aparecieron siempre en inglés en todas las capturas vistas hasta ahora
# (aunque el resto de la interfaz esté en español), pero no hay certeza
# total de que sea así siempre - se agregan variantes en español como
# respaldo, mismo criterio que con la detección de sesión expirada.
FRASES_GUARDADO_EXITOSO = [
    "saved successfully",
    "guardado correctamente",
    "guardado con éxito",
    "guardado con exito",
]
FRASES_SIN_CAMBIOS = [
    "no changes to save",
    "no hay cambios que guardar",
    "sin cambios que guardar",
    "sin cambios para guardar",
]


async def _leer_confirmacion_guardado(marco, timeout_ms: int = 15000, on_log=None):
    """
    Revisa el contenido de TODOS los frames (igual que la detección de
    sesión expirada) buscando alguna de las frases de confirmación de
    guardado, en inglés o español. Devuelve "exito", "sin_cambios", o
    None si se agotó el tiempo sin encontrar ninguna.

    Si se agota el tiempo sin encontrar nada y se pasó `on_log`, se
    loguea un extracto del texto visible de cada frame en ese momento -
    para diagnosticar casos donde SÍ hay un mensaje en pantalla (de
    error, de validación, o cualquier otro) pero no coincide con
    ninguna de las frases que estamos buscando.
    """
    limite = asyncio.get_event_loop().time() + timeout_ms / 1000
    while asyncio.get_event_loop().time() < limite:
        try:
            objetivos = [marco.page] + list(marco.page.frames)
        except Exception:
            objetivos = [marco]

        for objetivo in objetivos:
            try:
                contenido = (await objetivo.content()).lower()
            except Exception:
                continue
            if any(frase in contenido for frase in FRASES_SIN_CAMBIOS):
                return "sin_cambios"
            if any(frase in contenido for frase in FRASES_GUARDADO_EXITOSO):
                return "exito"

        await marco.wait_for_timeout(300)

    if on_log is not None:
        try:
            objetivos = [marco.page] + list(marco.page.frames)
        except Exception:
            objetivos = [marco]
        for i, objetivo in enumerate(objetivos):
            try:
                texto = await objetivo.evaluate("() => document.body ? document.body.innerText : ''")
            except Exception as err:
                on_log(f"[DIAG] frame {i}: no se pudo leer texto ({err})")
                continue
            texto = " ".join(texto.split())  # colapsar espacios/saltos de línea
            if texto:
                on_log(f"[DIAG] frame {i} (primeros 500 chars): {texto[:500]}")
            else:
                on_log(f"[DIAG] frame {i}: sin texto visible")

    return None


async def _guardar_y_recomenzar(pagina, marco, on_log) -> bool:
    await pagina.keyboard.press("F10")

    # Antes había una espera "a ciegas" de 1s antes de empezar siquiera a
    # revisar si apareció la confirmación. Eso funcionaba con Estatus
    # (guardar un cambio de texto tarda lo suficiente en el backend como
    # para que el aviso siga visible), pero con el checkbox de voz -un
    # cambio booleano trivial- Banner parece guardar y mostrar/ocultar el
    # aviso DENTRO de ese primer segundo ciego, así que el polling nunca
    # llegaba a verlo (timeout completo sin encontrar nada, aunque el
    # guardado sí se hizo). Se empieza a revisar de inmediato en vez de
    # esperar a ciegas primero - el propio polling de
    # _leer_confirmacion_guardado (cada 300ms) ya cubre el margen que se
    # necesitaba antes de que Banner reaccione.
    #
    # Con varias pestañas pidiéndole cosas a Banner al mismo tiempo, el
    # guardado puede tardar más de lo que tarda con una sola pestaña. Se
    # da un margen más generoso (15s) antes de considerar que no se
    # confirmó - y si aun así no aparece, NO se sigue de largo asumiendo
    # que salió bien: se lanza una excepción para que el NRC pase por el
    # mismo mecanismo de reintento que cualquier otro fallo, en vez de
    # arriesgarse a contar como "éxito" algo que nunca se confirmó.
    #
    # "Sin cambios" es una confirmación tan válida como "guardado
    # exitoso" - aparece cuando el valor que se quería escribir ya era el
    # mismo que ya tenía Banner (ej. querer poner Estatus B en un NRC que
    # ya estaba en B). No es un error: el NRC ya está en el estado
    # deseado, que es justamente el objetivo final.
    resultado = await _leer_confirmacion_guardado(marco, timeout_ms=15000, on_log=on_log)
    if resultado is None:
        raise RuntimeError(
            "No se confirmó el guardado (ni mensaje de éxito ni de sin cambios "
            "aparecieron a tiempo) - no se puede dar por exitoso sin confirmación."
        )

    if resultado == "sin_cambios":
        on_log("Ya estaba en el valor deseado - no hizo falta cambiar nada, se sigue igual.")

    # F5 dentro de Banner NO recarga la página completa: "recomienza" el
    # formulario y vuelve a la pantalla de búsqueda (Periodo/NRC). El
    # Periodo queda guardado de la vez anterior.
    await pagina.keyboard.press("F5")
    await pagina.wait_for_timeout(1000)
    if resultado is None:
        raise RuntimeError(
            "No se confirmó el guardado (ni mensaje de éxito ni de sin cambios "
            "aparecieron a tiempo) - no se puede dar por exitoso sin confirmación."
        )

    if resultado == "sin_cambios":
        on_log("Ya estaba en el valor deseado - no hizo falta cambiar nada, se sigue igual.")

    # F5 dentro de Banner NO recarga la página completa: "recomienza" el
    # formulario y vuelve a la pantalla de búsqueda (Periodo/NRC). El
    # Periodo queda guardado de la vez anterior.
    await pagina.keyboard.press("F5")
    await pagina.wait_for_timeout(1000)

    if _requiere_reautenticacion(pagina) or await _pantalla_muestra_sesion_expirada(pagina):
        raise SesionExpiradaError(
            "La sesión de Banner expiró (pantalla de error de autenticación externa). "
            "Hay que iniciar sesión de nuevo."
        )

    # Validación clave: si tras el F5 el campo de NRC no reaparece, algo
    # salió mal (Banner no respondió como se esperaba) - se deja que la
    # excepción suba para que el llamador dispare la recuperación
    # (recargar página / reabrir pestaña / detener todo).
    try:
        await marco.wait_for_selector(SELECTORES["campo_nrc"], timeout=10000)
    except Exception:
        # Si el frame quedó obsoleto (Angular pudo haber reemplazado todo
        # el contenido, no solo el formulario) o el campo simplemente no
        # apareció, se revisa una vez más por sesión expirada antes de
        # dejar que suba como un fallo genérico cualquiera.
        if _requiere_reautenticacion(pagina) or await _pantalla_muestra_sesion_expirada(pagina):
            raise SesionExpiradaError(
                "La sesión de Banner expiró (pantalla de error de autenticación externa). "
                "Hay que iniciar sesión de nuevo."
            )
        raise
    return True


async def _cambiar_estatus(pagina, marco, nuevo_estatus: str, on_log) -> bool:
    if not await _tecleo_confiable(marco, SELECTORES["campo_estatus"], nuevo_estatus, on_log):
        raise RuntimeError(f'No se pudo escribir el estatus "{nuevo_estatus}" de forma confiable')
    return await _guardar_y_recomenzar(pagina, marco, on_log)


async def _alternar_voz(pagina, marco, on_log) -> bool:
    await marco.click(SELECTORES["checkbox_voz"])

    # Este campo NO es un <input type="checkbox"> nativo - es un <button
    # role="checkbox"> (widget jQuery UI, ver diagnóstico en el chat).
    # Se sospecha que el clic solo actualiza el estado visual
    # (aria-checked), y que el AJAX real que le avisa a Banner "este
    # campo cambió" (GOTOITEM, ver sección 9.2 del contexto del
    # proyecto) se dispara recién con el blur (foco saliendo del campo)
    # - algo que un <input> de texto no necesita porque ya lo dispara al
    # tipear. Se fuerza el blur con Tab antes de guardar, a ver si esto
    # es lo que faltaba.
    await pagina.keyboard.press("Tab")
    await marco.wait_for_timeout(300)

    return await _guardar_y_recomenzar(pagina, marco, on_log)


async def _procesar_un_nrc(pagina, marco, periodo, nrc, accion, nuevo_estatus, on_log):
    """
    Intenta procesar un único NRC asumiendo que `pagina` está lista.
    `marco` es None si hay que arrancar desde cero (primer NRC de esta
    pestaña, o tras una recuperación), o el Frame ya ubicado si se puede
    usar el camino rápido. Devuelve el Frame usado.
    """
    if marco is None:
        marco = await _abrir_ssasect_desde_cero(pagina, periodo, nrc, on_log)
    else:
        marco = await _abrir_ssasect_siguiente_nrc(pagina, marco, nrc, on_log)

    if accion == "estatus":
        await _cambiar_estatus(pagina, marco, nuevo_estatus, on_log)
    elif accion == "voz":
        await _alternar_voz(pagina, marco, on_log)
    else:
        raise RuntimeError(f"Acción desconocida: {accion}")

    return marco


async def _guardar_captura_error(pagina, nrc: str):
    """
    Guarda una captura de pantalla del estado actual de la página cuando
    algo falla, para poder diagnosticar selectores sin tener acceso
    directo a Banner.
    """
    try:
        marca = datetime.now().strftime("%Y%m%d_%H%M%S")
        ruta = os.path.join(carpeta_logs(), f"error_{nrc}_{marca}.png")
        await pagina.screenshot(path=ruta)
        return ruta
    except Exception:
        return None


# --- 3) TRABAJADOR (una pestaña) --------------------------------------------


async def _pagina_nueva(contexto):
    """
    Crea una pestaña nueva con un manejador de diálogos nativos
    (window.confirm/alert/prompt) que los acepta automáticamente.

    Por defecto Playwright CANCELA en silencio cualquier diálogo nativo
    que no tenga un manejador explícito - sin tirar error. Se sospecha
    que Banner muestra un confirm() nativo al guardar cambios en el
    checkbox "Respuesta de voz y autoservicio disponibles" (a diferencia
    de Estatus, que nunca lo mostró), y que ese diálogo cancelado en
    silencio es la causa de que F10 nunca termine de guardar en modo voz
    (no aparece ni "Saved successfully" ni "No changes to save" porque
    Banner nunca llegó a intentar guardar de verdad).
    """
    pagina = await contexto.new_page()

    def _aceptar_dialogo(dialogo):
        asyncio.create_task(dialogo.accept())

    pagina.on("dialog", _aceptar_dialogo)
    return pagina


async def _trabajador(
    indice: int,
    contexto,
    cola: "asyncio.Queue[str]",
    periodo: str,
    accion: str,
    nuevo_estatus: str,
    estado_corrida,
    control,
    evento_detener: asyncio.Event,
    on_log,
    on_progreso,
    on_resumen=None,
):
    """
    Procesa NRCs de la cola compartida uno a la vez, en su propia pestaña
    (Page) del mismo navegador/contexto (misma sesión de login). Sigue
    tomando NRCs hasta que la cola se vacía, se cancela la corrida, o se
    activa evento_detener (Banner dejó de responder).

    `on_log` recibe TODO el detalle (reintentos, capturas, sesión
    expirada, etc.) - pensado para quedar en el archivo, no
    necesariamente en pantalla. `on_resumen` recibe solo lo que le
    importa al usuario: que un NRC quedó procesado, o que falló y por
    qué - sin importar cuántos reintentos hizo falta por debajo. Si no
    se pasa `on_resumen`, se usa `on_log` para todo (compatibilidad).
    """
    resumen = on_resumen if on_resumen is not None else on_log
    etiqueta = f"[Pestaña {indice + 1}]"

    def log(mensaje: str):
        # Todos los mensajes de este trabajador quedan etiquetados con su
        # número de pestaña, para poder distinguir en el log si alguna se
        # quedó atrás mientras las demás siguen avanzando.
        on_log(f"{etiqueta} {mensaje}")

    log("Pestaña iniciada.")
    pagina = await _pagina_nueva(contexto)
    marco = None

    try:
        while not evento_detener.is_set() and not control.cancelado:
            while control.pausado and not control.cancelado and not evento_detener.is_set():
                await asyncio.sleep(0.3)
            if control.cancelado or evento_detener.is_set():
                break

            try:
                nrc = cola.get_nowait()
            except asyncio.QueueEmpty:
                log("Sin más NRCs en la cola - esta pestaña terminó su parte.")
                break  # no quedan más NRCs - esta pestaña ya terminó su parte

            log(f"Procesando NRC {nrc}...")
            exito = False
            ultimo_error = None

            for intento in range(MAX_INTENTOS_POR_NRC):
                try:
                    # Límite de tiempo global por intento: si algo dentro
                    # (red, Chromium, lo que sea) se queda esperando sin
                    # límite propio, esto lo corta a los 60s en vez de
                    # dejar la corrida (y potencialmente la app entera)
                    # colgada para siempre.
                    marco = await asyncio.wait_for(
                        _procesar_un_nrc(pagina, marco, periodo, nrc, accion, nuevo_estatus, log),
                        timeout=60,
                    )
                    exito = True
                    break
                except SesionExpiradaError as err:
                    # La sesión expirada pasa por LA MISMA escalera de
                    # recuperación que cualquier otro fallo (recargar x2,
                    # reabrir pestaña x1) antes de rendirse - la primera
                    # vez que aparece esta pantalla podría ser un hipo
                    # transitorio (ej. en la primera carga de una pestaña
                    # recién abierta), no necesariamente una sesión
                    # realmente muerta. Solo si persiste después de haber
                    # agotado TODOS los intentos (recargas + reapertura de
                    # pestaña) se asume que sí murió de verdad.
                    ultimo_error = err
                    marco = None
                    log(
                        f"NRC {nrc}: pantalla de error de autenticación (intento {intento + 1}/"
                        f"{MAX_INTENTOS_POR_NRC}) - podría ser transitorio, reintentando..."
                    )

                    if intento == MAX_INTENTOS_POR_NRC - 1:
                        break  # se agotó toda la escalera, se rinde con este NRC
                    elif intento < 2:
                        try:
                            await asyncio.wait_for(
                                pagina.goto(BANNER_URL, wait_until="domcontentloaded"), timeout=20
                            )
                        except Exception:
                            pass
                    else:
                        log(f"NRC {nrc}: la recarga no funcionó, reabriendo la ventana...")
                        try:
                            await asyncio.wait_for(pagina.close(), timeout=10)
                        except Exception:
                            pass
                        try:
                            pagina = await asyncio.wait_for(_pagina_nueva(contexto), timeout=15)
                        except Exception:
                            pagina = await _pagina_nueva(contexto)
                except asyncio.TimeoutError:
                    ultimo_error = RuntimeError("Se agotó el límite de 60s para este intento (posible cuelgue)")
                    try:
                        if _requiere_reautenticacion(pagina) or await _pantalla_muestra_sesion_expirada(pagina):
                            ultimo_error = SesionExpiradaError("Se agotó el límite de 60s (sesión expirada)")
                    except Exception:
                        pass
                    log(f"NRC {nrc}: el intento {intento + 1} se pasó de 60s - se corta y se reintenta.")
                    ruta_captura = await _guardar_captura_error(pagina, nrc)
                    if ruta_captura:
                        log(f"Captura de pantalla guardada en: {ruta_captura}")
                    marco = None

                    if intento == MAX_INTENTOS_POR_NRC - 1:
                        break
                    elif intento < 2:
                        try:
                            await asyncio.wait_for(
                                pagina.goto(BANNER_URL, wait_until="domcontentloaded"), timeout=20
                            )
                        except Exception:
                            pass
                    else:
                        try:
                            await pagina.close()
                        except Exception:
                            pass
                        pagina = await _pagina_nueva(contexto)
                except Exception as err:
                    ultimo_error = err
                    # Chequeo universal: sin importar en qué función
                    # específica haya ocurrido la excepción (escribir un
                    # campo, esperar un selector, lo que sea), se revisa
                    # el estado REAL de la página en este momento antes de
                    # clasificarla como un fallo genérico cualquiera. Así
                    # no hace falta adivinar de antemano cada punto exacto
                    # donde podría aparecer la sesión expirada.
                    try:
                        if _requiere_reautenticacion(pagina) or await _pantalla_muestra_sesion_expirada(pagina):
                            ultimo_error = SesionExpiradaError(str(err))
                    except Exception:
                        pass

                    ruta_captura = await _guardar_captura_error(pagina, nrc)
                    if ruta_captura:
                        log(f"Captura de pantalla guardada en: {ruta_captura}")
                    marco = None

                    if isinstance(ultimo_error, SesionExpiradaError):
                        log(
                            f"NRC {nrc}: pantalla de error de autenticación (intento {intento + 1}/"
                            f"{MAX_INTENTOS_POR_NRC}) - podría ser transitorio, reintentando..."
                        )
                    elif intento < 2:
                        log(f"NRC {nrc}: reintentando (recargar página, intento {intento + 1}/2)...")

                    if intento == MAX_INTENTOS_POR_NRC - 1:
                        break  # se agotaron los intentos, se rinde con este NRC
                    elif intento < 2:
                        try:
                            await asyncio.wait_for(
                                pagina.goto(BANNER_URL, wait_until="domcontentloaded"), timeout=20
                            )
                        except Exception:
                            pass
                    else:
                        log(f"NRC {nrc}: la recarga no funcionó, reabriendo la ventana...")
                        try:
                            await asyncio.wait_for(pagina.close(), timeout=10)
                        except Exception:
                            pass
                        try:
                            pagina = await asyncio.wait_for(_pagina_nueva(contexto), timeout=15)
                        except Exception:
                            pagina = await _pagina_nueva(contexto)

            if exito:
                estado_corrida.marcar_exito(nrc)
                log(f"NRC {nrc}: OK")
                resumen(f"NRC {nrc}: Procesado")
            elif isinstance(ultimo_error, SesionExpiradaError):
                # Se agotó toda la escalera (recargar x2, reabrir pestaña
                # x1) y la pantalla de error de autenticación persistió -
                # recién acá se asume que la sesión sí murió de verdad.
                invalidar_sesion()
                log(
                    "SESIÓN EXPIRADA: la pantalla de error de autenticación persistió "
                    "incluso tras recargar y reabrir la ventana - probablemente tu sesión "
                    "de Banner venció. Se borró la sesión guardada: abre la app de nuevo e "
                    "inicia sesión con Google antes de reintentar. Si el mismo error sigue "
                    "apareciendo incluso después de volver a iniciar sesión, probablemente "
                    "ya no sea un tema de sesión sino un problema del propio Banner - en ese "
                    "caso, espera un momento y verifica si el sistema está funcionando "
                    "normalmente antes de intentar de nuevo."
                )
                estado_corrida.marcar_fallo(nrc, str(ultimo_error))
                resumen(f"NRC {nrc}: Error - sesión de Banner expirada, corrida detenida")
                evento_detener.set()
            else:
                estado_corrida.marcar_fallo(nrc, str(ultimo_error))
                log(f"NRC {nrc}: FALLÓ tras varios intentos - {ultimo_error}")
                log("Banner parece no estar respondiendo. Deteniendo toda la corrida.")
                resumen(f"NRC {nrc}: Error - {ultimo_error}")
                evento_detener.set()

            on_progreso(nrc, len(estado_corrida.procesados), len(estado_corrida.pendientes), len(estado_corrida.fallos))
    finally:
        try:
            await pagina.close()
        except Exception:
            pass


# --- 4) LOOP PRINCIPAL -------------------------------------------------------

async def ejecutar_lote(
    periodo: str,
    accion: str,          # "estatus" | "voz"
    nuevo_estatus: str,   # solo si accion == "estatus"
    nrcs: list[str],
    estado_corrida,        # instancia de EstadoCorrida
    control,                # objeto con .pausado (bool) y .cancelado (bool)
    on_log,
    on_progreso,            # callback(nrc, procesados, pendientes, fallos)
    num_pestanas: int = NUM_PESTANAS,  # configurable desde la UI (1-10)
    on_resumen=None,        # callback solo con lo esencial para el usuario
                             # (Inicializando / NRC X: Procesado / NRC X: Error - ...)
                             # - si no se pasa, se usa on_log para todo
) -> None:
    resumen = on_resumen if on_resumen is not None else on_log
    ruta = ruta_sesion()

    resumen("Inicializando...")

    n_pestanas = max(1, num_pestanas) if len(nrcs) > UMBRAL_PARALELO else 1
    if n_pestanas > 1:
        on_log(f"{len(nrcs)} NRCs: se procesan en paralelo con {n_pestanas} pestañas.")

    cola: "asyncio.Queue[str]" = asyncio.Queue()
    for nrc in nrcs:
        cola.put_nowait(nrc)

    evento_detener = asyncio.Event()

    async with async_playwright() as p:
        navegador = await p.chromium.launch(headless=True)
        contexto = await navegador.new_context(storage_state=ruta, locale="es-PE")

        tareas = [
            asyncio.create_task(_trabajador(
                i, contexto, cola, periodo, accion, nuevo_estatus,
                estado_corrida, control, evento_detener, on_log, on_progreso,
                on_resumen=resumen,
            ))
            for i in range(n_pestanas)
        ]
        await asyncio.gather(*tareas)
        await navegador.close()

    if evento_detener.is_set():
        if not hay_sesion_guardada():
            resumen(
                "Corrida detenida por sesión expirada. Vuelve a abrir la app "
                "e inicia sesión con Google antes de reintentar."
            )
        else:
            resumen(
                "La corrida se detuvo antes de terminar todos los NRCs: Banner "
                "dejó de responder. Revisa el sistema e intenta de nuevo más tarde."
            )