# src/automation_sfabrdf.py
"""
Automatización de la forma SFABRDF (Definición de regla de bloque) con
Playwright (API ASÍNCRONA). Es el puerto a Playwright headless del script de
prueba Selenium `prueba_sfabrdf_selenium.py`, ya validado en vivo.

Qué hace, por cada regla (una línea con 8 campos):
  1. F6 inserta una fila en la grilla superior ("Definición de las reglas").
  2. Tab + escritura por las 7 columnas editables (Prioridad, Nivel, Campus,
     Programa, Tipo de campo de estudio, Departamento, Atributo), verificando
     la columna REAL donde está el foco (aria-labelledby "..._col<N>_lbl").
  3. Alt+PageDown salta al campo Bloque (grilla inferior "Atributos del
     bloque"), se escribe el Bloque + Tab.
  4. F10 guarda; se lee el mensaje REAL de Banner (éxito / duplicado / error).
  5. Alt+PageUp regresa a la grilla superior para la siguiente regla.

Diferencias de comportamiento respecto a SSASECT (automation.py):
  - Si UNA regla falla o es duplicada, se marca como error y la corrida
    CONTINÚA con la siguiente (no se detiene toda la corrida). Solo se
    detiene si la sesión expiró o si fallan MAX_FALLOS_SEGUIDOS reglas
    seguidas (señal de que Banner dejó de responder).
  - Un duplicado NO se reintenta (daría el mismo error): se recarga la forma
    completa y se pasa a la siguiente.
  - Tras un guardado CONFIRMADO nunca se vuelve a insertar la misma fila
    (eso producía falsos duplicados).

Se ejecuta desde la app (main.py) o por línea de comandos, útil para validar
en visible antes de usar la interfaz:

    python -m src.automation_sfabrdf bloques.csv 202620 --visible

(requiere haber iniciado sesión antes con la app: usa la misma sesión
guardada en datos/banner_storage_state.json).
"""

import asyncio
import csv
import os
import re
import sys
import time
import unicodedata
from datetime import datetime

from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

from .automation import (
    BANNER_URL,
    SesionExpiradaError,
    _requiere_reautenticacion,
    _pantalla_muestra_sesion_expirada,
    _encontrar_frame,
    _guardar_captura_error,
    _pagina_nueva,
    _tecleo_confiable,
)
from .state import (
    ruta_sesion,
    carpeta_logs,
    invalidar_sesion,
    hay_sesion_guardada,
    EstadoCorrida,
)

# ------------------------------------------------------------------
# CONFIGURACIÓN
# ------------------------------------------------------------------

NOMBRE_FORMA = "SFABRDF"
ACCION = "sfabrdf"  # nombre de la carpeta de pendientes/procesados/fallos en datos/logs

SELECTOR_BUSQUEDA = "#search-landing"
# Confirmado vía DevTools: nombre de bloque genérico "keybloc" (no sigue el
# patrón "<forma>TermCode" de SSASECT).
SELECTOR_CAMPO_PERIODO = "#inp\\:key_block_keyblocTermCode"

# Con menos reglas que esto, una sola pestaña (secuencial) es suficiente.
UMBRAL_PARALELO = 20
NUM_PESTANAS = 5

# Intentos por regla: intento 1 -> falla -> recargar la forma completa ->
# intento 2 -> falla -> se marca como error y se sigue con la siguiente.
# (Los DUPLICADOS no usan esta escalera: se marcan como error de inmediato.)
MAX_INTENTOS_POR_FILA = 1

# Cada cuántas reglas guardadas se hace F5 + Alt+PageDown para que la grilla
# en pantalla no crezca indefinidamente.
FILAS_ANTES_DE_REFRESCAR = 50

# Si fallan tantas reglas SEGUIDAS (sin ninguna correcta ni duplicada en
# medio), se asume que Banner dejó de responder y se detiene la corrida.
MAX_FALLOS_SEGUIDOS = 5

# SOLO PARA PRUEBAS: antepone "[Pestaña N]" y el tiempo de cada regla a los
# mensajes del panel de la app (para ver qué pestaña procesa cada regla y cuánto
# tarda). Ponlo en False para volver al panel limpio (el detalle completo
# siempre queda en datos/app.log).
MOSTRAR_PESTANA_EN_RESUMEN = False

# SOLO PARA PRUEBAS: True abre el navegador VISIBLE: una sola ventana de Chrome
# con una pestaña por cada trabajador (haz clic en cada pestaña para ver cómo
# trabaja; solo la pestaña activa se ve en pantalla, las demás siguen
# trabajando en segundo plano). False = headless (sin ventana), que es el modo
# normal de producción. Desde la línea de comandos manda --visible, que tiene
# prioridad sobre esta bandera.
MOSTRAR_NAVEGADOR = False

# Límite de tiempo por intento de una regla (red de seguridad contra cuelgues).
LIMITE_SEGUNDOS_POR_INTENTO = 150

# Qué hacer si tras F10 no aparece ningún mensaje de guardado conocido:
#  False (recomendado) -> se trata como FALLO de la regla.
#  True                -> se asume que guardó y se sigue.
ASUMIR_OK_SI_NO_HAY_MENSAJE = False

# ------------------------------------------------------------------
# VELOCIDAD vs. FIABILIDAD (mismos valores que el script Selenium validado)
#
# MODO_RAPIDO = False (POR DEFECTO) -> tecleo carácter por carácter y pausa
#   fija tras cada Tab / F6 / F10 / Alt+PageUp. Las verificaciones (columna
#   real, grilla superior vs inferior, valores de la fila, no reinsertar tras
#   guardar, texto visible) siguen activas en ambos modos.
# MODO_RAPIDO = True -> pegado en bloque y pausas mínimas. Solo si el modo
#   seguro corre limpio, y bajando una pausa por vez.
# ------------------------------------------------------------------
MODO_RAPIDO = False

if MODO_RAPIDO:
    TECLEO_POR_CARACTER = False
    ESPERA_TRAS_TECLEO = 0.05
    ESPERA_TRAS_TAB = 0.0
    ESPERA_TRAS_F6 = 0.0
    ESPERA_TRAS_F10 = 0.1
    ESPERA_TRAS_ALT_PGUP = 0.1
else:
    TECLEO_POR_CARACTER = True
    ESPERA_TRAS_TECLEO = 0.1
    ESPERA_TRAS_TAB = 0.20
    ESPERA_TRAS_F6 = 0.35
    ESPERA_TRAS_F10 = 0.5
    ESPERA_TRAS_ALT_PGUP = 0.3

# Las 8 columnas del CSV, EN ESTE ORDEN (se leen por posición, no por nombre).
ORDEN_COLUMNAS_CSV = [
    "prioridad",
    "nivel",
    "campus",
    "programa",
    "tipo_campo_estudio",
    "departamento",
    "atributo",
    "bloque",
]
ENCABEZADO_LEGIBLE = (
    "Prioridad, Nivel, Campus, Programa, Tipo de campo de estudio, "
    "Departamento, Atributo, Bloque"
)

# Columna real de la grilla (confirmada por DevTools) -> nombre interno.
MAPA_COLUMNAS_GRILLA = {
    0: "prioridad",
    1: "nivel",
    2: "campus",
    5: "programa",
    6: "tipo_campo_estudio",
    8: "departamento",
    10: "atributo",
}

# La grilla superior tiene ~14 columnas y la inferior ~4.
MIN_COLUMNAS_GRILLA_SUPERIOR = 8


class ReglaDuplicadaError(RuntimeError):
    """Banner respondió que la regla ya existe (duplicada)."""
    tras_reintento = False


# ------------------------------------------------------------------
# LECTURA Y VALIDACIÓN DE LAS REGLAS (CSV / Excel / líneas de texto)
# ------------------------------------------------------------------

def _a_texto(valor) -> str:
    """Celda de Excel -> texto limpio (14.0 -> '14', None -> '')."""
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    return str(valor).strip()


def normalizar_campos(campos) -> str:
    """Los 8 campos -> la línea canónica 'a,b,c,...' (la clave de la regla)."""
    return ",".join(c.strip() for c in campos)


def parsear_linea(linea: str) -> dict:
    """Línea 'Prioridad,Nivel,...,Bloque' -> dict por nombre interno.
    Lanza ValueError si no tiene exactamente 8 campos o falta algún dato
    obligatorio (todos los campos son obligatorios en este flujo)."""
    try:
        campos = next(csv.reader([linea]))
    except (StopIteration, csv.Error) as err:
        raise ValueError(f"línea ilegible ({err})")
    campos = [c.strip() for c in campos]
    if len(campos) != len(ORDEN_COLUMNAS_CSV):
        raise ValueError(
            f"tiene {len(campos)} campos y se esperaban {len(ORDEN_COLUMNAS_CSV)} "
            f"({ENCABEZADO_LEGIBLE})"
        )
    vacios = [n for n, v in zip(ORDEN_COLUMNAS_CSV, campos) if not v]
    if vacios:
        raise ValueError("faltan datos en: " + ", ".join(vacios))
    return dict(zip(ORDEN_COLUMNAS_CSV, campos))


def validar_lineas(lineas: list) -> tuple:
    """Normaliza las líneas y las valida. Devuelve (lineas_ok, errores) donde
    errores es una lista de textos 'Línea N: motivo'. Las líneas idénticas se
    deduplican (una regla repetida solo daría 'duplicado' en Banner); el
    número de repetidas descartadas va como último elemento de errores si hay."""
    ok, errores, vistas = [], [], set()
    repetidas = 0
    for n, linea in enumerate(lineas, start=1):
        if not linea.strip():
            continue
        try:
            fila = parsear_linea(linea)
        except ValueError as err:
            errores.append(f"Línea {n}: {err}")
            continue
        clave = normalizar_campos([fila[c] for c in ORDEN_COLUMNAS_CSV])
        if clave in vistas:
            repetidas += 1
            continue
        vistas.add(clave)
        ok.append(clave)
    return ok, errores, repetidas


def leer_reglas_de_archivo(ruta: str) -> tuple:
    """Lee un CSV o Excel de 8 columnas POR POSICIÓN. Salta la primera fila si
    parece encabezado (alguna celda contiene 'prioridad'). Devuelve
    (lineas_normalizadas, repetidas_descartadas). Lanza ValueError con un
    mensaje claro si alguna fila no tiene las 8 columnas completas."""
    extension = os.path.splitext(ruta)[1].lower()
    filas_crudas = []

    if extension in (".xlsx", ".xls"):
        import openpyxl  # import perezoso

        libro = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
        for fila in libro.active.iter_rows(values_only=True):
            filas_crudas.append([_a_texto(c) for c in (fila or [])])
    elif extension in (".csv", ".txt"):
        with open(ruta, newline="", encoding="utf-8-sig") as f:
            # Acepta coma o punto y coma (Excel en español guarda con ';').
            muestra = f.read(4096)
            f.seek(0)
            delimitador = ";" if muestra.count(";") > muestra.count(",") else ","
            for fila in csv.reader(f, delimiter=delimitador):
                filas_crudas.append([c.strip() for c in fila])
    else:
        raise ValueError(f"Formato de archivo no soportado: {extension}")

    filas_crudas = [f for f in filas_crudas if any(c for c in f)]
    if filas_crudas and any("prioridad" in c.lower() for c in filas_crudas[0]):
        filas_crudas = filas_crudas[1:]

    lineas = []
    for n, fila in enumerate(filas_crudas, start=1):
        fila = list(fila[: len(ORDEN_COLUMNAS_CSV)])
        fila += [""] * (len(ORDEN_COLUMNAS_CSV) - len(fila))
        lineas.append(normalizar_campos(fila))

    ok, errores, repetidas = validar_lineas(lineas)
    if errores:
        raise ValueError(
            "El archivo tiene filas incompletas (se esperan 8 columnas: "
            + ENCABEZADO_LEGIBLE + "). " + " | ".join(errores[:5])
            + (f" ... y {len(errores) - 5} más" if len(errores) > 5 else "")
        )
    return ok, repetidas


# ------------------------------------------------------------------
# REGISTRO DE REGLAS CON ERROR (CSV con las 8 columnas + motivo, para
# revisarlas o reimportarlas después)
# ------------------------------------------------------------------

_archivo_errores = None


def _ruta_archivo_errores() -> str:
    global _archivo_errores
    if _archivo_errores is None:
        carpeta = os.path.join(carpeta_logs(), "sfabrdf_errores")
        os.makedirs(carpeta, exist_ok=True)
        marca = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        _archivo_errores = os.path.join(carpeta, f"filas_con_error_{marca}.csv")
    return _archivo_errores


def ruta_txt_errores() -> str:
    """TXT de la corrida actual: mismas 8 columnas del CSV de reglas, una regla
    por línea, SIN encabezado ni motivo (se puede importar tal cual para reintentar).
    Comparte nombre con el CSV de errores: solo cambia la extensión."""
    return os.path.splitext(_ruta_archivo_errores())[0].replace("filas_con_error_", "reglas_con_error_") + ".txt"


def hay_errores_en_corrida() -> bool:
    return _archivo_errores is not None and os.path.exists(ruta_txt_errores())


def registrar_fila_error(fila: dict, motivo: str) -> None:
    ruta = _ruta_archivo_errores()
    es_nuevo = not os.path.exists(ruta)
    with open(ruta, "a", newline="", encoding="utf-8-sig") as f:
        escritor = csv.writer(f)
        if es_nuevo:
            escritor.writerow(ORDEN_COLUMNAS_CSV + ["motivo"])
        escritor.writerow([fila.get(c, "") for c in ORDEN_COLUMNAS_CSV] + [motivo])
    with open(ruta_txt_errores(), "a", encoding="utf-8") as f:
        f.write(",".join(str(fila.get(c, "")).strip() for c in ORDEN_COLUMNAS_CSV) + "\n")


# ------------------------------------------------------------------
# DETECCIÓN DE MENSAJES DE BANNER (español e inglés)
#
# Banner muestra los mensajes en el idioma del navegador y se comporta
# distinto según la máquina, por eso TODAS las listas llevan ambos idiomas.
# Solo se lee el texto VISIBLE en pantalla (no el HTML ni el innerText
# completo, que incluyen texto oculto y avisos viejos -> falsos duplicados).
# ------------------------------------------------------------------

FRASES_GUARDADO_OK = [
    # inglés
    "saved successfully",
    "no changes to save",
    "changes saved",
    "record saved",
    "transaction complete",
    # español - texto REAL: "Guardado con suceso (2 registros guardados)"
    "guardado con suceso",
    "guardado con éxito",
    "guardado con exito",
    "guardado exitosamente",
    "guardado correctamente",
    "sin cambios que guardar",
    "no hay cambios que guardar",
    "cambios guardados",
]

# Mensaje REAL de duplicado: "*ERROR* El registro de la regla que está
# tratando de insertar está duplicado. Por favor, inserte una nueva regla."
FRASE_DUPLICADO_ES = "el registro de la regla que esta tratando de insertar esta duplicado"
PATRON_DUPLICADO_EN = re.compile(r"\*error\*[\s\S]{0,200}?(duplicate|duplicated|already exists)")

# Errores que NO son fallo del guardado (tecla inválida en el contexto actual).
FRASES_ERROR_IGNORABLES = ["funcion invalida", "invalid function"]


def _normalizar(texto: str) -> str:
    """Minúsculas, sin tildes y con espacios/saltos de línea colapsados."""
    sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto) if unicodedata.category(c) != "Mn"
    )
    return " ".join(sin_tildes.lower().split())


def _fragmento(contenido: str, ini: int, fin: int) -> str:
    return " ".join(contenido[max(0, ini - 20): min(len(contenido), fin + 80)].split())


def _buscar_duplicado(contenido: str):
    t = _normalizar(contenido)
    pos = t.find(FRASE_DUPLICADO_ES)
    if pos >= 0:
        return _fragmento(t, pos, pos + len(FRASE_DUPLICADO_ES))
    m = PATRON_DUPLICADO_EN.search(t)
    return _fragmento(t, m.start(), m.end()) if m else None


def _buscar_error(contenido: str):
    """Fragmento del primer '*ERROR*' que sí cuenta como fallo, o None."""
    for m in re.finditer(r"\*error\*", contenido):
        cola = _normalizar(contenido[m.start(): m.end() + 150])
        if any(f in cola for f in FRASES_ERROR_IGNORABLES):
            continue
        return _fragmento(contenido, m.start(), m.end())
    return None


def _contar_avisos(contenido: str):
    """(n_exito, n_error): cuántos avisos de éxito y de error hay en pantalla."""
    n_ok = sum(contenido.count(f) for f in FRASES_GUARDADO_OK)
    return n_ok, contenido.count("*error*")


# ------------------------------------------------------------------
# SCRIPTS JS (se ejecutan DENTRO del iframe del formulario con
# frame.evaluate; Playwright no necesita cambiar de contexto como Selenium)
# ------------------------------------------------------------------

# Estado del elemento con foco: columna real (aria-labelledby "..._col<N>_lbl",
# estable aunque el id del input sea dinámico), cuántas columnas tiene SU
# grilla (superior ~14 / inferior ~4) y su valor.
_JS_FOCO = r"""() => {
  const a = document.activeElement;
  if (!a) return null;
  const aria = a.getAttribute('aria-labelledby') || '';
  const mc = aria.match(/_col(\d+)_lbl/);
  const mp = aria.match(/^(.*)_col\d+_lbl$/);
  let ncols = -1;
  if (mp) ncols = document.querySelectorAll('[id^="' + mp[1] + '_col"][id$="_lbl"]').length;
  return {
    tag: (a.tagName || '').toLowerCase(),
    col: mc ? parseInt(mc[1], 10) : null,
    ncols: ncols,
    value: (a.value === undefined ? null : a.value),
    id: a.id || '',
    aria: aria
  };
}"""

# Texto de cada celda de la fila activa (SlickGrid: .slick-cell con clase
# l<N> = columna N). '__EDIT__' si la celda está en edición (tiene un input).
_JS_FILA_ACTIVA = r"""() => {
  const a = document.activeElement;
  let row = null;
  if (a && a.closest) row = a.closest('.slick-row');
  if (!row) row = document.querySelector('.slick-row.active');
  if (!row) { const c = document.querySelector('.slick-cell.active'); if (c) row = c.closest('.slick-row'); }
  if (!row) return null;
  const out = {};
  row.querySelectorAll('.slick-cell').forEach(function(c) {
    const m = (c.className || '').match(/(?:^|\s)l(\d+)(?:\s|$)/);
    if (!m) return;
    out[m[1]] = c.querySelector('input[type=text], input:not([type])') ? '__EDIT__' : (c.innerText || '').trim();
  });
  return out;
}"""

# Texto que SE VE de verdad (no el innerText, que incluye texto invisible de
# 1 px para lectores de pantalla y avisos viejos) del frame actual + del
# documento superior (shell de Banner, donde aparecen los avisos).
_JS_TEXTO_VISIBLE = r"""() => {
  function tv(doc) {
    if (!doc || !doc.body) return '';
    const out = [];
    const cache = new Map();
    const w = doc.createTreeWalker(doc.body, 4, null);
    let n;
    while ((n = w.nextNode())) {
      const t = n.nodeValue;
      if (!t || !t.trim()) continue;
      const el = n.parentElement;
      if (!el) continue;
      const tag = el.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') continue;
      let vis = cache.get(el);
      if (vis === undefined) {
        const r = el.getBoundingClientRect();
        vis = (r.width >= 4 && r.height >= 4);
        if (vis && el.checkVisibility) {
          vis = el.checkVisibility({checkOpacity: true, checkVisibilityCSS: true});
        }
        cache.set(el, vis);
      }
      if (vis) out.push(t.trim());
    }
    return out.join(' ');
  }
  const partes = [tv(document)];
  try { if (window.top !== window) partes.push(tv(window.top.document)); } catch (e) {}
  return partes.join('\n');
}"""


# Igual que _JS_TEXTO_VISIBLE, pero devuelve la lista de textos (uno por nodo)
# en vez de un solo string: sirve para saber qué texto APARECIÓ tras F10
# comparando contra lo que ya estaba en pantalla antes.
_JS_TEXTOS_VISIBLES = r"""() => {
  function tv(doc) {
    const out = [];
    if (!doc || !doc.body) return out;
    const cache = new Map();
    const w = doc.createTreeWalker(doc.body, 4, null);
    let n;
    while ((n = w.nextNode())) {
      const t = n.nodeValue;
      if (!t || !t.trim()) continue;
      const el = n.parentElement;
      if (!el) continue;
      const tag = el.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') continue;
      let vis = cache.get(el);
      if (vis === undefined) {
        const r = el.getBoundingClientRect();
        vis = (r.width >= 4 && r.height >= 4);
        if (vis && el.checkVisibility) {
          vis = el.checkVisibility({checkOpacity: true, checkVisibilityCSS: true});
        }
        cache.set(el, vis);
      }
      if (vis) out.push(t.trim());
    }
    return out;
  }
  let res = tv(document);
  try { if (window.top !== window) res = res.concat(tv(window.top.document)); } catch (e) {}
  return res;
}"""


def _en_grilla_inferior(foco) -> bool:
    """True SOLO si se sabe con certeza que el foco está en una grilla de pocas
    columnas (la inferior). Si no se puede determinar, False (no bloquea)."""
    if not foco:
        return False
    n = foco.get("ncols", -1)
    return isinstance(n, (int, float)) and 0 < n < MIN_COLUMNAS_GRILLA_SUPERIOR


async def _pausa(segundos: float) -> None:
    if segundos > 0:
        await asyncio.sleep(segundos)


# ------------------------------------------------------------------
# UNA PESTAÑA DE TRABAJO
# ------------------------------------------------------------------

class VentanaSFABRDF:
    """Una pestaña (Page) del contexto compartido, con su propio estado:
    el frame del formulario, cuántas reglas guardó (para el refresco cada 50)
    y su log. Todas las operaciones de teclado/lectura son métodos de esta
    clase para no pasar pagina/marco/log a cada función."""

    def __init__(self, pagina, periodo: str, on_log, contexto=None):
        self.pagina = pagina
        self.contexto = contexto
        self.periodo = periodo
        self.log = on_log
        self.marco = None
        self.guardadas = 0

    # ----------------------------------------------------- utilidades base --

    async def _tecla(self, combinacion: str) -> None:
        await self.pagina.keyboard.press(combinacion)

    async def _foco(self):
        """Estado del elemento con foco, o None si no se pudo leer (por ej.
        el frame se estaba redibujando)."""
        try:
            return await self.marco.evaluate(_JS_FOCO)
        except Exception:
            return None

    async def _texto_visible(self) -> str:
        try:
            return ((await self.marco.evaluate(_JS_TEXTO_VISIBLE)) or "").lower()
        except Exception:
            return ""

    async def _textos_visibles(self) -> list:
        try:
            return list((await self.marco.evaluate(_JS_TEXTOS_VISIBLES)) or [])
        except Exception:
            return []

    async def _leer_fila_activa(self):
        try:
            return await self.marco.evaluate(_JS_FILA_ACTIVA)
        except Exception:
            return None

    async def _asegurar_marco(self) -> None:
        """Si Banner reemplazó el iframe (el Frame quedó desprendido), se vuelve
        a ubicar buscando el frame que contiene la barra de la forma."""
        try:
            if self.marco is not None and not self.marco.is_detached():
                return
        except Exception:
            pass
        self.marco = await _encontrar_frame(self.pagina, "i.ba-add", timeout_ms=15000)

    async def _esperar_boton_insertar(self, timeout_ms: int = 15000) -> bool:
        """El ícono 'Insertar' de la barra de la forma sirve como señal de que
        la página respondió (no se le hace clic: se inserta con F6)."""
        try:
            await self.marco.wait_for_selector("i.ba-add", state="visible", timeout=timeout_ms)
            return True
        except Exception:
            self.log("  ADVERTENCIA: no se pudo confirmar que el botón Insertar esté listo (timeout)")
            return False

    # ------------------------------------------------- abrir forma + periodo --

    async def _lanzar_si_sesion_expirada(self, contexto_msg: str = "") -> None:
        if _requiere_reautenticacion(self.pagina) or await _pantalla_muestra_sesion_expirada(self.pagina):
            raise SesionExpiradaError(
                "La sesión de Banner expiró (pantalla de error de autenticación externa). "
                "Hay que iniciar sesión de nuevo."
            )

    async def abrir_forma(self) -> None:
        """Camino completo: recarga Banner, busca SFABRDF, escribe el Periodo y
        entra a la grilla (Alt+PageDown). Se usa al arrancar cada pestaña y
        para recuperarse tras un fallo o un duplicado."""
        p = self.pagina
        await p.goto(BANNER_URL, wait_until="domcontentloaded")

        if _requiere_reautenticacion(p):
            await self._lanzar_si_sesion_expirada()
        await p.wait_for_timeout(1500)
        await self._lanzar_si_sesion_expirada()

        try:
            await p.wait_for_selector(SELECTOR_BUSQUEDA, timeout=30000)
        except PlaywrightTimeoutError:
            await self._lanzar_si_sesion_expirada()
            raise

        await p.wait_for_timeout(400)  # margen: Angular conecta sus manejadores
        if not await _tecleo_confiable(p, SELECTOR_BUSQUEDA, NOMBRE_FORMA, self.log):
            raise RuntimeError(f'No se pudo escribir "{NOMBRE_FORMA}" en el buscador de forma confiable')
        await p.wait_for_timeout(2500)  # autocompletado

        try:
            sugerencia = p.locator(f"text={NOMBRE_FORMA}").filter(
                has_not=p.locator(SELECTOR_BUSQUEDA)
            ).first
            if await sugerencia.is_visible(timeout=1500):
                await sugerencia.click()
            else:
                await p.keyboard.press("Enter")
        except Exception:
            await p.keyboard.press("Enter")

        try:
            self.marco = await _encontrar_frame(p, SELECTOR_CAMPO_PERIODO, timeout_ms=40000)
        except PlaywrightTimeoutError:
            await self._lanzar_si_sesion_expirada()
            raise

        # No basta con que el campo exista: hay que esperar a que esté
        # habilitado (Banner a veces lo deja presente pero deshabilitado
        # mientras termina de cargar, sobre todo en la primera carga).
        campo = self.marco.locator(SELECTOR_CAMPO_PERIODO)
        fin = time.monotonic() + 20
        while time.monotonic() < fin:
            try:
                if await campo.is_enabled():
                    break
            except Exception:
                pass
            await asyncio.sleep(0.2)
        await asyncio.sleep(1.5)  # margen extra tras habilitarse

        if not await _tecleo_confiable(self.marco, SELECTOR_CAMPO_PERIODO, self.periodo, self.log):
            raise RuntimeError(f'No se pudo escribir el periodo "{self.periodo}" de forma confiable')

        # Alt+PageDown (NO Enter) es lo que avanza tras escribir el Periodo.
        await self._tecla("Alt+PageDown")
        await asyncio.sleep(1)
        await self._asegurar_marco()
        await self._esperar_boton_insertar()
        self.log(f"Periodo {self.periodo} aplicado.")

    async def refrescar_grilla(self) -> None:
        """F5 dentro de Banner NO recarga la página: reinicia el formulario
        conservando el Periodo. Solo hace falta Alt+PageDown para volver a
        entrar a la grilla."""
        self.log(f"--- Refrescando Banner (F5) tras {FILAS_ANTES_DE_REFRESCAR} reglas guardadas ---")
        await self._tecla("F5")
        await asyncio.sleep(2)
        await self._tecla("Alt+PageDown")
        await asyncio.sleep(1.5)
        await self._asegurar_marco()

    # ------------------------------------------------------------- F6 --

    async def insertar_fila(self, intentos: int = 3, espera_por_intento: float = 3.0) -> None:
        # ANTES de F6 el foco debe estar en la grilla superior. Si Alt+PageUp
        # no surtió efecto y seguimos en "Atributos del bloque", F6 insertaría
        # la fila ALLÍ (el valor de Prioridad terminaba en el campo Bloque).
        for _ in range(3):
            if not _en_grilla_inferior(await self._foco()):
                break
            self.log("  (el foco sigue en 'Atributos del bloque'; se reenvía Alt+PageUp antes de insertar)")
            await self._tecla("Alt+PageUp")
            await asyncio.sleep(0.4)
        else:
            raise RuntimeError("el foco no regresa a la grilla superior (sigue en 'Atributos del bloque')")

        for intento in range(1, intentos + 1):
            await self._esperar_boton_insertar()
            await self._tecla("F6")
            await _pausa(ESPERA_TRAS_F6)

            # Espera condicional: F6 se reenvía SOLO si se agota el tiempo, así
            # un F6 lento no provoca una segunda fila insertada.
            fin = time.monotonic() + espera_por_intento
            while time.monotonic() < fin:
                foco = await self._foco()
                if _en_grilla_inferior(foco):
                    raise RuntimeError("F6 insertó una fila en la grilla inferior (Atributos del bloque)")
                if (
                    foco and foco["col"] == 0 and not _en_grilla_inferior(foco)
                    and (foco.get("value") or "") == ""
                ):
                    return
                await asyncio.sleep(0.05)

            foco = await self._foco()
            self.log(
                f"  reintento F6 ({intento}/{intentos}): columna={foco['col'] if foco else None} "
                f"(esperaba columna 0 vacía tras {espera_por_intento}s)"
            )
        raise RuntimeError("no se pudo confirmar que la fila se insertó tras varios intentos de F6")

    # ---------------------------------------------------------- Tab / filas --

    async def _tab_y_esperar_cambio(self, timeout: float = 2.0) -> bool:
        """Envía Tab y espera a que el foco aterrice en una celda NUEVA con
        columna identificable, más una pausa fija tras aterrizar (Banner valida
        el campo que se acaba de dejar y puede redibujar la fila). El paso
        transitorio por <body> NO cuenta como 'el foco se movió'."""
        f0 = await self._foco()
        col_antes = f0["col"] if f0 else None
        await self._tecla("Tab")
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            await asyncio.sleep(0.03)
            f = await self._foco()
            col = f["col"] if f else None
            if col is not None and col != col_antes:
                await asyncio.sleep(0.05)  # confirmación: aterrizaje estable
                f2 = await self._foco()
                if f2 and f2["col"] == col:
                    await _pausa(ESPERA_TRAS_TAB)
                    return True
        self.log("  (el foco no aterrizó en una celda nueva tras Tab dentro del tiempo esperado)")
        await _pausa(ESPERA_TRAS_TAB)
        return False

    async def _esperar_columna_definida(self, timeout: float = 1.5):
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            f = await self._foco()
            if f and f["col"] is not None:
                return f["col"]
            await asyncio.sleep(0.05)
        return None

    async def _asegurar_columna_activa(self, col_esperada: int, max_tabs: int = 8) -> bool:
        """Tabula hasta que el foco quede sobre la columna esperada, verificando
        la columna REAL en cada paso (Banner a veces SÍ se detiene en columnas
        como Escuela/Grado según el Nivel, así que no se asume un nº de Tabs)."""
        fueras_seguidos = 0
        tabs_sin_avance = 0
        for _ in range(max_tabs):
            f = await self._foco()
            if (f is None or f["col"] is None):
                await self._esperar_columna_definida(timeout=1.5)
                f = await self._foco()

            fuera = (f is None) or f["tag"] == "body"
            if fuera:
                fueras_seguidos += 1
                if fueras_seguidos >= 2:
                    self.log("  ADVERTENCIA: el foco se salió de la grilla (posible error bloqueante de Banner) - se aborta esta fila")
                    return False
            else:
                fueras_seguidos = 0

            actual = f["col"] if f else None
            if actual == col_esperada:
                return True
            if actual is not None and actual > col_esperada:
                self.log(f"  ADVERTENCIA: se esperaba columna {col_esperada}, el foco ya pasó a columna {actual}")
                return False
            if await self._tab_y_esperar_cambio():
                tabs_sin_avance = 0
            else:
                tabs_sin_avance += 1
                if tabs_sin_avance >= 2:
                    self.log("  ADVERTENCIA: el foco no avanza con Tab (2 intentos seguidos) - se aborta esta fila")
                    self.log(f"    diagnóstico del elemento activo: {await self._foco()}")
                    return False
        self.log(f"  ADVERTENCIA: no se pudo confirmar llegar a la columna {col_esperada} tras {max_tabs} Tabs")
        self.log(f"    diagnóstico del elemento activo: {await self._foco()}")
        return False

    async def _escribir_en_activo(self, valor: str, intentos: int = 3) -> bool:
        """Escribe sobre el <input> con foco (ids dinámicos de SlickGrid, no se
        puede guardar la referencia) y verifica el valor leído."""
        valor = str(valor)
        for intento in range(1, intentos + 1):
            try:
                await self.pagina.keyboard.press("Control+a")
                await self.pagina.keyboard.press("Delete")
                await asyncio.sleep(0.05)
                if intento == 1 and not TECLEO_POR_CARACTER:
                    await self.pagina.keyboard.type(valor)  # ráfaga sin pausas
                else:
                    await self.pagina.keyboard.type(valor, delay=30)  # carácter por carácter
                await asyncio.sleep(ESPERA_TRAS_TECLEO)
                foco = await self._foco()
                actual = foco["value"] if foco else None
            except Exception as err:
                self.log(f"  reintento tecleo activo ({intento}/{intentos}): el campo se redibujó ({type(err).__name__})")
                await asyncio.sleep(0.2)
                continue
            if actual == valor:
                return True
            self.log(f"  reintento tecleo activo ({intento}/{intentos}): esperado='{valor}' obtenido='{actual}'")
        return False

    async def _describir_fila_activa(self) -> str:
        celdas = await self._leer_fila_activa()
        if not isinstance(celdas, dict):
            return "(no se pudo leer la fila)"
        partes = []
        for col, nombre in sorted(MAPA_COLUMNAS_GRILLA.items()):
            v = celdas.get(str(col))
            partes.append(f"{nombre}={'(vacío)' if v == '' else ('<editando>' if v == '__EDIT__' else v)}")
        return ", ".join(partes)

    _aviso_fila_ilegible = False

    async def _verificar_fila_llena(self, fila: dict, columnas_escritas=None) -> bool:
        """False si alguna celda YA ESCRITA de la fila activa NO muestra el valor
        esperado (Banner la borró/cambió tras una validación tardía del
        servidor). `columnas_escritas` = índices de columna ya llenados; las
        demás se ignoran (todavía están vacías, es lo normal). None = todas."""
        celdas = await self._leer_fila_activa()
        if not isinstance(celdas, dict) or not celdas:
            if not VentanaSFABRDF._aviso_fila_ilegible:
                VentanaSFABRDF._aviso_fila_ilegible = True
                self.log("  (no se pudo leer el texto de las celdas de la fila; se omite esta verificación)")
            return True
        distintas = []
        for col, nombre in sorted(MAPA_COLUMNAS_GRILLA.items()):
            if columnas_escritas is not None and col not in columnas_escritas:
                continue
            esperado = (fila.get(nombre, "") or "").strip()
            actual = celdas.get(str(col))
            if not esperado or actual is None or actual == "__EDIT__":
                continue
            if actual.strip().upper() != esperado.upper():
                distintas.append(f"{nombre}: esperado='{esperado}' en pantalla='{actual}'")
        if distintas:
            self.log("  ADVERTENCIA: Banner borró/cambió valores de la fila tras escribirlos -> " + "; ".join(distintas))
            return False
        return True

    async def llenar_fila_grilla(self, fila: dict) -> bool:
        columnas = sorted(MAPA_COLUMNAS_GRILLA.items())
        for i, (col_index, nombre) in enumerate(columnas):
            if not await self._asegurar_columna_activa(col_index):
                self.log(f"  estado de la fila al abortar: {await self._describir_fila_activa()}")
                return False

            valor = fila.get(nombre, "")
            if valor and not await self._escribir_en_activo(valor):
                self.log(f"  ADVERTENCIA: no se pudo confirmar el valor de '{nombre}'")
                return False

            if i < len(columnas) - 1:
                await self._tab_y_esperar_cambio()
                # Los valores ya escritos deben SEGUIR en pantalla (solo las
                # columnas que ya se llenaron; las siguientes aún están vacías).
                escritas = {c for c, _ in columnas[: i + 1]}
                if i >= 2 and not await self._verificar_fila_llena(fila, escritas):
                    return False

        await asyncio.sleep(0.2)
        return await self._verificar_fila_llena(fila)

    async def llenar_campo_bloque(self, valor: str, intentos: int = 3) -> bool:
        for intento in range(1, intentos + 1):
            await self._tecla("Alt+PageDown")  # salta DIRECTO al campo Bloque
            await asyncio.sleep(0.25)
            foco = await self._foco()
            if foco and foco["tag"] == "input":
                break
            self.log(
                f"  reintento Alt+PageDown hacia Bloque ({intento}/{intentos}): el foco no cayó "
                f"sobre un <input> (tag={foco['tag'] if foco else None})"
            )
            await asyncio.sleep(0.4)
        else:
            self.log("  ADVERTENCIA CRÍTICA: no se pudo llegar al campo Bloque como input real, no se escribirá el valor")
            return False

        ok = await self._escribir_en_activo(valor)
        if not ok:
            self.log("  ADVERTENCIA: no se pudo confirmar el valor del campo Bloque")
        # Tab confirma el valor y autocompleta "Descripción del bloque".
        await self._tecla("Tab")
        await asyncio.sleep(0.3)
        return ok

    # --------------------------------------------------------------- F10 --

    async def _leer_confirmacion_guardado(self, base=(0, 0), timeout: float = 6.0):
        """(estado, detalle): 'ok' | 'duplicado' | 'error' | 'desconocido'.
        `base` = avisos que YA había en pantalla antes de F10: solo cuenta como
        resultado de ESTE guardado un aviso adicional a esos."""
        base_ok, base_err = base
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            contenido = await self._texto_visible()
            n_ok, n_err = _contar_avisos(contenido)

            if n_ok > base_ok:
                for frase in FRASES_GUARDADO_OK:
                    pos = contenido.find(frase)
                    if pos >= 0:
                        return "ok", _fragmento(contenido, pos, pos + len(frase))

            if n_err > base_err:
                dup = _buscar_duplicado(contenido)
                if dup:
                    return "duplicado", dup
                err = _buscar_error(contenido)
                if err:
                    return "error", err

            await asyncio.sleep(0.15)
        return "desconocido", ""

    async def _esperar_sin_aviso(self, timeout: float = 4.0) -> bool:
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            if _contar_avisos(await self._texto_visible()) == (0, 0):
                return True
            await asyncio.sleep(0.1)
        return False

    async def _volver_a_grilla_superior(self, espera_foco: float = 2.0) -> None:
        """Alt+PageUp regresa el foco a la grilla de reglas (necesario ANTES del
        siguiente F6). Solo se reenvía si se SABE que el foco sigue abajo:
        reenviarlo estando ya arriba es una 'Función inválida' para Banner."""
        for envio in range(2):
            await self._tecla("Alt+PageUp")
            fin = time.monotonic() + espera_foco
            while time.monotonic() < fin:
                if not _en_grilla_inferior(await self._foco()):
                    await _pausa(ESPERA_TRAS_ALT_PGUP)
                    return
                await asyncio.sleep(0.05)
            if envio == 0:
                self.log("  (el foco siguió en 'Atributos del bloque' tras Alt+PageUp; se reenvía)")
        raise RuntimeError("el foco no regresó a la grilla superior tras Alt+PageUp")

    async def guardar(self) -> None:
        if not await self._esperar_sin_aviso(timeout=4.0):
            self.log("  (hay un aviso viejo todavía visible antes de F10; se usa como línea base)")
        base = _contar_avisos(await self._texto_visible())
        textos_antes = set(await self._textos_visibles())

        await self._tecla("F10")
        await _pausa(ESPERA_TRAS_F10)

        resultado, detalle = await self._leer_confirmacion_guardado(base=base)
        if resultado == "duplicado":
            raise ReglaDuplicadaError(f"duplicado detectado en el texto: «{detalle}»")
        if resultado == "error":
            raise RuntimeError(f"Banner mostró un mensaje de error tras F10: «{detalle}»")
        if resultado == "desconocido":
            if ASUMIR_OK_SI_NO_HAY_MENSAJE:
                self.log("  (no se detectó mensaje de guardado conocido - se asume OK, verificar manualmente si hay dudas)")
            else:
                # Se captura lo que Banner SÍ mostró: el texto que apareció en
                # pantalla después de F10 (no estaba antes). Ese es el mensaje
                # real; si es un éxito con otra redacción, basta agregarlo a
                # FRASES_GUARDADO_OK.
                nuevos = [t for t in await self._textos_visibles() if t not in textos_antes]
                visto = " | ".join(nuevos)[:400] if nuevos else "(no apareció ningún texto nuevo en pantalla)"
                self.log(f"  [DIAG] texto nuevo en pantalla tras F10: {visto}")
                raise RuntimeError(
                    "no se confirmó el guardado: ningún mensaje de éxito conocido tras F10. "
                    f"Banner mostró: «{visto}». "
                    "Si es un éxito con otra redacción, agrégala a FRASES_GUARDADO_OK."
                )

        # A PARTIR DE AQUÍ LA REGLA YA ESTÁ GUARDADA. Cualquier problema al
        # volver a la grilla superior NO debe lanzar excepción: si lo hiciera,
        # la escalera de reintentos volvería a insertar la misma regla y
        # Banner respondería "duplicado" (origen de los falsos duplicados).
        try:
            await self._volver_a_grilla_superior()
        except Exception as err:
            self.log(
                f"  ADVERTENCIA: la regla SÍ se guardó, pero falló el regreso a la grilla superior "
                f"({type(err).__name__}). Se recarga la forma para continuar limpio."
            )
            try:
                await self.abrir_forma()
            except SesionExpiradaError:
                raise
            except Exception as err2:
                self.log(f"  (no se pudo recargar: {err2}; la siguiente regla intentará recuperarse sola)")

    # ------------------------------------------------- una regla completa --

    async def _intentar_procesar_fila(self, fila: dict) -> None:
        await self._asegurar_marco()
        await self.insertar_fila()
        if not await self.llenar_fila_grilla(fila):
            # NO se intenta el campo Bloque si la fila de arriba quedó
            # incompleta: escribir ahí un valor corrupto dispara un error
            # BLOQUEANTE de Banner que encadena fallas en las filas siguientes.
            raise RuntimeError("fila incompleta: no se pudieron llenar todos los campos de la grilla")
        if not await self.llenar_campo_bloque(fila.get("bloque", "")):
            raise RuntimeError("no se pudo escribir el campo Bloque")
        await self.guardar()

    async def _recargar(self) -> None:
        await self.abrir_forma()

    async def procesar_fila_con_reintentos(self, fila: dict, etiqueta: str):
        """Devuelve (estado, error): 'ok' | 'duplicado' | 'sesion_expirada' |
        'fallo'. Escalera: intento -> falla -> recargar forma completa ->
        reintento -> falla -> se rinde (y recarga para dejar limpia la pestaña)."""
        ultimo_error = None
        for intento in range(MAX_INTENTOS_POR_FILA):
            try:
                await asyncio.wait_for(
                    self._intentar_procesar_fila(fila), timeout=LIMITE_SEGUNDOS_POR_INTENTO
                )
                return "ok", None

            except ReglaDuplicadaError as err:
                err.tras_reintento = intento > 0
                self.log(
                    f"  DUPLICADO (bloque={fila.get('bloque')}): {err}"
                    + (" [tras un reintento: probablemente la regla YA se había guardado en el intento anterior]"
                       if err.tras_reintento else "")
                )
                ruta = await _guardar_captura_error(self.pagina, f"sfabrdf_duplicado_{fila.get('bloque', 'sinbloque')}")
                if ruta:
                    self.log(f"  (captura: {ruta})")
                self.log("  Recargando la página completa para continuar con la siguiente regla...")
                try:
                    await self._recargar()
                except SesionExpiradaError as e2:
                    return "sesion_expirada", e2
                except Exception as e2:
                    try:
                        if _requiere_reautenticacion(self.pagina) or await _pantalla_muestra_sesion_expirada(self.pagina):
                            return "sesion_expirada", SesionExpiradaError(str(e2))
                    except Exception:
                        pass
                    self.log(f"  ADVERTENCIA: falló la recarga tras el duplicado: {e2}")
                return "duplicado", err

            except asyncio.TimeoutError:
                ultimo_error = RuntimeError(
                    f"se agotó el límite de {LIMITE_SEGUNDOS_POR_INTENTO}s para este intento (posible cuelgue)"
                )
                self.log(f"  intento {intento + 1}/{MAX_INTENTOS_POR_FILA} falló: {ultimo_error}")

            except Exception as err:
                ultimo_error = err
                # Chequeo universal: sin importar en qué paso falló, se revisa
                # el estado REAL de la página antes de clasificar el fallo.
                try:
                    if (
                        isinstance(err, SesionExpiradaError)
                        or _requiere_reautenticacion(self.pagina)
                        or await _pantalla_muestra_sesion_expirada(self.pagina)
                    ):
                        return "sesion_expirada", SesionExpiradaError(str(err))
                except Exception:
                    pass
                ruta = await _guardar_captura_error(self.pagina, f"sfabrdf_{fila.get('bloque', 'sinbloque')}")
                self.log(
                    f"  intento {intento + 1}/{MAX_INTENTOS_POR_FILA} falló: {err}"
                    + (f" (captura: {ruta})" if ruta else "")
                )

            # Recuperación tras un fallo: recargar la forma COMPLETA. También
            # tras el ÚLTIMO intento, para que la siguiente regla empiece
            # sobre una pantalla limpia y no sobre el estado roto de esta.
            ultimo_intento = intento == MAX_INTENTOS_POR_FILA - 1
            if ultimo_intento:
                self.log("  Se agotaron los intentos de esta regla; recargando la página para continuar con la siguiente...")
            try:
                await asyncio.wait_for(self._recargar(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
            except SesionExpiradaError as e2:
                return "sesion_expirada", e2
            except Exception as e2:
                if not isinstance(e2, asyncio.TimeoutError):
                    try:
                        if _requiere_reautenticacion(self.pagina) or await _pantalla_muestra_sesion_expirada(self.pagina):
                            return "sesion_expirada", SesionExpiradaError(str(e2))
                    except Exception:
                        pass
                if not ultimo_intento:
                    ultimo_error = e2
                else:
                    self.log(f"  ADVERTENCIA: falló la recarga tras agotar los intentos: {e2}")
                # Si la pestaña quedó inservible, se intenta reabrirla.
                await self._reabrir_pagina_si_hace_falta()

        return "fallo", ultimo_error

    async def reabrir_pagina(self) -> None:
        """Cierra esta pestaña y abre una nueva (misma sesión de login). Es el
        último recurso de la escalera de recuperación, como en SSASECT."""
        try:
            await asyncio.wait_for(self.pagina.close(), timeout=10)
        except Exception:
            pass
        if self.contexto is None:
            raise RuntimeError("no hay contexto para reabrir la pestaña")
        self.pagina = await asyncio.wait_for(_pagina_nueva(self.contexto), timeout=15)
        self.marco = None

    async def _reabrir_pagina_si_hace_falta(self) -> None:
        try:
            if not self.pagina.is_closed():
                return
        except Exception:
            pass
        if self.contexto is None:
            return
        try:
            self.pagina = await _pagina_nueva(self.contexto)
            self.marco = None
        except Exception as err:
            self.log(f"  (no se pudo reabrir la pestaña: {err})")


# ------------------------------------------------------------------
# TRABAJADOR (una pestaña) Y LOOP PRINCIPAL
# ------------------------------------------------------------------

async def _trabajador_sfabrdf(
    indice: int,
    contexto,
    cola: "asyncio.Queue[str]",
    periodo: str,
    estado_corrida,
    control,
    evento_detener: asyncio.Event,
    estado_compartido: dict,
    on_log,
    on_progreso,
    on_resumen=None,
):
    """Procesa reglas de la cola compartida una a la vez, en su propia pestaña
    (mismo contexto = misma sesión de login). Sigue tomando reglas hasta que
    la cola se vacía, se cancela la corrida o se activa evento_detener."""
    resumen = on_resumen if on_resumen is not None else on_log
    etiqueta = f"[Pestaña {indice + 1}]"

    def log(mensaje: str):
        on_log(f"{etiqueta} {mensaje}")

    def r(mensaje: str, segundos: float = None):
        """Mensaje del panel de la app; en modo pruebas lleva la pestaña y el tiempo."""
        if MOSTRAR_PESTANA_EN_RESUMEN:
            extra = f" ({segundos:.1f} s)" if segundos is not None else ""
            resumen(f"{etiqueta} {mensaje}{extra}")
        else:
            resumen(mensaje)

    log("Pestaña iniciada.")
    pagina = await _pagina_nueva(contexto)
    ventana = VentanaSFABRDF(pagina, periodo, log, contexto=contexto)

    async def _pestana_se_rinde(sesion_muerta: bool) -> None:
        """Esta pestaña no puede trabajar. Si todavía hay otras pestañas vivas,
        solo esta se retira y las demás siguen (una pestaña con un problema
        pasajero NO debe detener toda la corrida ni borrar la sesión). Solo si
        es la ÚLTIMA viva se detiene todo."""
        if not sesion_muerta:
            estado_compartido["fallo_no_sesion"] = True
        if estado_compartido["tabs_vivas"] > 1:
            log("Esta pestaña no pudo trabajar; se retira. Las demás pestañas continúan.")
            return
        if sesion_muerta and not estado_compartido["fallo_no_sesion"]:
            invalidar_sesion()
            resumen("Error - sesión de Banner expirada, corrida detenida")
        else:
            resumen(f"Error - no se pudo abrir {NOMBRE_FORMA}, corrida detenida")
        evento_detener.set()

    try:
        # Entrada inicial, con la misma escalera de SSASECT: intento -> intento
        # (tras una pausa) -> intento sobre una pestaña NUEVA. La primera carga
        # de una pestaña recién abierta puede toparse con un hipo pasajero del
        # SSO que no significa que la sesión haya muerto de verdad.
        listo = False
        ultimo_error = None
        t_inicio_pestana = time.monotonic()
        for intento in range(3):
            try:
                if intento == 2:
                    log("Reabriendo la pestaña para un último intento...")
                    await ventana.reabrir_pagina()
                await asyncio.wait_for(ventana.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
                listo = True
                break
            except Exception as err:
                ultimo_error = err
                if isinstance(err, SesionExpiradaError):
                    log(f"Pantalla de sesión/autenticación al abrir {NOMBRE_FORMA} (intento {intento + 1}/3): {err}")
                else:
                    log(f"No se pudo abrir {NOMBRE_FORMA} (intento {intento + 1}/3): {err}")
                await asyncio.sleep(2 + indice)  # pausa escalonada entre pestañas
        if listo:
            r("Pestaña lista (SFABRDF abierto)", time.monotonic() - t_inicio_pestana)
        if not listo:
            try:
                sesion_muerta = (
                    isinstance(ultimo_error, SesionExpiradaError)
                    or _requiere_reautenticacion(ventana.pagina)
                    or await _pantalla_muestra_sesion_expirada(ventana.pagina)
                )
            except Exception:
                sesion_muerta = isinstance(ultimo_error, SesionExpiradaError)
            await _pestana_se_rinde(sesion_muerta)
            return

        while not evento_detener.is_set() and not control.cancelado:
            while control.pausado and not control.cancelado and not evento_detener.is_set():
                await asyncio.sleep(0.3)
            if control.cancelado or evento_detener.is_set():
                break

            try:
                clave = cola.get_nowait()
            except asyncio.QueueEmpty:
                log("Sin más reglas en la cola - esta pestaña terminó su parte.")
                break

            try:
                fila = parsear_linea(clave)
            except ValueError as err:
                estado_corrida.marcar_fallo(clave, f"línea inválida: {err}")
                r(f"Regla «{clave}»: Error - línea inválida ({err})")
                on_progreso(clave, len(estado_corrida.procesados), len(estado_corrida.pendientes), len(estado_corrida.fallos))
                continue

            bloque = fila["bloque"]
            log(f"--- Procesando regla (bloque={bloque}, prioridad={fila['prioridad']}) ---")
            t0 = time.monotonic()
            estado, error = await ventana.procesar_fila_con_reintentos(fila, etiqueta)
            duracion = time.monotonic() - t0

            if estado == "ok":
                estado_compartido["fallos_seguidos"] = 0
                ventana.guardadas += 1
                estado_corrida.marcar_exito(clave)
                log(f"Bloque {bloque}: OK ({duracion:.1f} s)")
                r(f"Bloque {bloque}: Procesado", duracion)
                on_progreso(clave, len(estado_corrida.procesados), len(estado_corrida.pendientes), len(estado_corrida.fallos))
                if ventana.guardadas % FILAS_ANTES_DE_REFRESCAR == 0:
                    try:
                        await ventana.refrescar_grilla()
                    except Exception as err:
                        log(f"  ADVERTENCIA: falló el refresco de la grilla: {err}")

            elif estado == "duplicado":
                # Un duplicado es un resultado normal de Banner, no una falla
                # del sistema: no cuenta para el corte por fallos seguidos.
                estado_compartido["fallos_seguidos"] = 0
                if getattr(error, "tras_reintento", False):
                    motivo = "duplicado tras reintento (probablemente YA se guardó en el intento anterior)"
                else:
                    motivo = "duplicado: la regla ya existe en Banner"
                registrar_fila_error(fila, motivo)
                estado_corrida.marcar_fallo(clave, motivo)
                log(f"Bloque {bloque}: marcada como ERROR ({motivo}).")
                r(f"Bloque {bloque}: Error - {motivo}", duracion)
                on_progreso(clave, len(estado_corrida.procesados), len(estado_corrida.pendientes), len(estado_corrida.fallos))

            elif estado == "sesion_expirada":
                # Puede ser un hipo pasajero del SSO en ESTA pestaña. Antes de
                # concluir que la sesión murió: la regla vuelve a la cola (no
                # se marca como fallo; si en realidad sí se había guardado,
                # el reintento saldrá como duplicado y quedará registrado) y
                # esta pestaña intenta recuperarse reabriéndose.
                veces = estado_compartido["reintentos_sesion"].get(clave, 0) + 1
                estado_compartido["reintentos_sesion"][clave] = veces
                if veces > 2:
                    motivo = f"sesión/autenticación falló repetidamente al procesar esta regla: {error}"
                    registrar_fila_error(fila, motivo)
                    estado_corrida.marcar_fallo(clave, motivo)
                    log(f"*** Bloque {bloque} FALLÓ: {motivo} ***")
                    r(f"Bloque {bloque}: Error - {motivo}", duracion)
                    on_progreso(clave, len(estado_corrida.procesados), len(estado_corrida.pendientes), len(estado_corrida.fallos))
                else:
                    cola.put_nowait(clave)
                log("Pantalla de sesión/autenticación detectada; se intenta recuperar esta pestaña...")
                recuperada = False
                for intento_rec in range(2):
                    try:
                        await ventana.reabrir_pagina()
                        await asyncio.wait_for(ventana.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
                        recuperada = True
                        break
                    except Exception as err:
                        log(f"  recuperación {intento_rec + 1}/2 falló: {err}")
                        await asyncio.sleep(2 + indice)
                if recuperada:
                    log("Pestaña recuperada; se continúa.")
                    continue
                # La reglas sin procesar siguen PENDIENTES (no se marcan como
                # fallo): al volver a iniciar sesión se reanudan desde la lista.
                await _pestana_se_rinde(True)
                break

            else:  # "fallo"
                estado_compartido["fallos_seguidos"] += 1
                motivo = f"fallo tras {MAX_INTENTOS_POR_FILA} intentos: {error}"
                registrar_fila_error(fila, motivo)
                estado_corrida.marcar_fallo(clave, motivo)
                log(f"*** Bloque {bloque} FALLÓ: {motivo} - revisar manualmente en Banner. ***")
                r(f"Bloque {bloque}: Error - {error}", duracion)
                on_progreso(clave, len(estado_corrida.procesados), len(estado_corrida.pendientes), len(estado_corrida.fallos))
                if estado_compartido["fallos_seguidos"] >= MAX_FALLOS_SEGUIDOS:
                    log(
                        f"Fallaron {MAX_FALLOS_SEGUIDOS} reglas seguidas: Banner parece no estar "
                        "respondiendo. Deteniendo toda la corrida."
                    )
                    evento_detener.set()
    finally:
        estado_compartido["tabs_vivas"] -= 1
        try:
            await ventana.pagina.close()
        except Exception:
            pass


async def ejecutar_lote_sfabrdf(
    periodo: str,
    lineas: list,
    estado_corrida,
    control,
    on_log,
    on_progreso,
    num_pestanas: int = NUM_PESTANAS,
    on_resumen=None,
    headless: bool = None,
) -> None:
    """Procesa las reglas (líneas de 8 campos) con N pestañas sobre una cola
    compartida. `headless=False` abre una ventana visible (para depurar); si no
    se indica, depende de MOSTRAR_NAVEGADOR."""
    if headless is None:
        headless = not MOSTRAR_NAVEGADOR
    global _archivo_errores
    _archivo_errores = None  # un CSV de errores NUEVO por cada corrida
    resumen = on_resumen if on_resumen is not None else on_log
    ruta = ruta_sesion()
    resumen("Inicializando...")

    n_pestanas = max(1, num_pestanas) if len(lineas) > UMBRAL_PARALELO else 1
    if n_pestanas > 1:
        on_log(f"{len(lineas)} reglas: se procesan en paralelo con {n_pestanas} pestañas.")

    cola: "asyncio.Queue[str]" = asyncio.Queue()
    for linea in lineas:
        cola.put_nowait(linea)

    evento_detener = asyncio.Event()
    estado_compartido = {
        "fallos_seguidos": 0,
        "tabs_vivas": n_pestanas,      # pestañas que aún no terminaron ni se retiraron
        "fallo_no_sesion": False,      # alguna pestaña falló por algo distinto a la sesión
        "reintentos_sesion": {},       # regla -> veces que volvió a la cola por pantalla de sesión
    }

    async with async_playwright() as p:
        navegador = await p.chromium.launch(headless=headless)
        # Viewport amplio: la grilla superior tiene ~14 columnas y todas
        # deben quedar renderizadas.
        contexto = await navegador.new_context(
            storage_state=ruta, locale="es-PE", viewport={"width": 1600, "height": 900}
        )
        tareas = []
        for i in range(n_pestanas):
            tareas.append(asyncio.create_task(_trabajador_sfabrdf(
                i, contexto, cola, periodo, estado_corrida, control, evento_detener,
                estado_compartido, on_log, on_progreso, on_resumen=resumen,
            )))
            if i < n_pestanas - 1:
                await asyncio.sleep(1.5)  # no saturar el arranque de golpe
        await asyncio.gather(*tareas)
        await navegador.close()

    if evento_detener.is_set() and not control.cancelado:
        if not hay_sesion_guardada():
            resumen("Corrida detenida por sesión expirada. Vuelve a abrir la app e inicia sesión con Google antes de reintentar.")
        else:
            resumen("La corrida se detuvo antes de terminar todas las reglas: Banner dejó de responder. Revisa el sistema e intenta de nuevo más tarde.")
    resumen(
        f"Resumen: {len(estado_corrida.procesados)} procesadas, "
        f"{len(estado_corrida.fallos)} fallidas, {len(estado_corrida.pendientes)} pendientes."
    )
    if estado_corrida.fallos and _archivo_errores and os.path.exists(_archivo_errores):
        resumen(f"Reglas con error (TXT para reimportar): {ruta_txt_errores()}")
        resumen(f"Reglas con error con motivo (CSV): {_archivo_errores}")


# ------------------------------------------------------------------
# EJECUCIÓN POR LÍNEA DE COMANDOS (validar en visible antes de usar la app)
# ------------------------------------------------------------------

def _cli() -> None:
    import argparse

    ap = argparse.ArgumentParser(description="Procesa un CSV/Excel de reglas SFABRDF sin la interfaz.")
    ap.add_argument("archivo", help="CSV o Excel con 8 columnas: " + ENCABEZADO_LEGIBLE)
    ap.add_argument("periodo", help="Periodo académico de 6 dígitos, ej. 202620")
    ap.add_argument("--visible", action="store_true", help="abre una ventana de Chrome visible")
    ap.add_argument("--pestanas", type=int, default=1, help="pestañas en paralelo (solo si hay más de %d reglas)" % UMBRAL_PARALELO)
    args = ap.parse_args()

    if not (args.periodo.isdigit() and len(args.periodo) == 6):
        sys.exit("El periodo debe tener exactamente 6 dígitos.")
    if not hay_sesion_guardada():
        sys.exit("No hay sesión guardada: abre la app (python main.py) e inicia sesión con Google primero.")

    lineas, repetidas = leer_reglas_de_archivo(args.archivo)
    if repetidas:
        print(f"(se descartaron {repetidas} reglas repetidas del archivo)")
    print(f"{len(lineas)} reglas a procesar.")

    class _Control:
        pausado = False
        cancelado = False

    estado = EstadoCorrida(ACCION, lineas)
    asyncio.run(ejecutar_lote_sfabrdf(
        periodo=args.periodo,
        lineas=lineas,
        estado_corrida=estado,
        control=_Control(),
        on_log=lambda m: print(f"[{datetime.now():%H:%M:%S}] {m}", flush=True),
        on_progreso=lambda *a: None,
        num_pestanas=args.pestanas,
        headless=not args.visible,
    ))


if __name__ == "__main__":
    _cli()