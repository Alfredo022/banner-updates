# src/state.py
"""
Persistencia del proyecto: rutas portables (relativas al ejecutable, no
fijas) y archivos de texto plano para pendientes/procesados/fallos.

Estructura en disco (a partir de esta versión, organizada por
automatización + un archivo con fecha/hora por cada corrida, para no
perder el historial y para que los contadores en pantalla arranquen en
cero en cada corrida nueva):

    datos/
    └── logs/
        └── <accion>/              (ej. "cambiar_estatus", "alternar_voz")
            ├── pendientes/2026-09-10_14-32-05.txt
            ├── procesados/2026-09-10_14-32-05.txt
            └── fallos/2026-09-10_14-32-05.txt
"""

import sys
import os
import json
from datetime import datetime


def carpeta_base() -> str:
    """Carpeta del ejecutable (portable) o del script si corre sin empaquetar."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def carpeta_datos() -> str:
    """
    Carpeta de datos del usuario (sesión, logs, config).

    Si la app arranca desde el lanzador, este fija AUTOMATIZADOR_DATOS
    (%LOCALAPPDATA%\\AutomatizadorBanner\\datos) para que las actualizaciones
    de código nunca borren sesión ni registros. Sin esa variable (desarrollo,
    pruebas) se usa datos/ junto al proyecto, como siempre.
    """
    ruta = os.environ.get("AUTOMATIZADOR_DATOS") or os.path.join(carpeta_base(), "datos")
    os.makedirs(ruta, exist_ok=True)
    return ruta


def carpeta_logs() -> str:
    ruta = os.path.join(carpeta_datos(), "logs")
    os.makedirs(ruta, exist_ok=True)
    return ruta


def ruta_sesion() -> str:
    """Archivo con storage_state de Playwright (cookies + localStorage de Banner)."""
    return os.path.join(carpeta_datos(), "banner_storage_state.json")


def ruta_perfil_login() -> str:
    """
    Carpeta de perfil persistente para el navegador de LOGIN (headful).
    A diferencia de storage_state (que solo guarda la sesión de Banner
    para las corridas headless), este perfil completo guarda también las
    cookies de Google/Microsoft - así, del segundo login en adelante, si
    tu sesión de Google/Microsoft sigue activa, el SSO se completa solo,
    sin pedir credenciales de nuevo (igual que ya pasa en tu Chrome
    normal cuando haces logout/login en Banner).
    """
    ruta = os.path.join(carpeta_datos(), "perfil_login")
    os.makedirs(ruta, exist_ok=True)
    return ruta


def hay_sesion_guardada() -> bool:
    return os.path.exists(ruta_sesion())


def invalidar_sesion() -> None:
    """
    Borra la sesión guardada cuando Banner reporta que expiró
    ("Authentication Failed"). Así la próxima vez que se abra la app,
    hay_sesion_guardada() devuelve False y se pide un login nuevo, en vez
    de mostrar "Conectado" con una sesión que ya no sirve.
    """
    try:
        os.remove(ruta_sesion())
    except FileNotFoundError:
        pass


def borrar_datos_sesion() -> bool:
    """
    Borra TODOS los datos de sesión: el storage_state de Banner y el perfil del
    navegador de login (con las cookies de Google/Microsoft). Así, al volver a abrir
    la app, el login es obligatorio y completo. No toca logs, pendientes ni config.
    Devuelve True si no quedó nada de la sesión (False si algo no se pudo borrar, por
    ejemplo un archivo bloqueado por un navegador que sigue abierto).
    """
    import shutil
    import time

    perfil = os.path.join(carpeta_datos(), "perfil_login")
    for _ in range(3):  # en Windows el navegador puede tardar un instante en soltar los archivos
        try:
            os.remove(ruta_sesion())
        except FileNotFoundError:
            pass
        except OSError:
            pass
        shutil.rmtree(perfil, ignore_errors=True)
        if not os.path.exists(ruta_sesion()) and not os.path.exists(perfil):
            return True
        time.sleep(0.4)
    return False


# --- Carpetas por automatización -------------------------------------------

def _subcarpeta(accion: str, nombre: str) -> str:
    ruta = os.path.join(carpeta_logs(), accion, nombre)
    os.makedirs(ruta, exist_ok=True)
    return ruta


def carpeta_pendientes(accion: str) -> str:
    return _subcarpeta(accion, "pendientes")


def carpeta_procesados(accion: str) -> str:
    return _subcarpeta(accion, "procesados")


def carpeta_fallos(accion: str) -> str:
    return _subcarpeta(accion, "fallos")


def _leer_lineas(ruta: str) -> list[str]:
    if not os.path.exists(ruta):
        return []
    with open(ruta, "r", encoding="utf-8") as f:
        return [linea.strip() for linea in f if linea.strip()]


def _escribir_lineas(ruta: str, lineas: list[str]) -> None:
    with open(ruta, "w", encoding="utf-8") as f:
        f.write("\n".join(lineas))
        if lineas:
            f.write("\n")


def _agregar_linea(ruta: str, texto: str) -> None:
    marca = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(ruta, "a", encoding="utf-8") as f:
        f.write(f"[{marca}] {texto}\n")


def leer_pendientes_guardados(accion: str) -> list[str]:
    """
    Lee el archivo de pendientes de la corrida MÁS RECIENTE de esta
    automatización (sin importar si quedó vacío o no). Se usa para
    precargar el textarea al abrir la app o al cambiar de automatización.

    Importante: si esa corrida más reciente terminó bien, su archivo
    queda vacío, y eso es justamente la señal correcta de "no hay nada
    pendiente" - no hay que seguir buscando hacia atrás en corridas más
    viejas del historial (antes hacía eso, y terminaba precargando
    pendientes de una corrida vieja/interrumpida en vez de reconocer que
    la última corrida sí se completó).
    """
    carpeta = carpeta_pendientes(accion)
    try:
        archivos = sorted(os.listdir(carpeta), reverse=True)
    except FileNotFoundError:
        return []
    if not archivos:
        return []
    return _leer_lineas(os.path.join(carpeta, archivos[0]))


def listar_fallos(accion: str) -> list[str]:
    """Historial completo de fallos de esta automatización (todas las corridas)."""
    carpeta = carpeta_fallos(accion)
    try:
        archivos = sorted(os.listdir(carpeta), reverse=True)
    except FileNotFoundError:
        return []
    resultado = []
    for nombre in archivos:
        resultado.extend(_leer_lineas(os.path.join(carpeta, nombre)))
    return resultado


class EstadoCorrida:
    """
    Encapsula pendientes/procesados/fallos de UNA corrida de UNA
    automatización, persistiendo en disco tras cada NRC. Cada corrida
    tiene su propio archivo con marca de fecha/hora (no se reescribe el
    de otra corrida), pero los contadores en memoria (self.pendientes,
    self.procesados, self.fallos) sirven para que los chips de la UI
    arranquen en cero cada vez.
    """

    def __init__(self, accion: str, nrcs_iniciales: list[str]):
        marca = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.ruta_pendientes = os.path.join(carpeta_pendientes(accion), f"{marca}.txt")
        self.ruta_procesados = os.path.join(carpeta_procesados(accion), f"{marca}.txt")
        self.ruta_fallos = os.path.join(carpeta_fallos(accion), f"{marca}.txt")

        self.pendientes = list(nrcs_iniciales)
        self.procesados: list[str] = []
        self.fallos: list[str] = []
        self._persistir_pendientes()

    def _persistir_pendientes(self) -> None:
        _escribir_lineas(self.ruta_pendientes, self.pendientes)

    def marcar_exito(self, nrc: str) -> None:
        self.pendientes = [n for n in self.pendientes if n != nrc]
        self.procesados.append(nrc)
        self._persistir_pendientes()
        _agregar_linea(self.ruta_procesados, nrc)

    def marcar_fallo(self, nrc: str, motivo: str) -> None:
        self.pendientes = [n for n in self.pendientes if n != nrc]
        self.fallos.append(nrc)
        self._persistir_pendientes()
        _agregar_linea(self.ruta_fallos, f"{nrc} - {motivo}")


def ruta_log_texto() -> str:
    """
    Archivo de texto plano con TODO lo que muestra el panel de Log de la
    app, con timestamp. Como la automatización corre en segundo plano
    (headless), este archivo es la forma más fácil de compartir el log
    completo de una corrida (por ejemplo para diagnosticar un fallo), en
    vez de tener que copiar el texto manualmente del panel en pantalla.
    """
    return os.path.join(carpeta_datos(), "app.log")


def agregar_log_texto(mensaje: str) -> None:
    marca = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(ruta_log_texto(), "a", encoding="utf-8") as f:
        f.write(f"[{marca}] {mensaje}\n")


def ruta_config() -> str:
    return os.path.join(carpeta_datos(), "config.json")


def leer_num_pestanas(por_defecto: int = 5) -> int:
    """Preferencia guardada de cuántas pestañas usar en paralelo (1-10)."""
    ruta = ruta_config()
    if not os.path.exists(ruta):
        return por_defecto
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            datos = json.load(f)
        valor = int(datos.get("num_pestanas", por_defecto))
        return max(1, min(10, valor))
    except Exception:
        return por_defecto


def guardar_num_pestanas(valor: int) -> None:
    ruta = ruta_config()
    datos = {}
    if os.path.exists(ruta):
        try:
            with open(ruta, "r", encoding="utf-8") as f:
                datos = json.load(f)
        except Exception:
            datos = {}
    datos["num_pestanas"] = max(1, min(10, int(valor)))
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f)