# src/automation_stvblck.py
"""
Automatización de la forma STVBLCK (Validación de código de bloque) con
Playwright (API ASÍNCRONA). Es el puerto a Playwright headless del script de
prueba Selenium `prueba_stvblck_selenium.py`.

Qué hace, por cada código de bloque (una línea = un código):
  1. F6 inserta una fila en blanco en la grilla (foco en "Código de bloque").
  2. Se escribe el código; Banner pasa SOLO a la columna "Descripción" (sin Tab).
  3. Se escribe en "Descripción" el MISMO valor del código.
  4. F10 guarda; se lee el mensaje REAL de Banner:
        éxito   -> "Saved successfully (1 rows saved)" / "Guardado con suceso ..."
        rechazo -> "Failed to insert record" (es el MISMO aviso para un
                   duplicado y para otros rechazos de inserción: no se puede
                   distinguir por texto, así que se trata como "inserción
                   rechazada, probablemente el código ya existe").
  5. Cada FILAS_ANTES_DE_REFRESCAR códigos guardados se recarga TODA la página
     y se vuelve a abrir la forma desde el buscador.

Diferencias de comportamiento (mismo criterio que SFABRDF):
  - Si UN código falla o es rechazado, se marca como error y la corrida
    CONTINÚA con el siguiente. Solo se detiene si la sesión expiró o si fallan
    MAX_FALLOS_SEGUIDOS códigos seguidos.
  - Un rechazo de inserción NO se reintenta (daría lo mismo): se recarga la
    forma completa y se pasa al siguiente.
  - Tras un guardado CONFIRMADO nunca se vuelve a insertar el mismo código.
  - STVBLCK no tiene cabecera/Periodo: abre directo en la grilla.

Se ejecuta desde la app (main.py) o por línea de comandos (útil para validar
en visible antes de usar la interfaz):

    python -m src.automation_stvblck bloques_stvblck.csv --visible

(requiere haber iniciado sesión antes con la app: usa la misma sesión
guardada en datos/banner_storage_state.json).
"""

import asyncio
import csv
import os
import re
import sys
import time
from datetime import datetime

from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

from .automation import (
    BANNER_URL,
    SesionExpiradaError,
    _requiere_reautenticacion,
    _pantalla_muestra_sesion_expirada,
    _encontrar_frame,
    _guardar_captura_error,
    _pagina_nueva,
    _tecleo_confiable,
)
# Scripts JS y utilidades de lectura de mensajes ya validados en SFABRDF
# (misma grilla SlickGrid y mismos avisos de Banner).
from .automation_sfabrdf import (
    _JS_FOCO,
    _JS_FILA_ACTIVA,
    _JS_TEXTO_VISIBLE,
    _JS_TEXTOS_VISIBLES,
    FRASES_GUARDADO_OK,
    _a_texto,
    _contar_avisos,
    _buscar_error,
    _fragmento,
    _normalizar,
    _pausa,
)
from .state import (
    ruta_sesion,
    carpeta_logs,
    invalidar_sesion,
    hay_sesion_guardada,
    EstadoCorrida,
)

# ------------------------------------------------------------------
# CONFIGURACIÓN
# ------------------------------------------------------------------

NOMBRE_FORMA = "STVBLCK"
ACCION = "stvblck"  # nombre de la carpeta de pendientes/procesados/fallos en datos/logs

SELECTOR_BUSQUEDA = "#search-landing"
# La forma abre directo en la grilla; sus filas son .slick-row (SlickGrid).
SELECTOR_GRILLA = ".slick-row"

# Columnas de la grilla (índice colN de aria-labelledby). A confirmar con
# DevTools en la primera corrida real; si no se pueden leer, el código detecta
# el salto de foco por el cambio de id del <input> en edición.
COL_CODIGO = 0
COL_DESCRIPCION = 1

# Largo máximo del código de bloque en Banner (STVBLCK_BLCK_CODE). Los códigos
# vistos en la forma tienen 9-10 caracteres. Si fuera distinto en tu Banner,
# cambia este valor (0 = no validar el largo).
LONGITUD_MAXIMA_CODIGO = 10

# --- Paralelismo -----------------------------------------------------------
# Con SFABRDF el paralelo con varias pestañas dio problemas de foco en ventana
# visible y sigue sin resolverse. Para STVBLCK queda DESACTIVADO hasta validarlo:
# siempre 1 pestaña. Cuando quieras probar el paralelo (en headless), pon
# PARALELO_HABILITADO = True y el engranaje de la app (1-10 pestañas) volverá
# a surtir efecto en corridas de más de UMBRAL_PARALELO códigos.
PARALELO_HABILITADO = True
UMBRAL_PARALELO = 20
NUM_PESTANAS = 5

# Intentos por código. Seguro reintentar: el código de bloque es clave única,
# así que si el primer intento sí se había guardado, el reintento sale como
# "rechazado" (duplicado) y no crea nada doble.
MAX_INTENTOS_POR_FILA = 2

# Cada cuántos códigos guardados se recarga la página completa.
FILAS_ANTES_DE_REFRESCAR = 50

# Si fallan tantos códigos SEGUIDOS (sin ninguno correcto ni rechazado en
# medio), se asume que Banner dejó de responder y se detiene la corrida.
MAX_FALLOS_SEGUIDOS = 5

# SOLO PARA PRUEBAS: antepone "[Pestaña N]" y el tiempo de cada código a los
# mensajes del panel de la app.
MOSTRAR_PESTANA_EN_RESUMEN = False

# SOLO PARA PRUEBAS: True abre el navegador VISIBLE. False = headless (sin
# ventana), que es el modo normal. Desde la línea de comandos manda --visible.
MOSTRAR_NAVEGADOR = False

# Límite de tiempo por intento de un código (red de seguridad contra cuelgues).
LIMITE_SEGUNDOS_POR_INTENTO = 90

# Qué hacer si tras F10 no aparece ningún mensaje conocido:
#  False (recomendado) -> FALLO del código (con el texto real de Banner en el motivo).
#  True                -> se asume que guardó y se sigue.
ASUMIR_OK_SI_NO_HAY_MENSAJE = False

# --- Tiempos (mismos valores seguros que SFABRDF; bajarlos de a poco) -------
TECLEO_DELAY_MS = 30          # carácter por carácter (Angular pierde letras si va muy rápido)
ESPERA_TRAS_TECLEO = 0.1
ESPERA_TRAS_F6 = 0.35
ESPERA_TRAS_F10 = 0.3
# Tiempo máximo para que Banner pase SOLO a Descripción tras escribir el código.
# Si no pasa, se manda un Tab de respaldo (queda anotado en el log).
ESPERA_SALTO = 2.5


class CodigoRechazadoError(RuntimeError):
    """Banner rechazó la inserción ("Failed to insert record"): lo más probable
    es que el código ya exista. No se reintenta."""
    tras_reintento = False


# ------------------------------------------------------------------
# LECTURA Y VALIDACIÓN DE LOS CÓDIGOS (CSV / Excel / TXT / líneas de texto)
# ------------------------------------------------------------------

_PATRON_CODIGO = re.compile(r"^[A-Z0-9_.\-]+$")

# Encabezados reconocidos en la primera celda (ya sin tildes y en minúscula).
_ENCABEZADOS = {
    "codigo", "codigo de bloque", "codigo_bloque", "codigo bloque",
    "bloque", "block", "block code", "code",
}


def _es_encabezado(celda: str) -> bool:
    return _normalizar(celda or "") in _ENCABEZADOS


def validar_codigos(lineas: list) -> tuple:
    """Normaliza (recorta, MAYÚSCULAS) y valida los códigos. Devuelve
    (codigos_ok, errores, repetidas): errores son textos 'Línea N: motivo'; los
    códigos repetidos se deduplican (uno repetido solo daría 'rechazado')."""
    ok, errores, vistos = [], [], set()
    repetidas = 0
    for n, linea in enumerate(lineas, start=1):
        codigo = (linea or "").strip().upper()
        if not codigo:
            continue
        if not _PATRON_CODIGO.match(codigo):
            errores.append(
                f"Línea {n}: «{linea.strip()}» tiene caracteres no válidos "
                "(solo letras, números, guion, guion bajo y punto; sin espacios ni comas)"
            )
            continue
        if LONGITUD_MAXIMA_CODIGO and len(codigo) > LONGITUD_MAXIMA_CODIGO:
            errores.append(
                f"Línea {n}: «{codigo}» tiene {len(codigo)} caracteres y el máximo es {LONGITUD_MAXIMA_CODIGO}"
            )
            continue
        if codigo in vistos:
            repetidas += 1
            continue
        vistos.add(codigo)
        ok.append(codigo)
    return ok, errores, repetidas


def leer_codigos_de_archivo(ruta: str) -> tuple:
    """Lee un CSV / Excel / TXT con el código de bloque en la PRIMERA columna.
    Salta la primera fila si parece encabezado. Devuelve (codigos, repetidas).
    Lanza ValueError con un mensaje claro si el archivo no tiene el formato
    esperado (por ejemplo, si se importó por error un archivo de SFABRDF con 8
    columnas)."""
    extension = os.path.splitext(ruta)[1].lower()
    filas = []

    if extension in (".xlsx", ".xls"):
        import openpyxl  # import perezoso

        libro = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
        for fila in libro.active.iter_rows(values_only=True):
            filas.append([_a_texto(c) for c in (fila or [])])
    elif extension in (".csv", ".txt"):
        with open(ruta, newline="", encoding="utf-8-sig") as f:
            muestra = f.read(4096)
            f.seek(0)
            delimitador = ";" if muestra.count(";") > muestra.count(",") else ","
            for fila in csv.reader(f, delimiter=delimitador):
                filas.append([c.strip() for c in fila])
    else:
        raise ValueError(f"Formato de archivo no soportado: {extension}")

    filas = [f for f in filas if any(c for c in f)]
    if filas and _es_encabezado(filas[0][0] if filas[0] else ""):
        filas = filas[1:]

    for n, fila in enumerate(filas, start=1):
        if sum(1 for c in fila if c) > 2:
            raise ValueError(
                f"La fila {n} tiene varias columnas: se espera UNA sola columna con el código "
                "de bloque (¿importaste por error un archivo de 'Reglas de bloque'?)."
            )

    codigos, errores, repetidas = validar_codigos([f[0] if f else "" for f in filas])
    if errores:
        raise ValueError(
            "El archivo tiene códigos no válidos. " + " | ".join(errores[:5])
            + (f" ... y {len(errores) - 5} más" if len(errores) > 5 else "")
        )
    return codigos, repetidas


# ------------------------------------------------------------------
# REGISTRO DE CÓDIGOS CON ERROR (CSV con motivo + TXT reimportable)
# ------------------------------------------------------------------

_archivo_errores = None


def _ruta_archivo_errores() -> str:
    global _archivo_errores
    if _archivo_errores is None:
        carpeta = os.path.join(carpeta_logs(), "stvblck_errores")
        os.makedirs(carpeta, exist_ok=True)
        marca = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        _archivo_errores = os.path.join(carpeta, f"codigos_con_error_{marca}.csv")
    return _archivo_errores


def ruta_txt_errores() -> str:
    """TXT de la corrida actual: un código por línea, SIN encabezado ni motivo
    (se puede importar tal cual para reintentar)."""
    return os.path.splitext(_ruta_archivo_errores())[0] + ".txt"


def hay_errores_en_corrida() -> bool:
    return _archivo_errores is not None and os.path.exists(ruta_txt_errores())


def registrar_codigo_error(codigo: str, motivo: str) -> None:
    ruta = _ruta_archivo_errores()
    es_nuevo = not os.path.exists(ruta)
    with open(ruta, "a", newline="", encoding="utf-8-sig") as f:
        escritor = csv.writer(f)
        if es_nuevo:
            escritor.writerow(["codigo_bloque", "motivo"])
        escritor.writerow([codigo, motivo])
    with open(ruta_txt_errores(), "a", encoding="utf-8") as f:
        f.write(codigo + "\n")


# ------------------------------------------------------------------
# MENSAJES DE BANNER
#
# Éxito: reutiliza FRASES_GUARDADO_OK de SFABRDF (inglés y español).
# Rechazo: "Failed to insert record" (CONFIRMADO). Las variantes en español
# son suposiciones razonables; si Banner usa otra, el error saldrá con el
# texto real en el motivo ([DIAG]) y basta agregarla aquí (van SIN tildes,
# porque se comparan contra el texto normalizado).
# ------------------------------------------------------------------

FRASES_INSERCION_RECHAZADA = [
    "failed to insert record",
    "error al insertar el registro",
    "error al insertar registro",
    "no se pudo insertar el registro",
    "no se pudo insertar registro",
    "fallo al insertar el registro",
    "fallo al insertar registro",
    "no fue posible insertar el registro",
]


def _contar_rechazos(contenido: str) -> int:
    t = _normalizar(contenido)
    return sum(t.count(f) for f in FRASES_INSERCION_RECHAZADA)


def _buscar_rechazo(contenido: str):
    """La frase de rechazo encontrada en pantalla (sin contexto: el texto
    visible junta el de toda la página y el contexto solo metería ruido)."""
    t = _normalizar(contenido)
    for frase in FRASES_INSERCION_RECHAZADA:
        if frase in t:
            return frase
    return None


def _contar_todo(contenido: str) -> tuple:
    """(n_exito, n_error, n_rechazo): avisos visibles de cada tipo."""
    n_ok, n_err = _contar_avisos(contenido)
    return n_ok, n_err, _contar_rechazos(contenido)


# ------------------------------------------------------------------
# UNA PESTAÑA DE TRABAJO
# ------------------------------------------------------------------

class VentanaSTVBLCK:
    """Una pestaña (Page) del contexto compartido, con su propio estado: el
    frame del formulario y cuántos códigos guardó (para el refresco cada 50)."""

    def __init__(self, pagina, on_log, contexto=None):
        self.pagina = pagina
        self.contexto = contexto
        self.log = on_log
        self.marco = None
        self.guardadas = 0
        self._boton_insertar_visible = True  # se pone en False si nunca aparece

    # ----------------------------------------------------- utilidades base --

    async def _tecla(self, combinacion: str) -> None:
        await self.pagina.keyboard.press(combinacion)

    async def _foco(self):
        """Estado del elemento con foco, o None si no se pudo leer (por ej.
        el frame se estaba redibujando)."""
        try:
            return await self.marco.evaluate(_JS_FOCO)
        except Exception:
            return None

    async def _texto_visible(self) -> str:
        try:
            return ((await self.marco.evaluate(_JS_TEXTO_VISIBLE)) or "").lower()
        except Exception:
            return ""

    async def _textos_visibles(self) -> list:
        try:
            return list((await self.marco.evaluate(_JS_TEXTOS_VISIBLES)) or [])
        except Exception:
            return []

    async def _leer_fila_activa(self):
        try:
            return await self.marco.evaluate(_JS_FILA_ACTIVA)
        except Exception:
            return None

    async def _asegurar_marco(self) -> None:
        """Si Banner reemplazó el iframe (el Frame quedó desprendido), se vuelve
        a ubicar buscando el frame que contiene la grilla."""
        try:
            if self.marco is not None and not self.marco.is_detached():
                return
        except Exception:
            pass
        self.marco = await _encontrar_frame(self.pagina, SELECTOR_GRILLA, timeout_ms=15000)

    async def _esperar_boton_insertar(self, timeout_ms: int = 15000) -> bool:
        """El ícono 'Insertar' de la barra de la forma sirve como señal de que
        la página respondió (no se le hace clic: se inserta con F6). Si NUNCA
        aparece en este frame, se deja de esperarlo para no perder tiempo."""
        if not self._boton_insertar_visible:
            return True
        try:
            await self.marco.wait_for_selector("i.ba-add", state="visible", timeout=timeout_ms)
            return True
        except Exception:
            self._boton_insertar_visible = False
            self.log("  (no se encontró el ícono 'Insertar' en el frame de la forma; no se volverá a esperar)")
            return False

    # ------------------------------------------------------- abrir forma --

    async def _lanzar_si_sesion_expirada(self) -> None:
        if _requiere_reautenticacion(self.pagina) or await _pantalla_muestra_sesion_expirada(self.pagina):
            raise SesionExpiradaError(
                "La sesión de Banner expiró (pantalla de error de autenticación externa). "
                "Hay que iniciar sesión de nuevo."
            )

    async def abrir_forma(self) -> None:
        """Camino completo: recarga TODA la página, busca STVBLCK y espera la
        grilla. Se usa al arrancar cada pestaña, cada FILAS_ANTES_DE_REFRESCAR
        códigos y para recuperarse tras un fallo o un rechazo."""
        p = self.pagina
        await p.goto(BANNER_URL, wait_until="domcontentloaded")

        if _requiere_reautenticacion(p):
            await self._lanzar_si_sesion_expirada()
        await p.wait_for_timeout(1500)
        await self._lanzar_si_sesion_expirada()

        try:
            await p.wait_for_selector(SELECTOR_BUSQUEDA, timeout=30000)
        except PlaywrightTimeoutError:
            await self._lanzar_si_sesion_expirada()
            raise

        await p.wait_for_timeout(400)  # margen: Angular conecta sus manejadores
        if not await _tecleo_confiable(p, SELECTOR_BUSQUEDA, NOMBRE_FORMA, self.log):
            raise RuntimeError(f'No se pudo escribir "{NOMBRE_FORMA}" en el buscador de forma confiable')
        await p.wait_for_timeout(2500)  # autocompletado

        try:
            sugerencia = p.locator(f"text={NOMBRE_FORMA}").filter(
                has_not=p.locator(SELECTOR_BUSQUEDA)
            ).first
            if await sugerencia.is_visible(timeout=1500):
                await sugerencia.click()
            else:
                await p.keyboard.press("Enter")
        except Exception:
            await p.keyboard.press("Enter")

        try:
            self.marco = await _encontrar_frame(p, SELECTOR_GRILLA, timeout_ms=40000)
        except PlaywrightTimeoutError:
            await self._lanzar_si_sesion_expirada()
            raise

        await asyncio.sleep(1.5)  # margen para que el foco quede en la primera celda
        await self._asegurar_marco()
        await self._esperar_boton_insertar()
        self.log(f"Forma {NOMBRE_FORMA} abierta.")

    # ------------------------------------------------------------- F6 --

    async def insertar_fila(self, intentos: int = 3, espera_por_intento: float = 3.0) -> None:
        """F6 y espera condicional a que el foco quede en un <input> VACÍO de la
        columna Código. Un <input> con valor significa que seguimos sobre una
        fila existente (F6 aún no hizo efecto): en ese caso NO se escribe nada
        (se pisaría el código de una fila real) y se reintenta F6."""
        for intento in range(1, intentos + 1):
            await self._esperar_boton_insertar()
            await self._tecla("F6")
            await _pausa(ESPERA_TRAS_F6)

            fin = time.monotonic() + espera_por_intento
            while time.monotonic() < fin:
                foco = await self._foco()
                if (
                    foco and foco["tag"] == "input"
                    and foco["col"] in (COL_CODIGO, None)
                    and (foco.get("value") or "") == ""
                ):
                    return
                await asyncio.sleep(0.05)

            foco = await self._foco()
            self.log(
                f"  reintento F6 ({intento}/{intentos}): columna={foco['col'] if foco else None} "
                f"valor='{foco.get('value') if foco else None}' (esperaba un input vacío en la columna Código)"
            )
        raise RuntimeError("no se pudo confirmar que la fila se insertó tras varios intentos de F6")

    # ------------------------------------------------- escribir la fila --

    @staticmethod
    def _salto_a_descripcion(foco, id_antes: str) -> bool:
        """True si el foco ya está en Descripción. Si la columna no se puede
        leer, se considera que saltó cuando el <input> con foco es OTRO (cambió
        el id dinámico de SlickGrid)."""
        if not foco or foco["tag"] != "input":
            return False
        if foco["col"] is not None:
            return foco["col"] == COL_DESCRIPCION
        return bool(foco.get("id")) and foco["id"] != id_antes

    async def _escribir_codigo_con_salto(self, codigo: str) -> bool:
        """Escribe el código en la celda activa. Banner mueve SOLO el foco a
        Descripción, por eso NO se reintenta el tecleo (un reintento escribiría
        en Descripción). Si Banner no salta solo dentro de ESPERA_SALTO, se manda
        un único Tab de respaldo y se anota en el log."""
        foco0 = await self._foco()
        id_antes = (foco0 or {}).get("id", "")
        try:
            await self.pagina.keyboard.press("Control+a")
            await self.pagina.keyboard.press("Delete")
            await asyncio.sleep(0.05)
            await self.pagina.keyboard.type(codigo, delay=TECLEO_DELAY_MS)
        except Exception as err:
            self.log(f"  ADVERTENCIA: falló el tecleo del código ({type(err).__name__})")
            return False
        await _pausa(ESPERA_TRAS_TECLEO)

        salto = False
        fin = time.monotonic() + ESPERA_SALTO
        while time.monotonic() < fin:
            if self._salto_a_descripcion(await self._foco(), id_antes):
                salto = True
                break
            await asyncio.sleep(0.05)

        if not salto:
            self.log("  (Banner no pasó solo a Descripción; se envía Tab de respaldo)")
            await self._tecla("Tab")
            await asyncio.sleep(0.4)
            if not self._salto_a_descripcion(await self._foco(), id_antes):
                self.log(f"  ADVERTENCIA: el foco no llegó a Descripción. Foco actual: {await self._foco()}")
                return False

        # Verificación best-effort de lo que quedó en la celda del código.
        celdas = await self._leer_fila_activa()
        if isinstance(celdas, dict):
            actual = celdas.get(str(COL_CODIGO))
            if actual not in (None, "__EDIT__") and actual.strip().upper() != codigo.upper():
                self.log(f"  ADVERTENCIA: el código quedó como '{actual}' en vez de '{codigo}'")
                return False
        return True

    async def _escribir_en_activo(self, valor: str, intentos: int = 3) -> bool:
        """Escribe sobre el <input> con foco y verifica el valor leído."""
        valor = str(valor)
        for intento in range(1, intentos + 1):
            try:
                await self.pagina.keyboard.press("Control+a")
                await self.pagina.keyboard.press("Delete")
                await asyncio.sleep(0.05)
                await self.pagina.keyboard.type(valor, delay=TECLEO_DELAY_MS)
                await asyncio.sleep(ESPERA_TRAS_TECLEO)
                foco = await self._foco()
                actual = foco["value"] if foco else None
            except Exception as err:
                self.log(f"  reintento tecleo activo ({intento}/{intentos}): el campo se redibujó ({type(err).__name__})")
                await asyncio.sleep(0.2)
                continue
            if actual == valor:
                return True
            self.log(f"  reintento tecleo activo ({intento}/{intentos}): esperado='{valor}' obtenido='{actual}'")
        return False

    async def llenar_fila(self, codigo: str) -> bool:
        """Código (Banner salta solo a Descripción) -> Descripción (= mismo valor)."""
        if not await self._escribir_codigo_con_salto(codigo):
            return False
        foco = await self._foco()
        if not foco or foco["tag"] != "input":
            self.log(f"  ADVERTENCIA: no hay un <input> en foco para escribir la Descripción. Foco: {foco}")
            return False
        if not await self._escribir_en_activo(codigo):
            self.log("  ADVERTENCIA: no se pudo confirmar la Descripción")
            return False
        return True

    # --------------------------------------------------------------- F10 --

    async def _leer_confirmacion_guardado(self, base=(0, 0, 0), timeout: float = 6.0, textos_antes=None):
        """(estado, detalle): 'ok' | 'rechazado' | 'error' | 'desconocido'.
        `base` = avisos que YA había en pantalla antes de F10: solo cuenta como
        resultado de ESTE guardado un aviso adicional a esos. Si el resultado es
        'desconocido', `detalle` trae TODO el texto nuevo que apareció en
        pantalla mientras se esperaba (el aviso de Banner dura pocos segundos:
        leerlo recién al final ya no lo encuentra)."""
        base_ok, base_err, base_rech = base
        textos_antes = textos_antes or set()
        vistos_nuevos = []
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            contenido = await self._texto_visible()
            n_ok, n_err, n_rech = _contar_todo(contenido)
            for t in await self._textos_visibles():
                if t not in textos_antes and t not in vistos_nuevos:
                    vistos_nuevos.append(t)

            if n_rech > base_rech:
                detalle = _buscar_rechazo(contenido)
                if detalle:
                    return "rechazado", detalle

            if n_ok > base_ok:
                for frase in FRASES_GUARDADO_OK:
                    pos = contenido.find(frase)
                    if pos >= 0:
                        return "ok", _fragmento(contenido, pos, pos + len(frase))

            if n_err > base_err:
                err = _buscar_error(contenido)
                if err:
                    return "error", err

            await asyncio.sleep(0.15)
        return "desconocido", " | ".join(vistos_nuevos)[:400]

    async def _esperar_sin_aviso(self, timeout: float = 4.0) -> bool:
        """Espera a que no quede ningún aviso (éxito/error/rechazo) en pantalla,
        para que la línea base sea limpia: si un aviso viejo desaparece justo
        cuando aparece el nuevo, un conteo igual ocultaría el resultado."""
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            if _contar_todo(await self._texto_visible()) == (0, 0, 0):
                return True
            await asyncio.sleep(0.1)
        return False

    async def guardar(self) -> None:
        if not await self._esperar_sin_aviso(timeout=4.0):
            self.log("  (hay un aviso viejo todavía visible antes de F10; se usa como línea base)")
        base = _contar_todo(await self._texto_visible())
        textos_antes = set(await self._textos_visibles())

        await self._tecla("F10")
        await _pausa(ESPERA_TRAS_F10)

        resultado, detalle = await self._leer_confirmacion_guardado(base=base, textos_antes=textos_antes)
        if resultado == "rechazado":
            raise CodigoRechazadoError(
                f"inserción rechazada por Banner («{detalle}»): lo más probable es que el código ya exista"
            )
        if resultado == "error":
            raise RuntimeError(f"Banner mostró un mensaje de error tras F10: «{detalle}»")
        if resultado == "desconocido":
            if ASUMIR_OK_SI_NO_HAY_MENSAJE:
                self.log("  (no se detectó mensaje de guardado conocido - se asume OK, verificar manualmente si hay dudas)")
            else:
                visto = detalle or "(no apareció ningún texto nuevo en pantalla)"
                self.log(f"  [DIAG] texto nuevo en pantalla tras F10: {visto}")
                raise RuntimeError(
                    "no se confirmó el guardado: ningún mensaje de éxito conocido tras F10. "
                    f"Banner mostró: «{visto}». "
                    "Si es un éxito con otra redacción, agrégala a FRASES_GUARDADO_OK."
                )
        # A PARTIR DE AQUÍ EL CÓDIGO YA ESTÁ GUARDADO: no se hace nada que pueda
        # lanzar excepción (si la lanzara, la escalera de reintentos volvería a
        # insertarlo y Banner respondería "rechazado").

    # ------------------------------------------------- un código completo --

    async def _intentar_procesar(self, codigo: str) -> None:
        await self._asegurar_marco()
        await self.insertar_fila()
        if not await self.llenar_fila(codigo):
            # NO se guarda una fila a medias: se aborta y se recarga la forma.
            raise RuntimeError("fila incompleta: no se pudieron llenar Código y Descripción")
        await self.guardar()

    async def procesar_con_reintentos(self, codigo: str):
        """Devuelve (estado, error): 'ok' | 'rechazado' | 'sesion_expirada' |
        'fallo'. Escalera: intento -> falla -> recargar forma completa ->
        reintento -> falla -> se rinde (y recarga para dejar limpia la pestaña)."""
        ultimo_error = None
        for intento in range(MAX_INTENTOS_POR_FILA):
            try:
                await asyncio.wait_for(
                    self._intentar_procesar(codigo), timeout=LIMITE_SEGUNDOS_POR_INTENTO
                )
                return "ok", None

            except CodigoRechazadoError as err:
                err.tras_reintento = intento > 0
                self.log(
                    f"  RECHAZADO (bloque={codigo}): {err}"
                    + (" [tras un reintento: probablemente el código YA se había guardado en el intento anterior]"
                       if err.tras_reintento else "")
                )
                ruta = await _guardar_captura_error(self.pagina, f"stvblck_rechazado_{codigo}")
                if ruta:
                    self.log(f"  (captura: {ruta})")
                self.log("  Recargando la página completa para continuar con el siguiente código...")
                try:
                    await self.abrir_forma()
                except SesionExpiradaError as e2:
                    return "sesion_expirada", e2
                except Exception as e2:
                    try:
                        if _requiere_reautenticacion(self.pagina) or await _pantalla_muestra_sesion_expirada(self.pagina):
                            return "sesion_expirada", SesionExpiradaError(str(e2))
                    except Exception:
                        pass
                    self.log(f"  ADVERTENCIA: falló la recarga tras el rechazo: {e2}")
                return "rechazado", err

            except asyncio.TimeoutError:
                ultimo_error = RuntimeError(
                    f"se agotó el límite de {LIMITE_SEGUNDOS_POR_INTENTO}s para este intento (posible cuelgue)"
                )
                self.log(f"  intento {intento + 1}/{MAX_INTENTOS_POR_FILA} falló: {ultimo_error}")

            except Exception as err:
                ultimo_error = err
                try:
                    if (
                        isinstance(err, SesionExpiradaError)
                        or _requiere_reautenticacion(self.pagina)
                        or await _pantalla_muestra_sesion_expirada(self.pagina)
                    ):
                        return "sesion_expirada", SesionExpiradaError(str(err))
                except Exception:
                    pass
                ruta = await _guardar_captura_error(self.pagina, f"stvblck_{codigo}")
                self.log(
                    f"  intento {intento + 1}/{MAX_INTENTOS_POR_FILA} falló: {err}"
                    + (f" (captura: {ruta})" if ruta else "")
                )

            # Recuperación: recargar la forma COMPLETA (también tras el último
            # intento, para que el siguiente código empiece sobre pantalla limpia).
            ultimo_intento = intento == MAX_INTENTOS_POR_FILA - 1
            if ultimo_intento:
                self.log("  Se agotaron los intentos de este código; recargando la página para continuar con el siguiente...")
            try:
                await asyncio.wait_for(self.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
            except SesionExpiradaError as e2:
                return "sesion_expirada", e2
            except Exception as e2:
                if not isinstance(e2, asyncio.TimeoutError):
                    try:
                        if _requiere_reautenticacion(self.pagina) or await _pantalla_muestra_sesion_expirada(self.pagina):
                            return "sesion_expirada", SesionExpiradaError(str(e2))
                    except Exception:
                        pass
                if not ultimo_intento:
                    ultimo_error = e2
                else:
                    self.log(f"  ADVERTENCIA: falló la recarga tras agotar los intentos: {e2}")
                await self._reabrir_pagina_si_hace_falta()

        return "fallo", ultimo_error

    async def reabrir_pagina(self) -> None:
        """Cierra esta pestaña y abre una nueva (misma sesión de login)."""
        try:
            await asyncio.wait_for(self.pagina.close(), timeout=10)
        except Exception:
            pass
        if self.contexto is None:
            raise RuntimeError("no hay contexto para reabrir la pestaña")
        self.pagina = await asyncio.wait_for(_pagina_nueva(self.contexto), timeout=15)
        self.marco = None

    async def _reabrir_pagina_si_hace_falta(self) -> None:
        try:
            if not self.pagina.is_closed():
                return
        except Exception:
            pass
        if self.contexto is None:
            return
        try:
            self.pagina = await _pagina_nueva(self.contexto)
            self.marco = None
        except Exception as err:
            self.log(f"  (no se pudo reabrir la pestaña: {err})")


# ------------------------------------------------------------------
# TRABAJADOR (una pestaña) Y LOOP PRINCIPAL
# ------------------------------------------------------------------

async def _trabajador_stvblck(
    indice: int,
    contexto,
    cola: "asyncio.Queue[str]",
    estado_corrida,
    control,
    evento_detener: asyncio.Event,
    estado_compartido: dict,
    on_log,
    on_progreso,
    on_resumen=None,
):
    """Procesa códigos de la cola compartida uno a uno, en su propia pestaña
    (mismo contexto = misma sesión de login), hasta que la cola se vacía, se
    cancela la corrida o se activa evento_detener."""
    resumen = on_resumen if on_resumen is not None else on_log
    etiqueta = f"[Pestaña {indice + 1}]"

    def log(mensaje: str):
        on_log(f"{etiqueta} {mensaje}")

    def r(mensaje: str, segundos: float = None):
        if MOSTRAR_PESTANA_EN_RESUMEN:
            extra = f" ({segundos:.1f} s)" if segundos is not None else ""
            resumen(f"{etiqueta} {mensaje}{extra}")
        else:
            resumen(mensaje)

    def progreso(clave: str):
        on_progreso(clave, len(estado_corrida.procesados), len(estado_corrida.pendientes), len(estado_corrida.fallos))

    log("Pestaña iniciada.")
    pagina = await _pagina_nueva(contexto)
    ventana = VentanaSTVBLCK(pagina, log, contexto=contexto)

    async def _pestana_se_rinde(sesion_muerta: bool) -> None:
        """Esta pestaña no puede trabajar. Si quedan otras vivas, solo esta se
        retira; solo si es la ÚLTIMA viva se detiene todo (y solo entonces se
        invalida la sesión, y únicamente si ninguna falló por otra causa)."""
        if not sesion_muerta:
            estado_compartido["fallo_no_sesion"] = True
        if estado_compartido["tabs_vivas"] > 1:
            log("Esta pestaña no pudo trabajar; se retira. Las demás pestañas continúan.")
            return
        if sesion_muerta and not estado_compartido["fallo_no_sesion"]:
            invalidar_sesion()
            resumen("Error - sesión de Banner expirada, corrida detenida")
        else:
            resumen(f"Error - no se pudo abrir {NOMBRE_FORMA}, corrida detenida")
        evento_detener.set()

    try:
        # Entrada inicial: intento -> intento (tras pausa) -> intento sobre una
        # pestaña NUEVA (mismo patrón que SSASECT / SFABRDF).
        listo = False
        ultimo_error = None
        t_inicio = time.monotonic()
        for intento in range(3):
            try:
                if intento == 2:
                    log("Reabriendo la pestaña para un último intento...")
                    await ventana.reabrir_pagina()
                await asyncio.wait_for(ventana.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
                listo = True
                break
            except Exception as err:
                ultimo_error = err
                if isinstance(err, SesionExpiradaError):
                    log(f"Pantalla de sesión/autenticación al abrir {NOMBRE_FORMA} (intento {intento + 1}/3): {err}")
                else:
                    log(f"No se pudo abrir {NOMBRE_FORMA} (intento {intento + 1}/3): {err}")
                await asyncio.sleep(2 + indice)
        if listo:
            r(f"Pestaña lista ({NOMBRE_FORMA} abierto)", time.monotonic() - t_inicio)
        else:
            try:
                sesion_muerta = (
                    isinstance(ultimo_error, SesionExpiradaError)
                    or _requiere_reautenticacion(ventana.pagina)
                    or await _pantalla_muestra_sesion_expirada(ventana.pagina)
                )
            except Exception:
                sesion_muerta = isinstance(ultimo_error, SesionExpiradaError)
            await _pestana_se_rinde(sesion_muerta)
            return

        while not evento_detener.is_set() and not control.cancelado:
            while control.pausado and not control.cancelado and not evento_detener.is_set():
                await asyncio.sleep(0.3)
            if control.cancelado or evento_detener.is_set():
                break

            try:
                codigo = cola.get_nowait()
            except asyncio.QueueEmpty:
                log("Sin más códigos en la cola - esta pestaña terminó su parte.")
                break

            log(f"--- Procesando código de bloque {codigo} ---")
            t0 = time.monotonic()
            estado, error = await ventana.procesar_con_reintentos(codigo)
            duracion = time.monotonic() - t0

            if estado == "ok":
                estado_compartido["fallos_seguidos"] = 0
                ventana.guardadas += 1
                estado_corrida.marcar_exito(codigo)
                log(f"Bloque {codigo}: OK ({duracion:.1f} s)")
                r(f"Bloque {codigo}: Procesado", duracion)
                progreso(codigo)
                if ventana.guardadas % FILAS_ANTES_DE_REFRESCAR == 0:
                    log(f"--- Recargando la página tras {FILAS_ANTES_DE_REFRESCAR} códigos guardados ---")
                    try:
                        await asyncio.wait_for(ventana.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
                    except SesionExpiradaError as err:
                        # No se pierde nada: el siguiente código lo detectará y
                        # seguirá la escalera normal de recuperación de sesión.
                        log(f"  ADVERTENCIA: sesión/autenticación al recargar: {err}")
                    except Exception as err:
                        log(f"  ADVERTENCIA: falló la recarga de la página: {err}")

            elif estado == "rechazado":
                # Un rechazo es un resultado normal de Banner, no una falla del
                # sistema: no cuenta para el corte por fallos seguidos.
                estado_compartido["fallos_seguidos"] = 0
                if getattr(error, "tras_reintento", False):
                    motivo = "inserción rechazada tras reintento (probablemente YA se guardó en el intento anterior)"
                else:
                    motivo = "inserción rechazada por Banner (Failed to insert record): probable duplicado, el código ya existe"
                registrar_codigo_error(codigo, motivo)
                estado_corrida.marcar_fallo(codigo, motivo)
                log(f"Bloque {codigo}: marcado como ERROR ({motivo}).")
                r(f"Bloque {codigo}: Error - {motivo}", duracion)
                progreso(codigo)

            elif estado == "sesion_expirada":
                # Puede ser un hipo pasajero del SSO en ESTA pestaña. Antes de
                # concluir que la sesión murió: el código vuelve a la cola (no
                # se marca como fallo) y la pestaña intenta recuperarse.
                veces = estado_compartido["reintentos_sesion"].get(codigo, 0) + 1
                estado_compartido["reintentos_sesion"][codigo] = veces
                if veces > 2:
                    motivo = f"sesión/autenticación falló repetidamente al procesar este código: {error}"
                    registrar_codigo_error(codigo, motivo)
                    estado_corrida.marcar_fallo(codigo, motivo)
                    log(f"*** Bloque {codigo} FALLÓ: {motivo} ***")
                    r(f"Bloque {codigo}: Error - {motivo}", duracion)
                    progreso(codigo)
                else:
                    cola.put_nowait(codigo)
                log("Pantalla de sesión/autenticación detectada; se intenta recuperar esta pestaña...")
                recuperada = False
                for intento_rec in range(2):
                    try:
                        await ventana.reabrir_pagina()
                        await asyncio.wait_for(ventana.abrir_forma(), timeout=LIMITE_SEGUNDOS_POR_INTENTO)
                        recuperada = True
                        break
                    except Exception as err:
                        log(f"  recuperación {intento_rec + 1}/2 falló: {err}")
                        await asyncio.sleep(2 + indice)
                if recuperada:
                    log("Pestaña recuperada; se continúa.")
                    continue
                # Los códigos sin procesar siguen PENDIENTES (no se marcan como fallo).
                await _pestana_se_rinde(True)
                break

            else:  # "fallo"
                estado_compartido["fallos_seguidos"] += 1
                motivo = f"fallo tras {MAX_INTENTOS_POR_FILA} intentos: {error}"
                registrar_codigo_error(codigo, motivo)
                estado_corrida.marcar_fallo(codigo, motivo)
                log(f"*** Bloque {codigo} FALLÓ: {motivo} - revisar manualmente en Banner. ***")
                r(f"Bloque {codigo}: Error - {error}", duracion)
                progreso(codigo)
                if estado_compartido["fallos_seguidos"] >= MAX_FALLOS_SEGUIDOS:
                    log(
                        f"Fallaron {MAX_FALLOS_SEGUIDOS} códigos seguidos: Banner parece no estar "
                        "respondiendo. Deteniendo toda la corrida."
                    )
                    evento_detener.set()
    finally:
        estado_compartido["tabs_vivas"] -= 1
        try:
            await ventana.pagina.close()
        except Exception:
            pass


async def ejecutar_lote_stvblck(
    lineas: list,
    estado_corrida,
    control,
    on_log,
    on_progreso,
    num_pestanas: int = NUM_PESTANAS,
    on_resumen=None,
    headless: bool = None,
) -> None:
    """Procesa los códigos de bloque (una línea = un código) sobre una cola
    compartida. `headless=False` abre una ventana visible (para depurar); si no
    se indica, depende de MOSTRAR_NAVEGADOR. Misma firma que
    ejecutar_lote_sfabrdf, salvo que STVBLCK no lleva periodo."""
    if headless is None:
        headless = not MOSTRAR_NAVEGADOR
    global _archivo_errores
    _archivo_errores = None  # un CSV de errores NUEVO por cada corrida
    resumen = on_resumen if on_resumen is not None else on_log
    ruta = ruta_sesion()
    resumen("Inicializando...")

    if PARALELO_HABILITADO:
        n_pestanas = max(1, num_pestanas) if len(lineas) > UMBRAL_PARALELO else 1
    else:
        n_pestanas = 1
        if num_pestanas > 1 and len(lineas) > UMBRAL_PARALELO:
            on_log("STVBLCK: el paralelo aún no está validado para esta forma; se usa 1 pestaña.")
    if n_pestanas > 1:
        on_log(f"{len(lineas)} códigos: se procesan en paralelo con {n_pestanas} pestañas.")

    cola: "asyncio.Queue[str]" = asyncio.Queue()
    for linea in lineas:
        cola.put_nowait(linea)

    evento_detener = asyncio.Event()
    estado_compartido = {
        "fallos_seguidos": 0,
        "tabs_vivas": n_pestanas,
        "fallo_no_sesion": False,
        "reintentos_sesion": {},
    }

    async with async_playwright() as p:
        navegador = await p.chromium.launch(headless=headless)
        contexto = await navegador.new_context(
            storage_state=ruta, locale="es-PE", viewport={"width": 1600, "height": 900}
        )
        tareas = []
        for i in range(n_pestanas):
            tareas.append(asyncio.create_task(_trabajador_stvblck(
                i, contexto, cola, estado_corrida, control, evento_detener,
                estado_compartido, on_log, on_progreso, on_resumen=resumen,
            )))
            if i < n_pestanas - 1:
                await asyncio.sleep(1.5)  # no saturar el arranque de golpe
        await asyncio.gather(*tareas)
        await navegador.close()

    if evento_detener.is_set() and not control.cancelado:
        if not hay_sesion_guardada():
            resumen("Corrida detenida por sesión expirada. Vuelve a abrir la app e inicia sesión con Google antes de reintentar.")
        else:
            resumen("La corrida se detuvo antes de terminar todos los códigos: Banner dejó de responder. Revisa el sistema e intenta de nuevo más tarde.")
    resumen(
        f"Resumen: {len(estado_corrida.procesados)} procesados, "
        f"{len(estado_corrida.fallos)} fallidos, {len(estado_corrida.pendientes)} pendientes."
    )
    if estado_corrida.fallos and _archivo_errores and os.path.exists(_archivo_errores):
        resumen(f"Códigos con error (TXT para reimportar): {ruta_txt_errores()}")
        resumen(f"Códigos con error con motivo (CSV): {_archivo_errores}")


# ------------------------------------------------------------------
# EJECUCIÓN POR LÍNEA DE COMANDOS (validar en visible antes de usar la app)
# ------------------------------------------------------------------

def _cli() -> None:
    import argparse

    ap = argparse.ArgumentParser(description="Procesa un CSV/Excel/TXT de códigos de bloque STVBLCK sin la interfaz.")
    ap.add_argument("archivo", help="CSV, Excel o TXT con el código de bloque en la primera columna")
    ap.add_argument("--visible", action="store_true", help="abre una ventana de Chrome visible")
    ap.add_argument("--pestanas", type=int, default=1, help="pestañas en paralelo (solo si PARALELO_HABILITADO = True)")
    args = ap.parse_args()

    if not hay_sesion_guardada():
        sys.exit("No hay sesión guardada: abre la app (python main.py) e inicia sesión con Google primero.")

    codigos, repetidas = leer_codigos_de_archivo(args.archivo)
    if repetidas:
        print(f"(se descartaron {repetidas} códigos repetidos del archivo)")
    print(f"{len(codigos)} códigos a procesar.")

    class _Control:
        pausado = False
        cancelado = False

    estado = EstadoCorrida(ACCION, codigos)
    asyncio.run(ejecutar_lote_stvblck(
        lineas=codigos,
        estado_corrida=estado,
        control=_Control(),
        on_log=lambda m: print(f"[{datetime.now():%H:%M:%S}] {m}", flush=True),
        on_progreso=lambda *a: None,
        num_pestanas=args.pestanas,
        headless=not args.visible,
    ))


if __name__ == "__main__":
    _cli()
