# main.py
"""
Automatizador Banner - Interfaz de escritorio (customtkinter)

Flujo de dos pantallas:
  1) Pantalla de login: lo unico visible al abrir la app si no hay sesion
     guardada. Un solo boton "Iniciar sesion", que abre una ventana real
     de navegador (Playwright) para completar el SSO - Google bloquea el
     login OAuth dentro de webviews embebidos, asi que esa ventana
     separada es un requisito, no un detalle de implementacion.
  2) Pantalla principal: aparece automaticamente al completar el login (o
     de entrada, si ya habia una sesion guardada de una corrida anterior).
     Implementa el diseño aprobado en la sección 9 del contexto del
     proyecto: panel lateral de automatizaciones, chips de estado en vivo,
     selector de estatus descriptivo, importar desde Excel, cronómetro,
     log con color por tipo de evento.

Mismo patron ya usado en el proyecto: GUI + hilo de trabajo aparte +
queue.Queue para logs (nunca se tocan widgets desde el hilo de trabajo).
"""

import os
import re
import sys
import webbrowser
import csv
import textwrap
import time
import asyncio
import threading
import queue
from tkinter import filedialog, messagebox
import customtkinter as ctk
from PIL import Image

from src.state import (
    hay_sesion_guardada,
    EstadoCorrida,
    leer_pendientes_guardados,
    listar_fallos,
    agregar_log_texto,
    invalidar_sesion,
    borrar_datos_sesion,
)
from src.automation import iniciar_login_interactivo, ejecutar_lote
from src.formato_fallos import (
    formatear_fallos_sfabrdf,
    formatear_fallos_stvblck,
    formatear_fallos_ssarres,
    formatear_fallos_ssarres_atributo,
    formatear_fallos_ssarres_conservar,
    formatear_fallos_ssarres_agregar,
    parsear_linea_fallo,
)
from src.automation_sfabrdf import (
    ejecutar_lote_sfabrdf,
    leer_reglas_de_archivo,
    validar_lineas,
    ENCABEZADO_LEGIBLE as ENCABEZADO_SFABRDF,
    UMBRAL_PARALELO as UMBRAL_PARALELO_SFABRDF,
)
from src.automation_stvblck import (
    ejecutar_lote_stvblck,
    leer_codigos_de_archivo,
    validar_codigos,
)
from src.automation_ssarres import (
    ejecutar_lote_ssarres,
    leer_nrcs_de_archivo as leer_nrcs_ssarres,
    validar_nrcs,
    MODO_QUITAR as SSARRES_QUITAR,
    PROGRAMA_OBJETIVO as SSARRES_PROGRAMA,
)
from src.automation_ssarres_conservar import (
    ejecutar_lote_ssarres_conservar,
    leer_pares_de_archivo as leer_pares_ssarres_conservar,
    validar_lineas as validar_lineas_conservar,
    ACCION as ACCION_SSARRES_CONSERVAR,
)
from src.automation_ssarres_atributo import (
    ejecutar_lote_ssarres_atributo,
    leer_nrcs_de_archivo as leer_nrcs_ssarres_atributo,
    validar_nrcs as validar_nrcs_atributo,
    ATRIBUTO_OBJETIVO as SSARRES_ATRIBUTO,
    ATRIBUTOS_SUGERIDOS as SSARRES_ATRIBUTOS_SUGERIDOS,
    validar_atributo as validar_atributo_ssarres,
    ACCION as ACCION_SSARRES_ATRIBUTO,
)
from src.automation_ssarres_agregar import (
    ejecutar_lote_ssarres_agregar,
    leer_nrcs_de_archivo as leer_nrcs_ssarres_agregar,
    validar_nrcs as validar_nrcs_agregar,
    PROGRAMA_OBJETIVO as SSARRES_AGREGAR_PROGRAMA,
    ACCION as ACCION_SSARRES_AGREGAR,
)

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# Tipografías: en Windows existen Segoe UI y Cascadia Mono; si faltan, Tk cae
# a la fuente por defecto del sistema sin romper el diseño.
FAMILIA_UI = "Segoe UI"
FAMILIA_MONO = "Cascadia Mono"


ANCHO_LATERAL = 264
ANCHO_COLUMNA_DERECHA = 290
ALTO_MINIMO_LATERAL_COMPLETO = 640  # por debajo se oculta la descripción de cada acción
LIMITE_LINEAS_MARCADAS = 500      # líneas con error que se resaltan como máximo
LIMITE_PROBLEMAS_MOSTRADOS = 60   # textos de problema que se listan como máximo


def fuente(tam, peso="normal"):
    return (FAMILIA_UI, tam, peso)


def fuente_mono(tam, peso="normal"):
    return (FAMILIA_MONO, tam, peso)


FUENTE_TITULO = fuente(24, "bold")
FUENTE_SUBTITULO = fuente(15, "bold")
FUENTE_TEXTO = fuente(13)
FUENTE_MONO = fuente_mono(13)

# Paleta «tinta»: claro, casi monocromo, con el negro como único acento.
# Las capas se separan por tono (sin bordes ni sombras, que customtkinter
# no soporta bien) y los colores de estado solo aparecen cuando significan algo.
COLOR_ACENTO = "#111113"
COLOR_ACENTO_HOVER = "#33333a"
COLOR_ACENTO_TEXTO = "#ffffff"
COLOR_ACENTO_TINTE = "#ececf0"    # barras de ayuda, botones tonales
COLOR_EXITO = "#166a4a"
COLOR_EXITO_TINTE = "#dff3e8"
COLOR_PELIGRO = "#a02a34"
COLOR_PELIGRO_TINTE = "#fbe6e8"
COLOR_AVISO = "#8a5a00"
COLOR_AVISO_TINTE = "#fff1cf"
COLOR_MUTED = "#686870"           # texto secundario

COLOR_FONDO = "#f3f3f5"           # fondo de la ventana
COLOR_SIDEBAR = "#ffffff"         # panel lateral
COLOR_SUPERFICIE = "#ffffff"      # tarjetas
COLOR_SUPERFICIE_2 = "#f3f3f5"    # campos, filas y tarjetas internas
COLOR_BORDE = "#e4e4e8"
COLOR_LOG_BG = "#f3f3f5"          # consola de log
COLOR_TEXTO = "#111113"
COLOR_INACTIVO = "#e8e8ec"        # fondo de un botón principal deshabilitado
COLOR_INACTIVO_TEXTO = "#8d8d96"

ESTILO_BOTON_PRINCIPAL = dict(
    corner_radius=10, fg_color=COLOR_ACENTO, hover_color=COLOR_ACENTO_HOVER,
    text_color=COLOR_ACENTO_TEXTO, text_color_disabled=COLOR_INACTIVO_TEXTO,
)
ESTILO_BOTON_TONAL = dict(
    corner_radius=10, fg_color=COLOR_ACENTO_TINTE, hover_color=COLOR_BORDE,
    text_color=COLOR_TEXTO, text_color_disabled=COLOR_INACTIVO_TEXTO,
)

APP_NOMBRE = "Automatizador Banner"


def _leer_version():
    """Versión del paquete: archivo VERSION junto a main.py (lo escribe/lee publicar.py)."""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "VERSION"), encoding="utf-8") as f:
            return f.read().strip() or "dev"
    except OSError:
        return "dev"


APP_VERSION = _leer_version()      # se cambia en el archivo VERSION, no aquí
CORREO_CONSULTAS = "aherrerac@continental.edu.pe"
# Identificador propio para Windows: sin él, la barra de tareas agrupa la ventana
# bajo «Python» (y le pone su ícono) al ejecutar con `python main.py`.
APP_ID_WINDOWS = "UContinental.AutomatizadorBanner"


def ruta_recurso(*partes):
    """Ruta de un archivo incluido con la app: siempre junto a main.py, es decir,
    en la carpeta del paquete (la descargada por el lanzador, o el proyecto en
    desarrollo). Ya no depende de la carpeta temporal del .exe."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), *partes)


def poner_icono(ventana):
    """Ícono de la app en una ventana (y por tanto en la barra de tareas). Se reaplica
    a los 250 ms porque customtkinter pone su ícono por defecto a los 200 ms."""
    def aplicar():
        try:
            if sys.platform.startswith("win"):
                ventana.iconbitmap(RUTA_ICONO_ICO)
            else:
                import tkinter
                ventana._icono_ref = tkinter.PhotoImage(file=RUTA_ICONO_PNG)
                ventana.iconphoto(True, ventana._icono_ref)
        except Exception:
            pass  # sin ícono la app funciona igual
    aplicar()
    try:
        ventana.after(250, aplicar)
    except Exception:
        pass


# Ruta del logo institucional. Si el archivo no existe (todavía no lo
# pusiste ahí), la pantalla de login cae a un placeholder "UC" con el
# mismo tamaño y color de acento, sin romper el layout.
RUTA_LOGO = ruta_recurso("assets", "logo_uc.png")

# Ícono oficial de "Sign in with Google" (el usuario lo descarga de la
# página de branding de Google y lo coloca en assets/). Si no existe, el
# botón se muestra solo con texto, sin romper el layout.
RUTA_GOOGLE_ICON = ruta_recurso("assets", "google_icon.png")
RUTA_ICONO_ICO = ruta_recurso("assets", "icono_app.ico")   # barra de tareas y ventanas (Windows)
RUTA_ICONO_PNG = ruta_recurso("assets", "icono_app.png")   # otros sistemas

def cargar_logo(tamano=64):
    """Devuelve un CTkImage del logo institucional si el archivo existe, o None."""
    if not os.path.exists(RUTA_LOGO):
        return None
    try:
        img = Image.open(RUTA_LOGO)
        return ctk.CTkImage(light_image=img, dark_image=img, size=(tamano, tamano))
    except Exception:
        return None


def cargar_google_icon(tamano=18):
    """Devuelve un CTkImage del ícono de Google si el archivo existe, o None."""
    if not os.path.exists(RUTA_GOOGLE_ICON):
        return None
    try:
        img = Image.open(RUTA_GOOGLE_ICON)
        return ctk.CTkImage(light_image=img, dark_image=img, size=(tamano, tamano))
    except Exception:
        return None


def leer_nrcs_de_archivo(ruta: str) -> list[str]:
    """
    Lee NRCs desde un archivo Excel (.xlsx/.xls) o CSV, tomando la primera
    columna. Salta la primera fila si no parece un NRC numérico (se asume
    encabezado tipo "NRC").
    """
    extension = os.path.splitext(ruta)[1].lower()
    valores: list[str] = []

    if extension in (".xlsx", ".xls"):
        import openpyxl  # import perezoso: solo se necesita si se usa esta función

        libro = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
        hoja = libro.active
        for fila in hoja.iter_rows(values_only=True):
            if not fila:
                continue
            valor = fila[0]
            if valor is None:
                continue
            valores.append(str(valor).strip())
    elif extension == ".csv":
        with open(ruta, "r", encoding="utf-8-sig", newline="") as f:
            for fila in csv.reader(f):
                if fila and fila[0].strip():
                    valores.append(fila[0].strip())
    else:
        raise ValueError(f"Formato de archivo no soportado: {extension}")

    # Descartar encabezado si la primera fila no es numérica (ej. "NRC")
    if valores and not valores[0].isdigit():
        valores = valores[1:]

    # Quitar vacíos y duplicados, preservando el orden
    vistos = set()
    resultado = []
    for v in valores:
        if v and v not in vistos:
            vistos.add(v)
            resultado.append(v)
    return resultado


class Control:
    """Flags de control de la corrida (pausa/cancelación cooperativa)."""

    def __init__(self):
        self.pausado = False
        self.cancelado = False


class Tarjeta(ctk.CTkFrame):
    """Contenedor con esquinas redondeadas y título, para agrupar cada sección."""

    def __init__(self, master, titulo, **kwargs):
        super().__init__(
            master, corner_radius=18, fg_color=COLOR_SUPERFICIE,
            border_width=0, **kwargs
        )
        self.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            self, text=titulo, font=FUENTE_SUBTITULO, text_color=COLOR_TEXTO, anchor="w"
        ).grid(row=0, column=0, sticky="w", padx=20, pady=(16, 6))
        self.contenido = ctk.CTkFrame(self, fg_color="transparent")
        self.contenido.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 18))
        self.contenido.grid_columnconfigure(0, weight=1)


_COLORES_PASTILLA = {
    "ok": (COLOR_EXITO, COLOR_EXITO_TINTE),
    "err": (COLOR_PELIGRO, COLOR_PELIGRO_TINTE),
    "aviso": (COLOR_AVISO, COLOR_AVISO_TINTE),
    "neutro": (COLOR_MUTED, COLOR_ACENTO_TINTE),
}


class Pastilla(ctk.CTkFrame):
    """Etiqueta pequeña redondeada (customtkinter no tiene «pill»: marco + label)."""

    def __init__(self, master, texto="", tipo="neutro", tam=12):
        fg, bg = _COLORES_PASTILLA[tipo]
        super().__init__(master, corner_radius=14, fg_color=bg, border_width=0)
        self._label = ctk.CTkLabel(self, text=texto, font=fuente(tam, "bold"), text_color=fg)
        self._label.pack(padx=11, pady=3)

    def actualizar(self, texto, tipo=None):
        self._label.configure(text=texto)
        if tipo:
            fg, bg = _COLORES_PASTILLA[tipo]
            self.configure(fg_color=bg)
            self._label.configure(text_color=fg)


class FilaNav(ctk.CTkFrame):
    """Fila de una automatización en el panel lateral: insignia de dos letras,
    título y descripción. Toda la fila es clicable. `peligro` pinta la insignia
    en ámbar (la acción modifica o borra datos en Banner)."""

    def __init__(self, master, mono, titulo, descripcion, peligro, comando):
        super().__init__(master, corner_radius=12, height=48, fg_color="transparent")
        self.peligro = peligro
        self.activo = False
        self.grid_propagate(False)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure((0, 1), weight=1)

        self._insignia = ctk.CTkLabel(
            self, text=mono, width=32, height=32, corner_radius=9,
            font=fuente_mono(12, "bold"),
        )
        self._insignia.grid(row=0, column=0, rowspan=2, padx=(10, 10))
        self._titulo = ctk.CTkLabel(
            self, text=titulo, anchor="w", font=fuente(13, "bold"), text_color=COLOR_TEXTO
        )
        self._titulo.grid(row=0, column=1, sticky="sw", pady=(5, 0))
        self._desc = ctk.CTkLabel(
            self, text=descripcion, anchor="w", font=fuente(11), text_color=COLOR_MUTED
        )
        self._desc.grid(row=1, column=1, sticky="nw", pady=(0, 5))

        for w in (self, self._insignia, self._titulo, self._desc):
            w.bind("<Button-1>", lambda e: comando())
            w.bind("<Enter>", lambda e: self._hover(True))
            w.bind("<Leave>", self._al_salir)
            w.configure(cursor="hand2")
        self._pintar()

    def _pintar(self, hover=False):
        if self.activo:
            self.configure(fg_color=COLOR_SUPERFICIE)
            self._insignia.configure(fg_color=COLOR_ACENTO, text_color=COLOR_ACENTO_TEXTO)
        else:
            self.configure(fg_color=COLOR_INACTIVO if hover else "transparent")
            if self.peligro:
                self._insignia.configure(fg_color=COLOR_AVISO_TINTE, text_color=COLOR_AVISO)
            else:
                self._insignia.configure(fg_color=COLOR_SUPERFICIE, text_color=COLOR_MUTED)

    def _hover(self, dentro):
        if not self.activo:
            self._pintar(hover=dentro)

    def _al_salir(self, evento):
        # Salir de un hijo no es salir de la fila: solo se quita el resaltado
        # si el puntero ya no está sobre ningún descendiente.
        w = self.winfo_containing(evento.x_root, evento.y_root)
        while w is not None:
            if w is self:
                return
            w = getattr(w, "master", None)
        self._hover(False)

    def marcar(self, activo):
        self.activo = activo
        self._pintar()

    def compactar(self, compacto):
        """Con poca altura de ventana se oculta la descripción (la fila baja a 34 px)."""
        if compacto:
            self._desc.grid_remove()
            self._titulo.grid_configure(rowspan=2, sticky="w", pady=0)
            self.configure(height=34)
        else:
            self._desc.grid()
            self._titulo.grid_configure(rowspan=1, sticky="sw", pady=(5, 0))
            self.configure(height=48)


# ============================================================ PANTALLA 1 ==

class PantallaLogin(ctk.CTkFrame):
    """
    Unica pantalla visible mientras no hay sesion guardada. Deliberadamente
    minimalista: nada de funcionalidades hasta completar el login.
    """

    def __init__(self, master, on_login_exitoso, cola_logs):
        super().__init__(master, fg_color="transparent")
        self.on_login_exitoso = on_login_exitoso
        self.cola_logs = cola_logs

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        contenedor = ctk.CTkFrame(
            self, corner_radius=24, fg_color=COLOR_SUPERFICIE,
            border_width=0
        )
        contenedor.grid(row=0, column=0)
        contenedor.grid_columnconfigure(0, weight=1, minsize=380)

        PADX = 40

        logo_img = cargar_logo()
        if logo_img is not None:
            ctk.CTkLabel(contenedor, image=logo_img, text="").grid(
                row=0, column=0, pady=(44, 18)
            )
        else:
            badge = ctk.CTkFrame(
                contenedor, width=56, height=56, corner_radius=16, fg_color=COLOR_ACENTO
            )
            badge.grid(row=0, column=0, pady=(44, 18))
            badge.grid_propagate(False)
            badge.grid_columnconfigure(0, weight=1)
            badge.grid_rowconfigure(0, weight=1)
            ctk.CTkLabel(
                badge, text="UC", font=fuente(16, "bold"), text_color=COLOR_ACENTO_TEXTO
            ).grid(row=0, column=0)

        ctk.CTkLabel(
            contenedor, text="Automatizador Banner", font=FUENTE_TITULO, text_color=COLOR_TEXTO
        ).grid(row=1, column=0, padx=PADX, pady=(0, 4))

        ctk.CTkLabel(
            contenedor,
            text="Universidad Continental",
            font=FUENTE_TEXTO,
            text_color=COLOR_MUTED,
        ).grid(row=2, column=0, padx=PADX, pady=(0, 30))

        google_icon = cargar_google_icon()
        self.btn_login = ctk.CTkButton(
            contenedor,
            text="Iniciar sesión",
            image=google_icon,
            compound="left",
            height=42,
            font=fuente(13, "bold"),
            fg_color=COLOR_SUPERFICIE,
            border_width=1,
            border_color=COLOR_BORDE,
            text_color=COLOR_TEXTO,
            hover_color=COLOR_SUPERFICIE_2,
            corner_radius=12,
            command=self._on_click_login,
        )
        self.btn_login.grid(row=3, column=0, padx=PADX, pady=(0, 14), sticky="ew")

        ctk.CTkLabel(
            contenedor,
            text=(
                "Se abrirá una ventana pequeña para completar\n"
                "el inicio de sesión institucional."
            ),
            font=("Segoe UI", 11),
            text_color=COLOR_MUTED,
            justify="center",
        ).grid(row=4, column=0, padx=PADX, pady=(0, 4))

        self.label_estado = ctk.CTkLabel(
            contenedor, text="", font=("Segoe UI", 12), text_color=COLOR_MUTED,
            wraplength=340, justify="center",
        )
        self.label_estado.grid(row=5, column=0, padx=PADX, pady=(4, 0))

        separador = ctk.CTkFrame(contenedor, height=1, fg_color=COLOR_BORDE)
        separador.grid(row=6, column=0, sticky="ew", padx=PADX, pady=(18, 12))

        fila_estado = ctk.CTkFrame(contenedor, fg_color="transparent")
        fila_estado.grid(row=7, column=0, pady=(0, 30))
        punto = ctk.CTkFrame(fila_estado, width=6, height=6, corner_radius=3, fg_color="#b5b5bd")
        punto.grid(row=0, column=0, padx=(0, 6))
        punto.grid_propagate(False)
        ctk.CTkLabel(
            fila_estado, text="Sin sesión activa", font=("Segoe UI", 11), text_color=COLOR_MUTED
        ).grid(row=0, column=1)

    def _on_click_login(self):
        self.btn_login.configure(state="disabled", text="Conectando...")
        self.label_estado.configure(
            text="Se abrio una ventana del navegador. Completa el login ahi."
        )

        raiz = self.winfo_toplevel()
        raiz.update_idletasks()
        x_app = raiz.winfo_x()
        y_app = raiz.winfo_y()
        ancho_app = raiz.winfo_width()
        ancho_pantalla = raiz.winfo_screenwidth()

        pos_x = x_app + ancho_app + 16
        if pos_x + 480 > ancho_pantalla:
            pos_x = x_app + 40
        pos_y = max(y_app - 20, 0)

        def trabajo():
            try:
                asyncio.run(iniciar_login_interactivo(
                    lambda m: self.cola_logs.put(("log", m)), pos_x=pos_x, pos_y=pos_y
                ))
                self.cola_logs.put(("login_ok", None))
            except Exception as err:
                self.cola_logs.put(("login_error", str(err)))

        threading.Thread(target=trabajo, daemon=True).start()

    def notificar_login_ok(self):
        self.label_estado.configure(text="Listo! Entrando...")
        self.after(600, self.on_login_exitoso)

    def notificar_login_error(self, motivo: str):
        self.btn_login.configure(state="normal", text="Iniciar sesión")
        self.label_estado.configure(text=f"No se pudo iniciar sesion: {motivo}")


# ============================================================ PANTALLA 2 ==

class ChipEstado(ctk.CTkFrame):
    """
    Contador de estado en una sola fila (pendientes/procesados/fallos):
    ícono + título + nota + contador en vivo. El de fallos es clicable para
    ver el detalle de cada fallo.
    """

    def __init__(self, master, icono, titulo, nombre_archivo, color, on_click=None):
        super().__init__(master, corner_radius=12, fg_color=COLOR_SUPERFICIE_2, border_width=0, height=40)
        self.grid_columnconfigure(2, weight=1)
        self._clicable = on_click is not None

        ctk.CTkLabel(self, text=icono, font=fuente(14, "bold"), text_color=color, width=18).grid(
            row=0, column=0, sticky="w", padx=(12, 0), pady=8
        )
        ctk.CTkLabel(self, text=titulo, font=fuente(13, "bold"), text_color=COLOR_TEXTO).grid(
            row=0, column=1, sticky="w", padx=(6, 0)
        )
        ctk.CTkLabel(self, text=nombre_archivo, font=fuente(11), text_color=COLOR_MUTED, anchor="w").grid(
            row=0, column=2, sticky="w", padx=(8, 0)
        )
        self.label_contador = ctk.CTkLabel(
            self, text="0", font=fuente(16, "bold"), text_color=COLOR_TEXTO
        )
        self.label_contador.grid(row=0, column=3, sticky="e", padx=(8, 14))

        if on_click is not None:
            hijos = [self] + list(self.winfo_children())
            for widget in hijos:
                widget.bind("<Button-1>", lambda e: on_click())
                widget.bind("<Enter>", lambda e: self.configure(fg_color=COLOR_BORDE))
                widget.bind("<Leave>", self._al_salir)
                widget.configure(cursor="hand2")

    def _al_salir(self, evento):
        w = self.winfo_containing(evento.x_root, evento.y_root)
        while w is not None:
            if w is self:
                return
            w = getattr(w, "master", None)
        self.configure(fg_color=COLOR_SUPERFICIE_2)

    def actualizar(self, valor: int):
        self.label_contador.configure(text=str(valor))


# ----------------------------------------------------------------------------
# Textos de la interfaz por automatización. La lógica de cada una vive en
# src/ y en _on_iniciar; aquí solo está lo que se ve.
# ----------------------------------------------------------------------------

def _ajustar(texto, ancho=50):
    return textwrap.fill(texto, ancho)


ACCIONES_UI = {
    "estatus": {
        "titulo": "Cambiar estatus",
        "pastilla": "SSASECT · Secciones", "tipo": "neutro",
        "subtitulo": "Cambia el estatus de cada NRC al valor indicado.",
        "entrada": "NRCs a procesar",
        "ayuda": "Un NRC por línea.\nEj.: 2465",
        "importar": "Importar Excel",
        "aviso": None,
    },
    "voz": {
        "titulo": "Alternar respuesta de voz",
        "pastilla": "SSASECT · Secciones", "tipo": "neutro",
        "subtitulo": "Alterna la respuesta de voz de cada NRC.",
        "entrada": "NRCs a procesar",
        "ayuda": "Un NRC por línea.\nEj.: 2465",
        "importar": "Importar Excel",
        "aviso": None,
    },
    "sfabrdf": {
        "titulo": "Reglas de bloque",
        "pastilla": "SFABRDF · Reglas de bloque", "tipo": "neutro",
        "subtitulo": "Define una regla de bloque por cada línea.",
        "entrada": "Reglas a procesar",
        "ayuda": "Una regla por línea, 8 campos con coma:\n" + _ajustar(ENCABEZADO_SFABRDF, 46),
        "importar": "Importar CSV/Excel",
        "aviso": None,
    },
    "stvblck": {
        "titulo": "Códigos de bloque",
        "pastilla": "STVBLCK · Códigos", "tipo": "neutro",
        "subtitulo": "Valida un código de bloque por línea. No usa periodo.",
        "entrada": "Códigos a procesar",
        "ayuda": "Un código de bloque por línea.\nLa descripción será igual al código.",
        "importar": "Importar CSV/Excel",
        "aviso": None,
    },
    "ssarres_quitar": {
        "titulo": f"Quitar programa {SSARRES_PROGRAMA}",
        "pastilla": "SSARRES · Modifica datos", "tipo": "aviso",
        "subtitulo": f"Quita el programa {SSARRES_PROGRAMA} de cada NRC.",
        "entrada": "NRCs a procesar",
        "ayuda": "Un NRC por línea (solo dígitos).\nEj.: 2465",
        "importar": "Importar CSV/Excel",
        "aviso": f"Atención: se quitará el programa\n{SSARRES_PROGRAMA} de cada NRC en Banner.",
    },
    ACCION_SSARRES_CONSERVAR: {
        "titulo": "Dejar solo programas",
        "pastilla": "SSARRES · Modifica datos", "tipo": "aviso",
        "subtitulo": "Deja en cada NRC únicamente los programas indicados y borra todos los demás.",
        "entrada": "NRC y programas a conservar",
        "ayuda": "Una línea por NRC: NRC,código,código\nCódigo = 3 dígitos. Ej.: 2465,503,504",
        "importar": "Importar CSV/Excel",
        "aviso": "Atención: se borrarán programas\nen Banner. El guardado (F10) solo\nocurre tras verificar la lista\ncompleta de cada NRC.",
    },
    ACCION_SSARRES_ATRIBUTO: {
        "titulo": "Quitar atributo",
        "pastilla": "SSARRES · Modifica datos", "tipo": "aviso",
        "subtitulo": "Quita el atributo elegido de cada NRC.",
        "entrada": "NRCs a procesar",
        "ayuda": "Un NRC por línea (solo dígitos).\nEj.: 2465",
        "importar": "Importar CSV/Excel",
        "aviso": "Atención: se quitará el atributo\nindicado de cada NRC en Banner.",
    },
    ACCION_SSARRES_AGREGAR: {
        "titulo": f"Agregar programa {SSARRES_AGREGAR_PROGRAMA}",
        "pastilla": "SSARRES · Modifica datos", "tipo": "aviso",
        "subtitulo": f"Agrega el programa {SSARRES_AGREGAR_PROGRAMA} a la lista de programas de cada NRC.",
        "entrada": "NRCs a procesar",
        "ayuda": "Un NRC por línea (solo dígitos).\nEj.: 2465\nUn NRC sin programas se omite (quedaría\nrestringido solo al 502).",
        "importar": "Importar CSV/Excel",
        "aviso": f"Atención: se agregará el programa\n{SSARRES_AGREGAR_PROGRAMA} a cada NRC en Banner. Se\nguarda (F10) solo tras verificar la\nlista completa. Corre con 1 pestaña.",
    },
}

# Acciones que borran o modifican datos en Banner: piden confirmación antes de iniciar.
ACCIONES_DESTRUCTIVAS = ("ssarres_quitar", ACCION_SSARRES_CONSERVAR, ACCION_SSARRES_ATRIBUTO, ACCION_SSARRES_AGREGAR)

# Panel lateral: (código de la forma de Banner, nombre, [(acción, insignia, título, descripción, modifica)]).
GRUPOS_NAV = [
    ("SSASECT", "Secciones", [
        ("estatus", "ES", "Cambiar estatus", "Abrir o cerrar NRC", False),
        ("voz", "VZ", "Alternar voz", "Respuesta de voz por NRC", False)]),
    ("SFABRDF", "Reglas de bloque", [
        ("sfabrdf", "RB", "Reglas de bloque", "Insertar reglas desde archivo", False)]),
    ("STVBLCK", "Códigos", [
        ("stvblck", "CB", "Códigos de bloque", "Dar de alta códigos nuevos", False)]),
    ("SSARRES", "Restricciones", [
        ("ssarres_quitar", "50", f"Quitar programa {SSARRES_PROGRAMA}", f"Borra el {SSARRES_PROGRAMA} de cada NRC", True),
        (ACCION_SSARRES_CONSERVAR, "DS", "Dejar solo programas", "Deja solo los indicados", True),
        (ACCION_SSARRES_ATRIBUTO, "AT", "Quitar atributo", "Borra un atributo de alumno", True),
        (ACCION_SSARRES_AGREGAR, "AG", f"Agregar programa {SSARRES_AGREGAR_PROGRAMA}", f"Agrega el {SSARRES_AGREGAR_PROGRAMA} a cada NRC", True)]),
]


class PantallaPrincipal(ctk.CTkFrame):
    """
    Funcionalidades del sistema. Solo se muestra tras un login exitoso.
    Implementa el layout aprobado: panel lateral + panel de contenido.
    """

    def __init__(self, master, cola_logs, on_sesion_perdida=None):
        super().__init__(master, fg_color="transparent")
        self.cola_logs = cola_logs
        self.on_sesion_perdida = on_sesion_perdida
        self.control = Control()
        self.corrida_activa = False
        self.estado_corrida_actual = None  # EstadoCorrida de la corrida en curso / última
        self.accion_actual = "estatus"  # "estatus" | "voz" | "sfabrdf" | "stvblck" | "ssarres_quitar" | "ssarres_conservar" | "ssarres_atributo_quitar" | "ssarres_agregar"
        # "nrcs" (SSASECT: una lista de NRCs), "reglas" (SFABRDF: una regla
        # de 8 campos por línea), "codigos" (STVBLCK: un código de bloque por
        # línea) o "conservar" (SSARRES «Dejar solo programas»: NRC + códigos a
        # conservar por línea). Al cambiar de familia se limpia el textarea,
        # porque las líneas de una no sirven para la otra.
        self._familia_textarea = "nrcs"
        # Arranca siempre en 5, sin importar qué se haya usado la última
        # vez: usar más de 5 pestañas es una medida excepcional para
        # corridas puntuales, no una preferencia que deba quedar pegada
        # entre sesiones.
        self.num_pestanas = 5
        self.tiempo_inicio = None

        self._n_errores = 0          # líneas con error según la validación en vivo
        self._job_validacion = None
        self._filas_nav = {}

        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._construir_sidebar()
        self._construir_panel_principal()

    # ------------------------------------------------------- construcción --

    def _construir_sidebar(self):
        lateral = ctk.CTkFrame(self, width=ANCHO_LATERAL, corner_radius=0, fg_color=COLOR_SIDEBAR)
        lateral.grid(row=0, column=0, sticky="nsw")
        lateral.pack_propagate(False)

        # Cabecera: logo de la universidad + nombre de la app.
        cab = ctk.CTkFrame(lateral, fg_color="transparent")
        cab.pack(fill="x", padx=18, pady=(18, 8))
        logo_img = cargar_logo(36)
        if logo_img is not None:
            ctk.CTkLabel(cab, image=logo_img, text="").pack(side="left")
        else:
            ctk.CTkLabel(
                cab, text="UC", width=36, height=36, corner_radius=10,
                fg_color=COLOR_ACENTO, text_color=COLOR_ACENTO_TEXTO, font=fuente(14, "bold"),
            ).pack(side="left")
        col = ctk.CTkFrame(cab, fg_color="transparent")
        col.pack(side="left", padx=10)
        ctk.CTkLabel(col, text=APP_NOMBRE, font=fuente(14, "bold"), text_color=COLOR_TEXTO, anchor="w").pack(anchor="w")
        ctk.CTkLabel(col, text="Universidad Continental", font=fuente(11),
                     text_color=COLOR_MUTED, anchor="w").pack(anchor="w")

        # Pie (se empaqueta antes que las tarjetas para que siempre quede visible):
        # correo de consultas y versión.
        pie = ctk.CTkFrame(lateral, fg_color="transparent")
        pie.pack(side="bottom", fill="x", padx=18, pady=(4, 14))
        self.label_version = ctk.CTkLabel(
            pie, text=f"v{APP_VERSION}", font=fuente(10, "bold"), text_color=COLOR_MUTED
        )
        self.label_version.pack(side="right")
        self.label_correo = ctk.CTkLabel(
            pie, text=CORREO_CONSULTAS, font=fuente(11, "underline"), text_color=COLOR_MUTED,
            anchor="w", cursor="hand2",
        )
        self.label_correo.pack(side="left")
        self.label_correo.bind("<Button-1>", lambda e: self._escribir_a_consultas())

        # Una tarjeta gris por forma de Banner, con sus acciones dentro.
        self._filas_nav = {}
        for codigo, nombre, items in GRUPOS_NAV:
            tarjeta = ctk.CTkFrame(lateral, corner_radius=16, fg_color=COLOR_SUPERFICIE_2)
            tarjeta.pack(fill="x", padx=12, pady=4)
            fila_cab = ctk.CTkFrame(tarjeta, fg_color="transparent")
            fila_cab.pack(fill="x", padx=14, pady=(9, 2))
            ctk.CTkLabel(fila_cab, text=codigo, font=fuente(12, "bold"), text_color=COLOR_TEXTO).pack(side="left")
            ctk.CTkLabel(fila_cab, text=nombre, font=fuente(11), text_color=COLOR_MUTED).pack(side="left", padx=(8, 0))
            if any(it[4] for it in items):
                Pastilla(fila_cab, "modifica", "aviso", 10).pack(side="right")
            for valor, mono, titulo, desc, peligro in items:
                fila = FilaNav(tarjeta, mono, titulo, desc, peligro,
                               comando=lambda v=valor: self._seleccionar_automatizacion(v))
                fila.pack(fill="x", padx=6, pady=1)
                self._filas_nav[valor] = fila
            ctk.CTkFrame(tarjeta, height=4, fg_color="transparent").pack()

        # Atributos con el nombre que usa el resto del código.
        self.btn_side_estatus = self._filas_nav["estatus"]
        self.btn_side_voz = self._filas_nav["voz"]
        self.btn_side_sfabrdf = self._filas_nav["sfabrdf"]
        self.btn_side_stvblck = self._filas_nav["stvblck"]
        self.btn_side_ssarres_quitar = self._filas_nav["ssarres_quitar"]
        self.btn_side_ssarres_conservar = self._filas_nav[ACCION_SSARRES_CONSERVAR]
        self.btn_side_ssarres_atributo = self._filas_nav[ACCION_SSARRES_ATRIBUTO]
        self.btn_side_ssarres_agregar = self._filas_nav[ACCION_SSARRES_AGREGAR]

        # Con ventanas bajas (laptops con escala alta) se compactan las filas.
        self._lateral_compacto = False
        lateral.bind("<Configure>", lambda e: self._ajustar_lateral(e.height))

    def _ajustar_lateral(self, alto):
        compacto = alto < ALTO_MINIMO_LATERAL_COMPLETO
        if compacto != self._lateral_compacto:
            self._lateral_compacto = compacto
            for fila in self._filas_nav.values():
                fila.compactar(compacto)

    def _escribir_a_consultas(self):
        """Abre el correo de consultas; si no hay programa de correo, lo copia al portapapeles."""
        try:
            abierto = webbrowser.open(f"mailto:{CORREO_CONSULTAS}?subject=Consulta%20{APP_NOMBRE.replace(' ', '%20')}%20v{APP_VERSION}")
        except Exception:
            abierto = False
        if not abierto:
            self.clipboard_clear()
            self.clipboard_append(CORREO_CONSULTAS)
            self._log(f"Correo de consultas copiado al portapapeles: {CORREO_CONSULTAS}", tipo="info")

    def _campo(self, padre, etiqueta):
        """Marco con una etiqueta pequeña arriba, para los campos del encabezado."""
        marco = ctk.CTkFrame(padre, fg_color="transparent")
        lbl = ctk.CTkLabel(marco, text=etiqueta, font=fuente(11, "bold"), text_color=COLOR_MUTED, anchor="w")
        lbl.pack(anchor="w")
        return marco, lbl

    def _boton_suave(self, padre, texto, comando, ancho=0, alto=32, sobre_suave=False, neutro=True):
        return ctk.CTkButton(
            padre, text=texto, command=comando, width=ancho, height=alto, corner_radius=10,
            fg_color=COLOR_SUPERFICIE if sobre_suave else COLOR_ACENTO_TINTE,
            text_color=COLOR_TEXTO, hover_color=COLOR_BORDE, font=fuente(12, "bold"),
        )

    def _construir_panel_principal(self):
        panel = ctk.CTkFrame(self, fg_color="transparent")
        panel.grid(row=0, column=1, sticky="nsew")
        panel.grid_columnconfigure(0, weight=1)
        panel.grid_rowconfigure(1, weight=1)

        # --- Encabezado: acción actual + campos que usa ---
        encabezado = ctk.CTkFrame(panel, fg_color="transparent")
        encabezado.grid(row=0, column=0, sticky="ew", padx=24, pady=(14, 2))
        encabezado.grid_columnconfigure(0, weight=1)

        # Fila 0: etiqueta de la acción (izquierda) y sesión (derecha).
        # Fila 1: título (izquierda) y campos de la acción (derecha). Fila 2: subtítulo.
        self.pastilla_accion = Pastilla(encabezado, "", "neutro", 11)
        self.pastilla_accion.grid(row=0, column=0, sticky="w")
        self.label_titulo_accion = ctk.CTkLabel(
            encabezado, text="Cambiar estatus", font=FUENTE_TITULO, text_color=COLOR_TEXTO, anchor="w"
        )
        self.label_titulo_accion.grid(row=1, column=0, sticky="sw", pady=(6, 0))

        # Sesión: arriba a la derecha, donde se espera encontrarla.
        sesion = ctk.CTkFrame(encabezado, corner_radius=16, fg_color=COLOR_SUPERFICIE, border_width=0)
        sesion.grid(row=0, column=1, columnspan=3, sticky="e")
        self.badge_sesion = ctk.CTkLabel(
            sesion, text="●  Sesión activa", font=fuente(12, "bold"), text_color=COLOR_EXITO
        )
        self.badge_sesion.pack(side="left", padx=(14, 6), pady=4)
        ctk.CTkFrame(sesion, width=1, height=16, fg_color=COLOR_BORDE).pack(side="left")
        self.btn_cerrar_sesion = ctk.CTkButton(
            sesion, text="Cerrar sesión", width=96, height=26, corner_radius=12,
            font=fuente(12, "bold"), fg_color="transparent", text_color=COLOR_TEXTO,
            hover_color=COLOR_ACENTO_TINTE, command=self._on_cerrar_sesion,
        )
        self.btn_cerrar_sesion.pack(side="left", padx=(4, 4), pady=3)

        # Periodo (STVBLCK no lo usa: se oculta). Solo dígitos, máximo 6.
        self.campo_periodo, self.label_periodo = self._campo(encabezado, "Periodo")
        self.entry_periodo = ctk.CTkEntry(
            self.campo_periodo, width=116, height=38, corner_radius=10, border_width=0,
            fg_color=COLOR_SUPERFICIE, text_color=COLOR_TEXTO, font=fuente_mono(14),
            placeholder_text="202510",
        )
        self.entry_periodo.pack()
        vcmd_periodo = self.register(self._validar_periodo)
        self.entry_periodo.configure(validate="key", validatecommand=(vcmd_periodo, "%P"))
        self.campo_periodo.grid(row=1, column=1, sticky="s", padx=(12, 0))

        # Nuevo estatus (solo «Cambiar estatus»): 1 carácter, siempre en mayúscula.
        self.campo_estatus, self.label_estatus = self._campo(encabezado, "Nuevo estatus")
        self.var_estatus = ctk.StringVar()
        self.entry_estatus = ctk.CTkEntry(
            self.campo_estatus, textvariable=self.var_estatus, width=116, height=38, corner_radius=10,
            border_width=0, fg_color=COLOR_SUPERFICIE, text_color=COLOR_TEXTO,
            font=fuente_mono(14), placeholder_text="ej. A",
        )
        self.entry_estatus.pack()
        self.var_estatus.trace_add("write", self._normalizar_estatus)
        self.campo_estatus.grid(row=1, column=2, sticky="s", padx=(12, 0))

        # Atributo a quitar (solo «Quitar atributo»): desplegable con los habituales,
        # también se puede escribir otro código.
        self.campo_atributo, self.label_atributo = self._campo(encabezado, "Atributo a quitar")
        self.var_atributo = ctk.StringVar(value=SSARRES_ATRIBUTO)
        self.combo_atributo = ctk.CTkComboBox(
            self.campo_atributo, variable=self.var_atributo, values=list(SSARRES_ATRIBUTOS_SUGERIDOS),
            width=150, height=38, corner_radius=10, border_width=0, fg_color=COLOR_SUPERFICIE,
            button_color=COLOR_ACENTO_TINTE, button_hover_color=COLOR_BORDE, text_color=COLOR_TEXTO,
            dropdown_fg_color=COLOR_SUPERFICIE, dropdown_text_color=COLOR_TEXTO,
            dropdown_hover_color=COLOR_ACENTO_TINTE, font=fuente_mono(14),
        )
        self.combo_atributo.pack()
        self.var_atributo.trace_add("write", self._normalizar_atributo)
        self.campo_atributo.grid(row=1, column=2, sticky="s", padx=(12, 0))
        self.campo_atributo.grid_remove()

        # Pestañas en paralelo (antes un engranaje): abre la ventana de configuración.
        marco_pest = ctk.CTkFrame(encabezado, fg_color="transparent")
        ctk.CTkLabel(marco_pest, text="Procesos simultáneos", font=fuente(11, "bold"),
                     text_color=COLOR_MUTED, anchor="w").pack(anchor="w")
        self.btn_configuracion = ctk.CTkButton(
            marco_pest, text=f"Procesos: {self.num_pestanas}", width=136, height=38, corner_radius=10,
            font=fuente(13, "bold"), fg_color=COLOR_SUPERFICIE, text_color=COLOR_TEXTO,
            hover_color=COLOR_ACENTO_TINTE, command=self._abrir_configuracion,
        )
        self.btn_configuracion.pack()
        marco_pest.grid(row=1, column=3, sticky="s", padx=(12, 0))

        self.label_subtitulo_accion = ctk.CTkLabel(
            encabezado, text="", font=fuente(13), text_color=COLOR_MUTED, anchor="w", justify="left"
        )
        self.label_subtitulo_accion.grid(row=2, column=0, columnspan=4, sticky="w", pady=(2, 0))

        # --- Cuerpo desplazable (por si la ventana es baja) ---
        cuerpo = ctk.CTkScrollableFrame(
            panel, fg_color="transparent",
            scrollbar_button_color=COLOR_BORDE, scrollbar_button_hover_color="#cfcfd6",
        )
        cuerpo.grid(row=1, column=0, sticky="nsew", padx=(18, 12), pady=(0, 12))
        cuerpo.grid_columnconfigure(0, weight=1)
        cuerpo.grid_columnconfigure(1, weight=0, minsize=ANCHO_COLUMNA_DERECHA)

        # 1) Lista de entrada + validación en vivo
        izquierda = ctk.CTkFrame(cuerpo, fg_color="transparent")
        izquierda.grid(row=0, column=0, sticky="new", padx=(6, 8), pady=(8, 8))
        entrada = ctk.CTkFrame(izquierda, corner_radius=18, fg_color=COLOR_SUPERFICIE, border_width=0)
        entrada.pack(fill="x")
        interior = ctk.CTkFrame(entrada, fg_color="transparent")
        interior.pack(fill="both", expand=True, padx=18, pady=16)

        self.label_titulo_entrada = ctk.CTkLabel(
            interior, text="NRCs a procesar", font=FUENTE_SUBTITULO, text_color=COLOR_TEXTO, anchor="w"
        )
        self.label_titulo_entrada.pack(anchor="w")

        ayuda = ctk.CTkFrame(interior, corner_radius=12, fg_color=COLOR_ACENTO_TINTE, border_width=0)
        ayuda.pack(fill="x", pady=(10, 10))
        self.btn_importar = ctk.CTkButton(
            ayuda, text="Importar Excel", width=132, height=30, corner_radius=10,
            font=fuente(12, "bold"), fg_color=COLOR_SUPERFICIE, text_color=COLOR_TEXTO,
            hover_color=COLOR_BORDE, command=self._on_importar_excel,
        )
        self.btn_importar.pack(side="right", padx=10, pady=10)
        self.label_pendientes = ctk.CTkLabel(
            ayuda, text="", font=fuente(12), text_color=COLOR_TEXTO, justify="left", anchor="w"
        )
        self.label_pendientes.pack(side="left", padx=(14, 6), pady=10)

        self.texto_nrcs = ctk.CTkTextbox(
            interior, height=190, corner_radius=12, fg_color=COLOR_SUPERFICIE_2, border_width=0,
            text_color=COLOR_TEXTO, font=FUENTE_MONO, wrap="none",
        )
        self.texto_nrcs.pack(fill="x")
        # Líneas con error: fondo rojo suave (el CTkTextbox deja usar tags de Tk).
        self.texto_nrcs.tag_config("error", background=COLOR_PELIGRO_TINTE, foreground=COLOR_PELIGRO)
        self.texto_nrcs._textbox.configure(spacing1=3, spacing3=3, padx=14, pady=8)
        self.texto_nrcs.bind("<KeyRelease>", lambda e: self._programar_validacion())

        # Caja de problemas: se muestra solo si hay líneas con error.
        self.caja_problemas = ctk.CTkFrame(
            interior, corner_radius=12, fg_color=COLOR_PELIGRO_TINTE, border_width=0
        )
        self.label_problemas = ctk.CTkLabel(
            self.caja_problemas, text="", font=fuente(12, "bold"), text_color=COLOR_PELIGRO, anchor="w"
        )
        self.label_problemas.pack(fill="x", padx=14, pady=(8, 2))
        self.texto_problemas = ctk.CTkTextbox(
            self.caja_problemas, height=76, corner_radius=8, fg_color=COLOR_PELIGRO_TINTE,
            border_width=0, text_color=COLOR_TEXTO, font=fuente(12), wrap="word",
            scrollbar_button_color="#efc2c6", scrollbar_button_hover_color="#e5a9ae",
        )
        self.texto_problemas.pack(fill="x", padx=10, pady=(0, 8))
        self.texto_problemas.configure(state="disabled")

        self.pie_entrada = ctk.CTkFrame(interior, fg_color="transparent")
        self.pie_entrada.pack(fill="x", pady=(10, 0))
        self.pastilla_validas = Pastilla(self.pie_entrada, "0 válidas", "ok", 12)
        self.pastilla_validas.pack(side="left", padx=(0, 8))
        self.pastilla_errores = Pastilla(self.pie_entrada, "0 con error", "err", 12)
        self.label_repetidas = ctk.CTkLabel(
            self.pie_entrada, text="", font=fuente(11), text_color=COLOR_MUTED
        )
        self.label_repetidas.pack(side="left", padx=(8, 0))
        self.btn_limpiar = self._boton_suave(
            self.pie_entrada, "Limpiar", self._on_limpiar_lista, ancho=84, alto=30
        )
        self.btn_limpiar.pack(side="right")

        # 2) Columna derecha: estado de la corrida
        derecha = ctk.CTkFrame(cuerpo, fg_color="transparent")
        derecha.grid(row=0, column=1, sticky="new", padx=(0, 6), pady=(8, 0))

        estado = ctk.CTkFrame(derecha, corner_radius=18, fg_color=COLOR_SUPERFICIE, border_width=0)
        estado.pack(fill="x")
        ctk.CTkLabel(estado, text="Estado de la corrida", font=FUENTE_SUBTITULO,
                     text_color=COLOR_TEXTO, anchor="w").pack(fill="x", padx=18, pady=(16, 8))

        self.chip_pendientes = ChipEstado(estado, "○", "Pendientes", "", COLOR_MUTED)
        self.chip_pendientes.pack(fill="x", padx=14, pady=2)
        self.chip_procesados = ChipEstado(estado, "✓", "Procesados", "", COLOR_EXITO)
        self.chip_procesados.pack(fill="x", padx=14, pady=2)
        self.chip_fallos = ChipEstado(
            estado, "✕", "Fallos", "ver detalle ›", COLOR_PELIGRO, on_click=self._mostrar_detalle_fallos
        )
        self.chip_fallos.pack(fill="x", padx=14, pady=2)

        fila_progreso = ctk.CTkFrame(estado, fg_color="transparent")
        fila_progreso.pack(fill="x", padx=18, pady=(12, 0))
        fila_progreso.grid_columnconfigure(0, weight=1)
        self.barra_progreso = ctk.CTkProgressBar(
            fila_progreso, height=8, corner_radius=4, fg_color=COLOR_ACENTO_TINTE, progress_color=COLOR_ACENTO
        )
        self.barra_progreso.set(0)
        self.barra_progreso.grid(row=0, column=0, sticky="ew", padx=(0, 12))
        self.label_cronometro = ctk.CTkLabel(
            fila_progreso, text="00:00", font=fuente_mono(13), text_color=COLOR_MUTED
        )
        self.label_cronometro.grid(row=0, column=1, sticky="e")
        self.label_progreso = ctk.CTkLabel(
            estado, text="Sin corridas todavía.", font=fuente(12), text_color=COLOR_MUTED, anchor="w"
        )
        self.label_progreso.pack(fill="x", padx=18, pady=(4, 10))

        self.btn_iniciar = ctk.CTkButton(
            estado, text="Iniciar", command=self._on_iniciar, height=44, corner_radius=12,
            font=fuente(14, "bold"), fg_color=COLOR_ACENTO, hover_color=COLOR_ACENTO_HOVER,
            text_color=COLOR_ACENTO_TEXTO, text_color_disabled=COLOR_INACTIVO_TEXTO,
        )
        self.btn_iniciar.pack(fill="x", padx=18, pady=(0, 8))

        fila_botones = ctk.CTkFrame(estado, fg_color="transparent")
        fila_botones.pack(fill="x", padx=18, pady=(0, 18))
        fila_botones.grid_columnconfigure((0, 1), weight=1, uniform="botones")
        self.btn_pausar = ctk.CTkButton(
            fila_botones, text="Pausar", command=self._on_pausar, state="disabled", height=36,
            corner_radius=10, font=fuente(12, "bold"), fg_color=COLOR_ACENTO_TINTE,
            text_color=COLOR_TEXTO, hover_color=COLOR_BORDE, text_color_disabled=COLOR_INACTIVO_TEXTO,
        )
        self.btn_pausar.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.btn_cancelar = ctk.CTkButton(
            fila_botones, text="Cancelar", command=self._on_cancelar, state="disabled", height=36,
            corner_radius=10, font=fuente(12, "bold"), fg_color=COLOR_PELIGRO_TINTE,
            text_color=COLOR_PELIGRO, hover_color="#f5d3d6", text_color_disabled=COLOR_INACTIVO_TEXTO,
        )
        self.btn_cancelar.grid(row=0, column=1, sticky="ew", padx=(4, 0))

        # Aviso ámbar: solo en las acciones que borran o modifican datos.
        self.tarjeta_aviso = ctk.CTkFrame(
            derecha, corner_radius=14, fg_color=COLOR_AVISO_TINTE, border_width=0
        )
        self.label_aviso = ctk.CTkLabel(
            self.tarjeta_aviso, text="", font=fuente(12), text_color=COLOR_AVISO, justify="left", anchor="w"
        )
        self.label_aviso.pack(fill="x", padx=14, pady=12)

        # 3) Log
        tarjeta_log = Tarjeta(izquierda, "Registro")
        tarjeta_log.pack(fill="x", pady=(10, 0))
        self.texto_log = ctk.CTkTextbox(
            tarjeta_log.contenido, height=88, corner_radius=12, font=FUENTE_MONO,
            fg_color=COLOR_LOG_BG, text_color=COLOR_TEXTO, border_width=0,
        )
        self.texto_log.grid(row=0, column=0, sticky="ew")
        self.texto_log._textbox.configure(padx=12, pady=8)
        self.texto_log.configure(state="disabled")
        # Colores por tipo de evento sobre el widget interno de tkinter
        # (CTkTextbox envuelve un tk.Text real en _textbox).
        try:
            self.texto_log._textbox.tag_config("exito", foreground=COLOR_EXITO)
            self.texto_log._textbox.tag_config("error", foreground=COLOR_PELIGRO)
            self.texto_log._textbox.tag_config("info", foreground=COLOR_MUTED)
        except Exception:
            pass

        self._seleccionar_automatizacion("estatus")

    # ----------------------------------------------------------- eventos --

    def _validar_periodo(self, texto_propuesto: str) -> bool:
        """
        Validador de tecleo para el campo Periodo: permite vacío (mientras
        se borra) y solo dígitos, hasta 6 caracteres. Cualquier otra tecla
        (letras, más de 6 dígitos) se rechaza antes de llegar al campo.
        """
        if texto_propuesto == "":
            return True
        return texto_propuesto.isdigit() and len(texto_propuesto) <= 6

    def _normalizar_atributo(self, *_args):
        """El atributo siempre en MAYÚSCULAS, sin espacios y máximo 15 caracteres."""
        valor = self.var_atributo.get()
        normalizado = "".join(valor.split()).upper()[:15]
        if normalizado != valor:
            self.var_atributo.set(normalizado)

    def _normalizar_estatus(self, *_args):
        valor = self.var_estatus.get()
        normalizado = valor.upper()[:1]
        if normalizado != valor:
            self.var_estatus.set(normalizado)

    def _seleccionar_automatizacion(self, valor_accion):
        self.accion_actual = valor_accion
        ui = ACCIONES_UI[valor_accion]

        for clave, fila in self._filas_nav.items():
            fila.marcar(clave == valor_accion)

        # Campos del encabezado: cada automatización muestra solo los que usa.
        # STVBLCK abre directo en la grilla: no usa periodo.
        if valor_accion == "stvblck":
            self.campo_periodo.grid_remove()
        else:
            self.campo_periodo.grid()
        if valor_accion == "estatus":
            self.campo_estatus.grid()
        else:
            self.campo_estatus.grid_remove()
        if valor_accion == ACCION_SSARRES_ATRIBUTO:
            self.campo_atributo.grid()
        else:
            self.campo_atributo.grid_remove()

        self.pastilla_accion.actualizar(ui["pastilla"], ui["tipo"])
        self.label_titulo_accion.configure(text=ui["titulo"])
        self.label_subtitulo_accion.configure(text=ui["subtitulo"])
        self.label_titulo_entrada.configure(text=ui["entrada"])
        self.label_pendientes.configure(text=ui["ayuda"])
        self.btn_importar.configure(text=ui["importar"])

        if ui["aviso"]:
            self.label_aviso.configure(text=ui["aviso"])
            self.tarjeta_aviso.pack(fill="x", pady=(12, 0))
        else:
            self.tarjeta_aviso.pack_forget()

        # Las líneas de una familia (NRCs / reglas / códigos) no sirven para
        # las otras: al cambiar de familia se limpia el textarea (salvo con una
        # corrida en curso, para no borrarle la lista de pendientes que se va
        # vaciando).
        familia = {"sfabrdf": "reglas", "stvblck": "codigos", ACCION_SSARRES_CONSERVAR: "conservar"}.get(valor_accion, "nrcs")
        if familia != self._familia_textarea and not self.corrida_activa:
            self.texto_nrcs.delete("1.0", "end")
        self._familia_textarea = familia

        # Precargar pendientes de esta automatización solo si el textarea
        # está vacío, para no pisar algo que el usuario ya haya escrito.
        if not self.texto_nrcs.get("1.0", "end").strip():
            self._precargar_pendientes()
        self._actualizar_chips()

    # ------------------------------------------- validación en vivo (fase 2) --

    def _validador_actual(self):
        """Mismo validador que usa _on_iniciar para la acción actual (o None si
        esa acción no valida las líneas antes de iniciar)."""
        return {
            "sfabrdf": validar_lineas,
            "stvblck": validar_codigos,
            "ssarres_quitar": validar_nrcs,
            ACCION_SSARRES_ATRIBUTO: validar_nrcs_atributo,
            ACCION_SSARRES_CONSERVAR: validar_lineas_conservar,
            ACCION_SSARRES_AGREGAR: validar_nrcs_agregar,
        }.get(self.accion_actual)

    def _programar_validacion(self):
        """Valida poco después de la última tecla, para no recalcular en cada una."""
        if self._job_validacion is not None:
            try:
                self.after_cancel(self._job_validacion)
            except Exception:
                pass
        self._job_validacion = self.after(250, self._validar_en_vivo)

    def _validar_en_vivo(self):
        self._job_validacion = None
        caja = self.texto_nrcs._textbox
        caja.tag_remove("error", "1.0", "end")
        if self.corrida_activa:
            # Con la corrida en marcha la lista se va vaciando sola: no se revalida.
            return

        lineas, posiciones = [], []
        for numero, linea in enumerate(self.texto_nrcs.get("1.0", "end").splitlines(), start=1):
            if linea.strip():
                lineas.append(linea.strip())
                posiciones.append(numero)

        errores, repetidas, n_validas = [], 0, len(lineas)
        validador = self._validador_actual()
        if validador is not None and lineas:
            try:
                ok, errores, repetidas = validador(lineas)
                n_validas = len(ok)
            except Exception:
                errores, repetidas, n_validas = [], 0, len(lineas)

        # «Línea N» cuenta solo las líneas con contenido: se traduce a la línea real.
        con_error = set()
        for texto in errores:
            m = re.match(r"\s*Línea (\d+)", texto)
            if m:
                i = int(m.group(1)) - 1
                if 0 <= i < len(posiciones):
                    con_error.add(posiciones[i])
        for numero in sorted(con_error)[:LIMITE_LINEAS_MARCADAS]:
            caja.tag_add("error", f"{numero}.0", f"{numero}.end+1c")

        n_errores = len(con_error) if con_error else len(errores)
        self._n_errores = n_errores

        self.pastilla_validas.actualizar(f"{n_validas} {'válida' if n_validas == 1 else 'válidas'}")
        if n_errores:
            self.pastilla_errores.actualizar(f"{n_errores} con error")
            self.pastilla_errores.pack(side="left", before=self.label_repetidas)
        else:
            self.pastilla_errores.pack_forget()
        self.label_repetidas.configure(
            text=f"{repetidas} repetida(s), se descartarán" if repetidas else ""
        )

        # Caja de problemas (todos los textos, con desplazamiento si son muchos).
        self.texto_problemas.configure(state="normal")
        self.texto_problemas.delete("1.0", "end")
        if errores:
            self.label_problemas.configure(
                text=f"{n_errores} {'línea con problema' if n_errores == 1 else 'líneas con problemas'}"
            )
            self.texto_problemas.insert("1.0", "\n".join(errores[:LIMITE_PROBLEMAS_MOSTRADOS]))
            if len(errores) > LIMITE_PROBLEMAS_MOSTRADOS:
                self.texto_problemas.insert(
                    "end", f"\n... y {len(errores) - LIMITE_PROBLEMAS_MOSTRADOS} más."
                )
            if not self.caja_problemas.winfo_ismapped():
                self.caja_problemas.pack(fill="x", pady=(10, 0), before=self.pie_entrada)
        else:
            self.caja_problemas.pack_forget()
        self.texto_problemas.configure(state="disabled")

        self._refrescar_boton_iniciar()

    def _refrescar_boton_iniciar(self):
        """Iniciar: negro si se puede; gris y con el motivo si hay líneas con error
        o ya hay una corrida en marcha."""
        if self.corrida_activa:
            self.btn_iniciar.configure(state="disabled", text="Iniciar", fg_color=COLOR_INACTIVO)
        elif self._n_errores:
            n = self._n_errores
            self.btn_iniciar.configure(
                state="disabled", fg_color=COLOR_INACTIVO,
                text=f"Corrige {n} {'línea' if n == 1 else 'líneas'} para iniciar",
            )
        else:
            self.btn_iniciar.configure(state="normal", text="Iniciar", fg_color=COLOR_ACENTO)

    def _on_limpiar_lista(self):
        if self.corrida_activa:
            return
        self.texto_nrcs.delete("1.0", "end")
        self._actualizar_chips()

    # ------------------------------------- confirmación antes de borrar datos --

    def _confirmar_inicio(self, accion, periodo, cantidad, atributo=None) -> bool:
        """Ventana de confirmación para las acciones que borran o modifican datos
        en Banner. Devuelve True solo si el usuario acepta."""
        ui = ACCIONES_UI[accion]
        raiz = self.winfo_toplevel()
        ventana = ctk.CTkToplevel(raiz)
        poner_icono(ventana)
        ventana.title("Confirmar corrida")
        ventana.configure(fg_color=COLOR_FONDO)
        ventana.resizable(False, False)
        ventana.transient(raiz)
        resultado = {"ok": False}

        tarjeta = ctk.CTkFrame(ventana, corner_radius=18, fg_color=COLOR_SUPERFICIE, border_width=0)
        tarjeta.pack(fill="both", expand=True, padx=16, pady=16)
        ctk.CTkLabel(tarjeta, text="¿Iniciar la corrida?", font=fuente(19, "bold"),
                     text_color=COLOR_TEXTO, anchor="w").pack(fill="x", padx=22, pady=(20, 0))
        ctk.CTkLabel(tarjeta, text="Revisa el resumen antes de modificar Banner.", font=fuente(13),
                     text_color=COLOR_MUTED, anchor="w").pack(fill="x", padx=22, pady=(2, 12))

        resumen = ctk.CTkFrame(tarjeta, corner_radius=12, fg_color=COLOR_SUPERFICIE_2, border_width=0)
        resumen.pack(fill="x", padx=22)
        filas = [("Acción", ui["titulo"], False), ("Periodo", periodo, True)]
        if atributo:
            filas.append(("Atributo", atributo, True))
        filas.append(("A modificar", f"{cantidad} NRC", False))
        for i, (clave, valor, mono) in enumerate(filas):
            fila = ctk.CTkFrame(resumen, fg_color="transparent")
            fila.pack(fill="x", padx=14, pady=(10 if i == 0 else 3, 10 if i == len(filas) - 1 else 3))
            ctk.CTkLabel(fila, text=clave, font=fuente(13), text_color=COLOR_MUTED).pack(side="left")
            ctk.CTkLabel(fila, text=valor, font=fuente_mono(13, "bold") if mono else fuente(13, "bold"),
                         text_color=COLOR_TEXTO).pack(side="right")

        aviso = ctk.CTkFrame(tarjeta, corner_radius=12, fg_color=COLOR_AVISO_TINTE, border_width=0)
        aviso.pack(fill="x", padx=22, pady=(12, 0))
        ctk.CTkLabel(aviso, text=ui["aviso"].replace("Atención: ", "Atención: ", 1), font=fuente(12),
                     text_color=COLOR_AVISO, justify="left", anchor="w").pack(fill="x", padx=14, pady=10)

        botones = ctk.CTkFrame(tarjeta, fg_color="transparent")

        def aceptar():
            resultado["ok"] = True
            ventana.destroy()

        def cancelar():
            ventana.destroy()

        btn_ok = ctk.CTkButton(
            botones, text=f"Iniciar {cantidad} NRC", height=42, corner_radius=12, font=fuente(14, "bold"),
            fg_color=COLOR_INACTIVO, text_color=COLOR_ACENTO_TEXTO, hover_color=COLOR_ACENTO_HOVER,
            text_color_disabled=COLOR_INACTIVO_TEXTO, state="disabled", command=aceptar,
        )

        def al_marcar():
            if var_entiendo.get():
                btn_ok.configure(state="normal", fg_color=COLOR_ACENTO)
            else:
                btn_ok.configure(state="disabled", fg_color=COLOR_INACTIVO)

        var_entiendo = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            tarjeta, text="Entiendo que se modificarán datos en Banner", variable=var_entiendo,
            command=al_marcar, font=fuente(13), text_color=COLOR_TEXTO, fg_color=COLOR_ACENTO,
            hover_color=COLOR_ACENTO_HOVER, border_color="#b9b9c2", checkmark_color=COLOR_ACENTO_TEXTO,
            corner_radius=6,
        ).pack(anchor="w", padx=22, pady=(14, 0))

        botones.pack(fill="x", padx=22, pady=(16, 20))
        ctk.CTkButton(
            botones, text="Cancelar", height=42, corner_radius=12, font=fuente(14, "bold"),
            fg_color=COLOR_ACENTO_TINTE, text_color=COLOR_TEXTO, hover_color=COLOR_BORDE, command=cancelar,
        ).pack(side="left", expand=True, fill="x", padx=(0, 6))
        btn_ok.pack(side="left", expand=True, fill="x", padx=(6, 0))

        ventana.bind("<Escape>", lambda e: cancelar())
        ventana.protocol("WM_DELETE_WINDOW", cancelar)
        ventana.update_idletasks()
        ancho, alto = max(ventana.winfo_reqwidth(), 460), ventana.winfo_reqheight()
        x = raiz.winfo_rootx() + (raiz.winfo_width() - ancho) // 2
        y = raiz.winfo_rooty() + (raiz.winfo_height() - alto) // 2
        ventana.geometry(f"{ancho}x{alto}+{max(x, 0)}+{max(y, 0)}")
        try:
            ventana.wait_visibility()
            ventana.grab_set()
        except Exception:
            pass
        ventana.focus_set()
        self.wait_window(ventana)
        return resultado["ok"]

    def _nombre_items(self) -> str:
        """Cómo llamar a cada línea de la lista según la automatización."""
        return {"sfabrdf": "regla(s)", "stvblck": "código(s)"}.get(self.accion_actual, "NRC(s)")

    def _on_importar_excel(self):
        es_reglas = self.accion_actual == "sfabrdf"
        es_codigos = self.accion_actual == "stvblck"
        es_ssarres = self.accion_actual == "ssarres_quitar"
        es_ssarres_atributo = self.accion_actual == ACCION_SSARRES_ATRIBUTO
        es_ssarres_conservar = self.accion_actual == ACCION_SSARRES_CONSERVAR
        es_ssarres_agregar = self.accion_actual == ACCION_SSARRES_AGREGAR
        if es_reglas:
            titulo_dialogo = "Importar reglas desde CSV o Excel"
        elif es_ssarres_conservar:
            titulo_dialogo = "Importar NRC y programas a conservar desde CSV, Excel o TXT"
        elif es_codigos:
            titulo_dialogo = "Importar códigos de bloque desde CSV, Excel o TXT"
        else:
            titulo_dialogo = "Importar NRCs desde Excel o CSV"
        ruta = filedialog.askopenfilename(
            title=titulo_dialogo,
            filetypes=[("Excel, CSV o TXT", "*.xlsx *.xls *.csv *.txt")],
        )
        if not ruta:
            return
        repetidas = 0
        try:
            if es_reglas:
                nrcs, repetidas = leer_reglas_de_archivo(ruta)
            elif es_codigos:
                nrcs, repetidas = leer_codigos_de_archivo(ruta)
            elif es_ssarres:
                nrcs, repetidas = leer_nrcs_ssarres(ruta)
            elif es_ssarres_atributo:
                nrcs, repetidas = leer_nrcs_ssarres_atributo(ruta)
            elif es_ssarres_conservar:
                nrcs, repetidas = leer_pares_ssarres_conservar(ruta)
            elif es_ssarres_agregar:
                nrcs, repetidas = leer_nrcs_ssarres_agregar(ruta)
            else:
                nrcs = leer_nrcs_de_archivo(ruta)
        except Exception as err:
            self._log(f"No se pudo importar el archivo: {err}", tipo="error")
            return

        etiqueta = self._nombre_items()
        if not nrcs:
            self._log(f"El archivo no contenía {etiqueta} reconocibles.", tipo="error")
            return

        self.texto_nrcs.delete("1.0", "end")
        self.texto_nrcs.insert("1.0", "\n".join(nrcs))
        self._actualizar_chips()
        self._log(f"Se importaron {len(nrcs)} {etiqueta} desde {os.path.basename(ruta)}.", tipo="info")
        if repetidas:
            self._log(
                f"Se descartaron {repetidas} línea(s) repetida(s) del archivo (una repetida solo daría 'duplicado' en Banner).",
                tipo="info",
            )

    def _precargar_pendientes(self):
        """Si quedó algo pendiente de una corrida anterior de esta automatización, precargarlo."""
        pendientes = leer_pendientes_guardados(self.accion_actual)
        if pendientes:
            self.texto_nrcs.delete("1.0", "end")
            self.texto_nrcs.insert("1.0", "\n".join(pendientes))
            self._log(
                f"Se precargaron {len(pendientes)} {self._nombre_items()} "
                "pendientes de una corrida anterior.",
                tipo="info",
            )
            self._actualizar_chips()

    def _abrir_configuracion(self):
        ventana = ctk.CTkToplevel(self)
        poner_icono(ventana)
        ventana.title("Configuración")
        ventana.geometry("400x364")
        ventana.configure(fg_color=COLOR_FONDO)
        ventana.grab_set()

        tarjeta = ctk.CTkFrame(ventana, corner_radius=18, fg_color=COLOR_SUPERFICIE, border_width=0)
        tarjeta.pack(fill="both", expand=True, padx=14, pady=14)

        ctk.CTkLabel(
            tarjeta, text="Procesos simultáneos", font=FUENTE_SUBTITULO, text_color=COLOR_TEXTO
        ).pack(padx=20, pady=(18, 4), anchor="w")

        ctk.CTkLabel(
            tarjeta,
            text=(
                f"Solo aplica a corridas de {UMBRAL_PARALELO_SFABRDF + 1} o más datos\n"
                "(NRC, reglas o códigos); con menos se usa 1\n"
                "proceso. Vale para todas las formas.\n"
                "\n"
                "Cada proceso es una pestaña de Banner. Más\n"
                "procesos van más rápido, pero le piden más al\n"
                "servidor de Banner (compartido con el resto de\n"
                "la universidad)."
            ),
            font=fuente(12), text_color=COLOR_MUTED, justify="left",
        ).pack(padx=20, pady=(0, 12), anchor="w")

        var_pestanas = ctk.StringVar(value=str(self.num_pestanas))
        combo = ctk.CTkOptionMenu(
            tarjeta, variable=var_pestanas, values=[str(n) for n in range(1, 11)],
            height=36, corner_radius=10, font=fuente(13), fg_color=COLOR_ACENTO_TINTE,
            button_color=COLOR_ACENTO_TINTE, button_hover_color=COLOR_BORDE, text_color=COLOR_TEXTO,
            dropdown_fg_color=COLOR_SUPERFICIE, dropdown_text_color=COLOR_TEXTO,
            dropdown_hover_color=COLOR_ACENTO_TINTE, dropdown_font=fuente(13),
        )
        combo.pack(padx=20, pady=(0, 14), fill="x")

        def guardar():
            valor = int(var_pestanas.get())
            self.num_pestanas = valor
            self.btn_configuracion.configure(text=f"Procesos: {valor}")
            # No se persiste a disco a propósito: usar más de 5 pestañas
            # es una excepción puntual para esta corrida, no debe quedar
            # pegado como preferencia para la próxima vez que se abra la
            # app (siempre debe arrancar en 5).
            self._log(f"Procesos simultáneos configurados en: {valor} (solo para esta sesión)", tipo="info")
            ventana.destroy()

        ctk.CTkButton(
            tarjeta, text="Guardar", height=40, corner_radius=12, font=fuente(14, "bold"),
            fg_color=COLOR_ACENTO, hover_color=COLOR_ACENTO_HOVER, text_color=COLOR_ACENTO_TEXTO,
            command=guardar,
        ).pack(padx=20, pady=(0, 18), fill="x")

    def _on_cerrar_sesion(self):
        if self.corrida_activa:
            messagebox.showwarning(
                "Corrida en curso",
                "Hay una corrida en curso. Cancélala o espera a que termine antes de cerrar sesión.",
            )
            return

        confirmar = messagebox.askyesno(
            "Cerrar sesión",
            "¿Seguro que quieres cerrar sesión? Vas a tener que volver a iniciar sesión "
            "con Google para usar la app de nuevo.",
        )
        if not confirmar:
            return

        borrar_datos_sesion()
        self._log("Sesión cerrada manualmente por el usuario.", tipo="info")
        if self.on_sesion_perdida:
            self.on_sesion_perdida()

    def _fallos_corrida_actual(self) -> list:
        """Líneas de fallo SOLO de la corrida actual (o la última de esta sesión).
        Nunca mezcla corridas anteriores: eso confundía al usuario."""
        est = self.estado_corrida_actual
        if est is None or not os.path.exists(est.ruta_fallos):
            return []
        with open(est.ruta_fallos, "r", encoding="utf-8") as f:
            return [linea.strip() for linea in f if linea.strip()]

    def _mostrar_detalle_fallos_reglas(self):
        """Fallos de SFABRDF de la corrida actual: cada regla con sus valores
        etiquetados, el motivo explicado y un TXT con la misma estructura del CSV."""
        ventana = ctk.CTkToplevel(self)
        poner_icono(ventana)
        ventana.title("Reglas con error — SFABRDF")
        ventana.geometry("880x580")
        ventana.configure(fg_color=COLOR_FONDO)
        ventana.grab_set()
        ventana.grid_columnconfigure(0, weight=1)
        ventana.grid_rowconfigure(1, weight=1)

        lineas = self._fallos_corrida_actual()
        texto, claves = formatear_fallos_sfabrdf(lineas)
        if not lineas:
            texto = (
                "Sin errores en esta corrida."
                if self.estado_corrida_actual is not None
                else "Aún no hay una corrida en esta sesión."
            )
        # Todas las reglas con error (incluye duplicadas) en el formato del CSV de entrada.
        todas = []
        for l in lineas:
            d = parsear_linea_fallo(l)
            todas.append(d["clave"])

        barra = ctk.CTkFrame(ventana, fg_color="transparent")
        barra.grid(row=0, column=0, sticky="ew", padx=12, pady=(12, 0))
        barra.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            barra, text=f"Corrida actual — {len(lineas)} regla(s) con error",
            font=FUENTE_SUBTITULO, anchor="w", text_color=COLOR_TEXTO,
        ).grid(row=0, column=0, sticky="w")

        def guardar_txt():
            ruta = filedialog.asksaveasfilename(
                parent=ventana, defaultextension=".txt", initialfile="reglas_con_error.txt",
                filetypes=[("Texto", "*.txt")],
            )
            if not ruta:
                return
            with open(ruta, "w", encoding="utf-8") as f:
                f.write("\n".join(todas) + "\n")
            self._log(f"Reglas con error guardadas en: {ruta}", tipo="info")

        def copiar():
            ventana.clipboard_clear()
            ventana.clipboard_append("\n".join(claves))
            self._log(
                f"Se copiaron {len(claves)} regla(s) con error al portapapeles "
                "(sin los duplicados): pégalas en 'Reglas pendientes' para reintentarlas.",
                tipo="info",
            )

        btn_txt = ctk.CTkButton(barra, text="Guardar .txt", width=120, height=32,
                                font=fuente(12, "bold"), command=guardar_txt, **ESTILO_BOTON_TONAL,
                                state="normal" if todas else "disabled")
        btn_txt.grid(row=0, column=1, padx=(8, 0))
        btn_copiar = ctk.CTkButton(barra, text="Copiar para reintentar", width=170, height=32,
                                   font=fuente(12, "bold"), command=copiar, **ESTILO_BOTON_PRINCIPAL,
                                   state="normal" if claves else "disabled")
        btn_copiar.grid(row=0, column=2, padx=(8, 0))

        caja = ctk.CTkTextbox(ventana, font=FUENTE_MONO, wrap="word", corner_radius=14,
                              fg_color=COLOR_SUPERFICIE, text_color=COLOR_TEXTO, border_width=0)
        caja.grid(row=1, column=0, sticky="nsew", padx=12, pady=12)
        caja.insert("1.0", texto)
        caja.configure(state="disabled")

    def _mostrar_detalle_fallos_codigos(self):
        """Fallos de STVBLCK de la corrida actual: cada código con el motivo
        explicado, y botones para guardar/copiar los códigos a reintentar."""
        ventana = ctk.CTkToplevel(self)
        poner_icono(ventana)
        ventana.title("Códigos con error — STVBLCK")
        ventana.geometry("880x580")
        ventana.configure(fg_color=COLOR_FONDO)
        ventana.grab_set()
        ventana.grid_columnconfigure(0, weight=1)
        ventana.grid_rowconfigure(1, weight=1)

        lineas = self._fallos_corrida_actual()
        texto, claves = formatear_fallos_stvblck(lineas)
        if not lineas:
            texto = (
                "Sin errores en esta corrida."
                if self.estado_corrida_actual is not None
                else "Aún no hay una corrida en esta sesión."
            )
        # Todos los códigos con error (incluye los rechazados por Banner).
        todas = [parsear_linea_fallo(l)["clave"] for l in lineas]

        barra = ctk.CTkFrame(ventana, fg_color="transparent")
        barra.grid(row=0, column=0, sticky="ew", padx=12, pady=(12, 0))
        barra.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            barra, text=f"Corrida actual — {len(lineas)} código(s) con error",
            font=FUENTE_SUBTITULO, anchor="w", text_color=COLOR_TEXTO,
        ).grid(row=0, column=0, sticky="w")

        def guardar_txt():
            ruta = filedialog.asksaveasfilename(
                parent=ventana, defaultextension=".txt", initialfile="codigos_con_error.txt",
                filetypes=[("Texto", "*.txt")],
            )
            if not ruta:
                return
            with open(ruta, "w", encoding="utf-8") as f:
                f.write("\n".join(todas) + "\n")
            self._log(f"Códigos con error guardados en: {ruta}", tipo="info")

        def copiar():
            ventana.clipboard_clear()
            ventana.clipboard_append("\n".join(claves))
            self._log(
                f"Se copiaron {len(claves)} código(s) con error al portapapeles "
                "(sin los rechazados por Banner): pégalos en 'Códigos pendientes' para reintentarlos.",
                tipo="info",
            )

        ctk.CTkButton(barra, text="Guardar .txt", width=120, height=32,
                      font=fuente(12, "bold"), command=guardar_txt, **ESTILO_BOTON_TONAL,
                      state="normal" if todas else "disabled").grid(row=0, column=1, padx=(8, 0))
        ctk.CTkButton(barra, text="Copiar para reintentar", width=170, height=32,
                      font=fuente(12, "bold"), command=copiar, **ESTILO_BOTON_PRINCIPAL,
                      state="normal" if claves else "disabled").grid(row=0, column=2, padx=(8, 0))

        caja = ctk.CTkTextbox(ventana, font=FUENTE_MONO, wrap="word", corner_radius=14,
                              fg_color=COLOR_SUPERFICIE, text_color=COLOR_TEXTO, border_width=0)
        caja.grid(row=1, column=0, sticky="nsew", padx=12, pady=12)
        caja.insert("1.0", texto)
        caja.configure(state="disabled")

    def _mostrar_detalle_fallos_ssarres(self, formateador=formatear_fallos_ssarres, titulo="NRCs con error — SSARRES"):
        """Fallos de SSARRES de la corrida actual: cada NRC con el motivo
        explicado, y botones para guardar/copiar los NRC que sí vale reintentar.
        `formateador` y `titulo` cambian según la función (programas / atributo)."""
        ventana = ctk.CTkToplevel(self)
        poner_icono(ventana)
        ventana.title(titulo)
        ventana.geometry("880x580")
        ventana.configure(fg_color=COLOR_FONDO)
        ventana.grab_set()
        ventana.grid_columnconfigure(0, weight=1)
        ventana.grid_rowconfigure(1, weight=1)

        lineas = self._fallos_corrida_actual()
        texto, claves = formateador(lineas)
        if not lineas:
            texto = (
                "Sin errores en esta corrida."
                if self.estado_corrida_actual is not None
                else "Aún no hay una corrida en esta sesión."
            )
        todas = [parsear_linea_fallo(l)["clave"] for l in lineas]

        barra = ctk.CTkFrame(ventana, fg_color="transparent")
        barra.grid(row=0, column=0, sticky="ew", padx=12, pady=(12, 0))
        barra.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            barra, text=f"Corrida actual — {len(lineas)} NRC(s) con error",
            font=FUENTE_SUBTITULO, anchor="w", text_color=COLOR_TEXTO,
        ).grid(row=0, column=0, sticky="w")

        def guardar_txt():
            ruta = filedialog.asksaveasfilename(
                parent=ventana, defaultextension=".txt", initialfile="nrcs_con_error.txt",
                filetypes=[("Texto", "*.txt")],
            )
            if not ruta:
                return
            with open(ruta, "w", encoding="utf-8") as f:
                f.write("\n".join(todas) + "\n")
            self._log(f"NRCs con error guardados en: {ruta}", tipo="info")

        def copiar():
            ventana.clipboard_clear()
            ventana.clipboard_append("\n".join(claves))
            self._log(
                f"Se copiaron {len(claves)} NRC(s) con error al portapapeles "
                "(sin los inexistentes ni los que hay que corregir a mano): pégalos en 'NRCs pendientes' para reintentarlos.",
                tipo="info",
            )

        ctk.CTkButton(barra, text="Guardar .txt", width=120, height=32,
                      font=fuente(12, "bold"), command=guardar_txt, **ESTILO_BOTON_TONAL,
                      state="normal" if todas else "disabled").grid(row=0, column=1, padx=(8, 0))
        ctk.CTkButton(barra, text="Copiar para reintentar", width=170, height=32,
                      font=fuente(12, "bold"), command=copiar, **ESTILO_BOTON_PRINCIPAL,
                      state="normal" if claves else "disabled").grid(row=0, column=2, padx=(8, 0))

        caja = ctk.CTkTextbox(ventana, font=FUENTE_MONO, wrap="word", corner_radius=14,
                              fg_color=COLOR_SUPERFICIE, text_color=COLOR_TEXTO, border_width=0)
        caja.grid(row=1, column=0, sticky="nsew", padx=12, pady=12)
        caja.insert("1.0", texto)
        caja.configure(state="disabled")

    def _mostrar_detalle_fallos(self):
        if self.accion_actual == "ssarres_quitar":
            self._mostrar_detalle_fallos_ssarres()
            return
        if self.accion_actual == ACCION_SSARRES_CONSERVAR:
            self._mostrar_detalle_fallos_ssarres(
                formateador=formatear_fallos_ssarres_conservar,
                titulo="NRCs con error — SSARRES (dejar solo programas)",
            )
            return
        if self.accion_actual == ACCION_SSARRES_ATRIBUTO:
            self._mostrar_detalle_fallos_ssarres(
                formateador=formatear_fallos_ssarres_atributo,
                titulo="NRCs con error — SSARRES (atributo)",
            )
            return
        if self.accion_actual == ACCION_SSARRES_AGREGAR:
            self._mostrar_detalle_fallos_ssarres(
                formateador=formatear_fallos_ssarres_agregar,
                titulo="NRCs con error — SSARRES (agregar programa)",
            )
            return
        if self.accion_actual == "sfabrdf":
            self._mostrar_detalle_fallos_reglas()
            return
        if self.accion_actual == "stvblck":
            self._mostrar_detalle_fallos_codigos()
            return
        fallos = listar_fallos(self.accion_actual)
        ventana = ctk.CTkToplevel(self)
        poner_icono(ventana)
        ventana.title("Detalle de fallos")
        ventana.geometry("420x360")
        ventana.grab_set()

        caja = ctk.CTkTextbox(ventana, font=FUENTE_MONO)
        caja.pack(fill="both", expand=True, padx=12, pady=12)
        if fallos:
            caja.insert("1.0", "\n".join(fallos))
        else:
            caja.insert("1.0", "Sin fallos registrados todavía.")
        caja.configure(state="disabled")

    def _on_iniciar(self):
        periodo = self.entry_periodo.get().strip()
        accion = self.accion_actual
        nuevo_estatus = self.var_estatus.get().strip()
        nrcs = [l.strip() for l in self.texto_nrcs.get("1.0", "end").splitlines() if l.strip()]
        es_reglas = accion == "sfabrdf"
        es_codigos = accion == "stvblck"
        es_ssarres = accion == "ssarres_quitar"
        es_ssarres_atributo = accion == ACCION_SSARRES_ATRIBUTO
        es_ssarres_conservar = accion == ACCION_SSARRES_CONSERVAR
        es_ssarres_agregar = accion == ACCION_SSARRES_AGREGAR
        atributo = SSARRES_ATRIBUTO
        if es_ssarres_atributo:
            try:
                atributo = validar_atributo_ssarres(self.var_atributo.get())
            except ValueError as err:
                self._log(str(err), tipo="error")
                return

        # STVBLCK no usa periodo (abre directo en la grilla).
        if not es_codigos:
            if not periodo:
                self._log("Falta indicar el periodo académico.", tipo="error")
                return
            if len(periodo) != 6:
                self._log("El periodo académico debe tener exactamente 6 dígitos.", tipo="error")
                return
        if not nrcs:
            if es_ssarres_conservar:
                self._log("Falta al menos una línea «NRC,código,código».", tipo="error")
            elif es_reglas:
                self._log("Falta al menos una regla.", tipo="error")
            elif es_codigos:
                self._log("Falta al menos un código de bloque.", tipo="error")
            else:
                self._log("Falta al menos un NRC.", tipo="error")
            return
        if es_ssarres or es_ssarres_atributo or es_ssarres_agregar:
            # Solo dígitos y sin repetidos; se valida TODO antes de empezar.
            validador = (
                validar_nrcs_atributo if es_ssarres_atributo
                else validar_nrcs_agregar if es_ssarres_agregar
                else validar_nrcs
            )
            nrcs, errores, repetidas = validador(nrcs)
            if errores:
                for e in errores[:8]:
                    self._log(e, tipo="error")
                if len(errores) > 8:
                    self._log(f"... y {len(errores) - 8} línea(s) más con problemas.", tipo="error")
                return
            if repetidas:
                self._log(f"Se descartaron {repetidas} NRC(s) repetido(s).", tipo="info")
            if not nrcs:
                self._log("No quedaron NRCs válidos para procesar.", tipo="error")
                return
            self.texto_nrcs.delete("1.0", "end")
            self.texto_nrcs.insert("1.0", "\n".join(nrcs) + "\n")
        if es_ssarres_conservar:
            # Cada línea = NRC + códigos de programa que deben QUEDAR (3 dígitos). Se valida
            # TODO antes de empezar: si algo no cumple, NO se inicia (nada se toca a medias).
            nrcs, errores, repetidas = validar_lineas_conservar(nrcs)
            if errores:
                for e in errores[:8]:
                    self._log(e, tipo="error")
                if len(errores) > 8:
                    self._log(f"... y {len(errores) - 8} línea(s) más con problemas.", tipo="error")
                self._log("No se inició nada. Formato por línea: NRC,código,código (cada código = 3 dígitos numéricos).", tipo="info")
                return
            if repetidas:
                self._log(f"Se descartaron {repetidas} línea(s) repetida(s).", tipo="info")
            if not nrcs:
                self._log("No quedaron líneas válidas para procesar.", tipo="error")
                return
            # El textarea se reescribe normalizado: cada línea es la clave de su NRC y
            # coincide con la que se quita al ir procesándola.
            self.texto_nrcs.delete("1.0", "end")
            self.texto_nrcs.insert("1.0", "\n".join(nrcs) + "\n")
        if es_codigos:
            # Se validan TODOS los códigos antes de empezar (caracteres, largo,
            # repetidos): mejor un aviso claro ahora que fallos a mitad de corrida.
            nrcs, errores, repetidas = validar_codigos(nrcs)
            if errores:
                for e in errores[:8]:
                    self._log(e, tipo="error")
                if len(errores) > 8:
                    self._log(f"... y {len(errores) - 8} línea(s) más con problemas.", tipo="error")
                return
            if repetidas:
                self._log(f"Se descartaron {repetidas} código(s) repetido(s).", tipo="info")
            if not nrcs:
                self._log("No quedaron códigos válidos para procesar.", tipo="error")
                return
            # El textarea se reescribe normalizado (MAYÚSCULAS, sin repetidos):
            # cada línea es la clave de su código, y así coincide con la que se
            # quita al ir procesándolo.
            self.texto_nrcs.delete("1.0", "end")
            self.texto_nrcs.insert("1.0", "\n".join(nrcs) + "\n")
        if es_reglas:
            # Cada línea debe traer los 8 campos. Se validan TODAS antes de
            # empezar: es mejor un aviso claro ahora que fallos a mitad de corrida.
            nrcs, errores, repetidas = validar_lineas(nrcs)
            if errores:
                for e in errores[:8]:
                    self._log(e, tipo="error")
                if len(errores) > 8:
                    self._log(f"... y {len(errores) - 8} línea(s) más con problemas.", tipo="error")
                self._log(f"Cada regla necesita 8 campos: {ENCABEZADO_SFABRDF}.", tipo="info")
                return
            if repetidas:
                self._log(f"Se descartaron {repetidas} regla(s) repetida(s).", tipo="info")
            if not nrcs:
                self._log("No quedaron reglas válidas para procesar.", tipo="error")
                return
            # El textarea se reescribe normalizado: cada línea es la clave de su
            # regla, y así coincide con la que se quita al ir procesándola.
            self.texto_nrcs.delete("1.0", "end")
            self.texto_nrcs.insert("1.0", "\n".join(nrcs) + "\n")
        if accion == "estatus" and not nuevo_estatus:
            self._log("Falta indicar el nuevo estatus.", tipo="error")
            return
        if self.corrida_activa:
            self._log("Ya hay una corrida en curso.", tipo="error")
            return
        # Acciones que borran o modifican datos: confirmación explícita antes de empezar.
        if accion in ACCIONES_DESTRUCTIVAS:
            if not self._confirmar_inicio(
                accion, periodo, len(nrcs), atributo if es_ssarres_atributo else None
            ):
                self._log("Corrida cancelada: no se confirmó el inicio.", tipo="info")
                return

        self.control = Control()
        self.corrida_activa = True
        self._limpiar_log()
        estado_corrida = EstadoCorrida(accion, nrcs)
        self.estado_corrida_actual = estado_corrida  # la ventana de errores solo muestra ESTA corrida
        self.total_nrcs_corrida = len(nrcs)

        self._refrescar_boton_iniciar()
        self.btn_limpiar.configure(state="disabled")
        self.btn_pausar.configure(state="normal", text="Pausar")
        self.btn_cancelar.configure(state="normal")
        self.label_progreso.configure(
            text=f"Procesando {len(nrcs)} {self._nombre_items()}..."
        )
        self.barra_progreso.set(0)
        self.tiempo_inicio = time.time()
        self._actualizar_cronometro()
        self._actualizar_chips()

        def trabajo():
            try:
                if es_reglas:
                    asyncio.run(ejecutar_lote_sfabrdf(
                        periodo=periodo,
                        lineas=nrcs,
                        estado_corrida=estado_corrida,
                        control=self.control,
                        on_log=lambda m: self.cola_logs.put(("detalle", m)),
                        on_resumen=lambda m: self.cola_logs.put(("log", m)),
                        on_progreso=lambda nrc, p, pend, f: self.cola_logs.put(("progreso", (nrc, p, pend, f))),
                        num_pestanas=self.num_pestanas,
                    ))
                elif es_ssarres_atributo:
                    asyncio.run(ejecutar_lote_ssarres_atributo(
                        periodo=periodo,
                        atributo=atributo,
                        nrcs=nrcs,
                        estado_corrida=estado_corrida,
                        control=self.control,
                        on_log=lambda m: self.cola_logs.put(("detalle", m)),
                        on_resumen=lambda m: self.cola_logs.put(("log", m)),
                        on_progreso=lambda nrc, p, pend, f: self.cola_logs.put(("progreso", (nrc, p, pend, f))),
                        num_pestanas=self.num_pestanas,
                    ))
                elif es_ssarres_agregar:
                    asyncio.run(ejecutar_lote_ssarres_agregar(
                        periodo=periodo,
                        modo="agregar",
                        nrcs=nrcs,
                        estado_corrida=estado_corrida,
                        control=self.control,
                        on_log=lambda m: self.cola_logs.put(("detalle", m)),
                        on_resumen=lambda m: self.cola_logs.put(("log", m)),
                        on_progreso=lambda nrc, p, pend, f: self.cola_logs.put(("progreso", (nrc, p, pend, f))),
                        num_pestanas=self.num_pestanas,
                    ))
                elif es_ssarres_conservar:
                    asyncio.run(ejecutar_lote_ssarres_conservar(
                        periodo=periodo,
                        lineas=nrcs,
                        estado_corrida=estado_corrida,
                        control=self.control,
                        on_log=lambda m: self.cola_logs.put(("detalle", m)),
                        on_resumen=lambda m: self.cola_logs.put(("log", m)),
                        on_progreso=lambda nrc, p, pend, f: self.cola_logs.put(("progreso", (nrc, p, pend, f))),
                        num_pestanas=self.num_pestanas,
                    ))
                elif es_ssarres:
                    asyncio.run(ejecutar_lote_ssarres(
                        periodo=periodo,
                        modo=SSARRES_QUITAR,
                        nrcs=nrcs,
                        estado_corrida=estado_corrida,
                        control=self.control,
                        on_log=lambda m: self.cola_logs.put(("detalle", m)),
                        on_resumen=lambda m: self.cola_logs.put(("log", m)),
                        on_progreso=lambda nrc, p, pend, f: self.cola_logs.put(("progreso", (nrc, p, pend, f))),
                        num_pestanas=self.num_pestanas,
                    ))
                elif es_codigos:
                    asyncio.run(ejecutar_lote_stvblck(
                        lineas=nrcs,
                        estado_corrida=estado_corrida,
                        control=self.control,
                        on_log=lambda m: self.cola_logs.put(("detalle", m)),
                        on_resumen=lambda m: self.cola_logs.put(("log", m)),
                        on_progreso=lambda nrc, p, pend, f: self.cola_logs.put(("progreso", (nrc, p, pend, f))),
                        num_pestanas=self.num_pestanas,
                    ))
                else:
                    asyncio.run(ejecutar_lote(
                        periodo=periodo,
                        accion=accion,
                        nuevo_estatus=nuevo_estatus,
                        nrcs=nrcs,
                        estado_corrida=estado_corrida,
                        control=self.control,
                        on_log=lambda m: self.cola_logs.put(("detalle", m)),
                        on_resumen=lambda m: self.cola_logs.put(("log", m)),
                        on_progreso=lambda nrc, p, pend, f: self.cola_logs.put(("progreso", (nrc, p, pend, f))),
                        num_pestanas=self.num_pestanas,
                    ))
            except Exception as err:
                import traceback
                # RecursionError y similares necesitan el traceback
                # completo para saber QUÉ función se está llamando a sí
                # misma - el mensaje solo (str(err)) no alcanza para
                # diagnosticar este tipo de error.
                try:
                    detalle = traceback.format_exc()
                except Exception:
                    detalle = "(no se pudo generar el traceback completo)"
                self.cola_logs.put(("log", f"Error fatal en la corrida: {err}\n{detalle}"))
            finally:
                self.cola_logs.put(("finalizado", None))

        threading.Thread(target=trabajo, daemon=True).start()

    def _on_pausar(self):
        self.control.pausado = not self.control.pausado
        self.btn_pausar.configure(text="Reanudar" if self.control.pausado else "Pausar")
        self._log("Pausado." if self.control.pausado else "Reanudado.", tipo="info")

    def _on_cancelar(self):
        self.control.cancelado = True
        self.control.pausado = False
        self.btn_cancelar.configure(state="disabled")
        self._log("Cancelando... (termina el NRC actual y se detiene)", tipo="info")

    # ------------------------------------------------------- utilitarios --

    def _actualizar_chips(self):
        pendientes_actuales = [
            l.strip() for l in self.texto_nrcs.get("1.0", "end").splitlines() if l.strip()
        ]
        self.chip_pendientes.actualizar(len(pendientes_actuales))
        self.chip_procesados.actualizar(0)
        self.chip_fallos.actualizar(0)
        self._programar_validacion()

    def _quitar_nrc_de_textarea(self, nrc: str):
        """Borra la línea de un NRC ya procesado del textarea, para que la
        lista de "pendientes" se vaya vaciando en pantalla a medida que
        avanza la corrida."""
        lineas_actuales = self.texto_nrcs.get("1.0", "end").splitlines()
        lineas_nuevas = [l for l in lineas_actuales if l.strip() != nrc]
        self.texto_nrcs.delete("1.0", "end")
        if lineas_nuevas:
            self.texto_nrcs.insert("1.0", "\n".join(lineas_nuevas) + "\n")

    def _actualizar_cronometro(self):
        if not self.corrida_activa or self.tiempo_inicio is None:
            return
        transcurrido = int(time.time() - self.tiempo_inicio)
        minutos, segundos = divmod(transcurrido, 60)
        self.label_cronometro.configure(text=f"{minutos:02d}:{segundos:02d}")
        self.after(1000, self._actualizar_cronometro)

    def _limpiar_log(self):
        self.texto_log.configure(state="normal")
        self.texto_log.delete("1.0", "end")
        self.texto_log.configure(state="disabled")

    def _log(self, mensaje: str, tipo: str = "info"):
        self.texto_log.configure(state="normal")
        inicio = self.texto_log.index("end-1c")
        self.texto_log.insert("end", f"{mensaje}\n")
        try:
            self.texto_log._textbox.tag_add(tipo, inicio, "end-1c")
        except Exception:
            pass
        self.texto_log.see("end")
        self.texto_log.configure(state="disabled")
        try:
            agregar_log_texto(mensaje)
        except Exception:
            pass

    def _tipo_por_contenido(self, mensaje: str) -> str:
        minus = mensaje.lower()
        if "falló" in minus or "error" in minus or "no se pudo" in minus:
            return "error"
        if ": ok" in minus or ": procesado" in minus:
            return "exito"
        return "info"

    def manejar_evento_cola(self, tipo, datos):
        if tipo == "log":
            self._log(datos, tipo=self._tipo_por_contenido(datos))
        elif tipo == "detalle":
            # Detalle completo (reintentos, capturas, sesión expirada,
            # etc.) - se guarda en datos/app.log para diagnóstico, pero
            # NO se muestra en el panel de la interfaz: el usuario solo
            # necesita ver si un NRC se procesó o falló, no cada
            # reintento intermedio.
            agregar_log_texto(datos)
        elif tipo == "progreso":
            nrc, procesados, pendientes, fallos = datos
            self._quitar_nrc_de_textarea(nrc)
            self.label_progreso.configure(text=f"Procesados: {procesados} | Pendientes: {pendientes}")
            self.chip_procesados.actualizar(procesados)
            self.chip_pendientes.actualizar(pendientes)
            self.chip_fallos.actualizar(fallos)
            total = getattr(self, "total_nrcs_corrida", None)
            if total:
                self.barra_progreso.set(min(procesados / total, 1.0))
        elif tipo == "finalizado":
            self._log("Corrida finalizada.", tipo="info")
            self.corrida_activa = False
            self.btn_pausar.configure(state="disabled", text="Pausar")
            self.btn_cancelar.configure(state="disabled")
            self.btn_limpiar.configure(state="normal")
            self._programar_validacion()   # revalida la lista que quedó y rehabilita Iniciar
            if not hay_sesion_guardada() and self.on_sesion_perdida:
                self._log("Sesión perdida - volviendo a la pantalla de login.", tipo="error")
                self.on_sesion_perdida()


# ================================================================ APP =====

TAMANO_LOGIN = "460x600"
TAMANO_PRINCIPAL = "1180x720"
MINIMO_PRINCIPAL = (1100, 600)


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(APP_NOMBRE)
        poner_icono(self)
        self.configure(fg_color=COLOR_FONDO)
        self.minsize(420, 560)

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.cola_logs = queue.Queue()
        self.pantalla_login = None
        self.pantalla_principal = None

        # El login es obligatorio en cada arranque: se borra cualquier sesión que haya
        # quedado (cierre forzado, corte de luz...) y se muestra siempre el login.
        try:
            borrar_datos_sesion()
        except Exception:
            pass
        self.geometry(TAMANO_LOGIN)
        self._centrar_ventana()
        self._mostrar_pantalla_login()
        self.protocol("WM_DELETE_WINDOW", self._al_cerrar)

        self.after(150, self._drenar_cola)

    def _al_cerrar(self):
        """Al cerrar la app se borra la sesión (Banner + Google): la próxima vez hay que
        volver a iniciar sesión. Con una corrida en curso se pide confirmación."""
        principal = self.pantalla_principal
        if principal is not None and principal.corrida_activa:
            if not messagebox.askyesno(
                "Corrida en curso",
                "Hay una corrida en curso. Si cierras ahora se interrumpe y se cierra la sesión.\n\n"
                "¿Cerrar de todos modos?",
                default="no",
            ):
                return
            principal.control.cancelado = True
        try:
            borrar_datos_sesion()
        except Exception:
            pass
        self.destroy()

    def _centrar_ventana(self):
        self.update_idletasks()
        ancho, alto = 460, 600
        x = (self.winfo_screenwidth() - ancho) // 2
        y = (self.winfo_screenheight() - alto) // 2
        self.geometry(f"{ancho}x{alto}+{x}+{y}")

    def _ajustar_ventana_principal(self):
        """Tamaño de la pantalla principal: 1180x720 como máximo y siempre dentro de
        la pantalla (en laptops de 15" con escala 125-150 % el alto útil es menor)."""
        ancho, alto = (int(v) for v in TAMANO_PRINCIPAL.split("x"))
        min_ancho, min_alto = MINIMO_PRINCIPAL
        try:
            escala = self._get_window_scaling() or 1.0
            ancho = min(ancho, int(self.winfo_screenwidth() * 0.96 / escala))
            alto = min(alto, int(self.winfo_screenheight() * 0.88 / escala))
        except Exception:
            pass
        self.minsize(min(min_ancho, ancho), min(min_alto, alto))
        self.geometry(f"{ancho}x{alto}")

    def _mostrar_pantalla_login(self):
        if self.pantalla_principal:
            self.pantalla_principal.grid_forget()
        self.pantalla_login = PantallaLogin(
            self, on_login_exitoso=self._mostrar_pantalla_principal, cola_logs=self.cola_logs
        )
        self.pantalla_login.grid(row=0, column=0, sticky="nsew")

    def _mostrar_pantalla_principal(self):
        if self.pantalla_login:
            self.pantalla_login.grid_forget()
        self._ajustar_ventana_principal()
        self.pantalla_principal = PantallaPrincipal(
            self, cola_logs=self.cola_logs, on_sesion_perdida=self._mostrar_pantalla_login
        )
        self.pantalla_principal.grid(row=0, column=0, sticky="nsew")

    def _drenar_cola(self):
        try:
            while True:
                tipo, datos = self.cola_logs.get_nowait()

                if tipo == "log" and not self.pantalla_principal:
                    # Durante el login todavía no existe pantalla_principal
                    # (que es quien normalmente escribe a archivo) - se
                    # guarda igual para no perder el rastro de lo que pasó.
                    try:
                        agregar_log_texto(datos)
                    except Exception:
                        pass

                if tipo == "login_ok" and self.pantalla_login:
                    self.pantalla_login.notificar_login_ok()
                elif tipo == "login_error" and self.pantalla_login:
                    self.pantalla_login.notificar_login_error(datos)
                elif self.pantalla_principal:
                    self.pantalla_principal.manejar_evento_cola(tipo, datos)
        except queue.Empty:
            pass
        finally:
            self.after(150, self._drenar_cola)


if __name__ == "__main__":
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID_WINDOWS)
        except Exception:
            pass
    app = App()
    app.mainloop()